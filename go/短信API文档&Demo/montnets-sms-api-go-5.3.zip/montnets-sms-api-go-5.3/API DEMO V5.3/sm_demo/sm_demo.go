package main

import "fmt"
import "flag"
import "strconv"
import "strings"
import "os"
import "log"
import "montnets/mwgate/smsutil"

var Logger *log.Logger

// 单条发送
func singleSend(userid string, pwd string, mobile string, content string) {

	fmt.Println("singleSend demo begin")
	// 将数据打包
	sendobj := smsutil.NewSingleSend(userid, pwd, mobile, content)
	// 发送数据
	smsutil.SendAndRecvOnce(sendobj)
}

// 相同内容群发
func batchSend(userid string, pwd string, mobiles string, content string) {

	fmt.Println("batchSend demo begin")
	// 将数据打包
	sendobj := smsutil.NewBatchSend(userid, pwd, mobiles, content)
	// 发送数据
	smsutil.SendAndRecvOnce(sendobj)
}

// 个性化群发
func multiSend(userid string, pwd string, mutli []smsutil.SMData) {
	fmt.Println("multiSend demo begin")

	// 将数据打包
	sendobj := smsutil.NewMultiSend(userid, pwd, mutli)
	// 发送数据
	smsutil.SendAndRecvOnce(sendobj)
}

func getMo(userid string, pwd string, retsize int) {
	fmt.Println("getMo demo begin")
	// 将数据打包
	sendobj := smsutil.NewGetMo(userid, pwd, retsize)
	// 发送数据
	smsutil.SendAndRecvOnce(sendobj)
}

func getRpt(userid string, pwd string, retsize int) {
	fmt.Println("getRpt demo begin")

	// 将数据打包
	sendobj := smsutil.NewGetRpt(userid, pwd, retsize)
	// 发送数据
	smsutil.SendAndRecvOnce(sendobj)
}

// 查询余额
func getBalance(userid string, pwd string) {
	fmt.Println("getBalance demo begin")

	// 将数据打包
	sendobj := smsutil.NewGetBalance(userid, pwd)
	// 发送数据
	smsutil.SendAndRecvOnce(sendobj)
}

// 查询剩余金额或条数
func getRemains(userid string, pwd string) {
	fmt.Println("getRemains demo begin")

	// 将数据打包
	sendobj := smsutil.NewGetBalance(userid, pwd)
	// 发送数据
	smsutil.SendAndRecvOnce(sendobj)
}

func main() {

	// 用户账号：长度最大6个字符，统一大写,如提交参数中包含apikey，
	// 则可以不用填写该参数及pwd，两种鉴权方式中只能选择一种方式来
	//userid := "E10FXA"
	userid := flag.String("u", "kuku6", "用户账号：长度最大6个字符，统一大写")

	// 用户密码：定长小写32位字符, 如提交参数中包含apikey，则可以
	// 不用填写该参数及userid，两种鉴权方式中只能选择一种方式来进
	// 行鉴权。
	// pwd := "rIkXe2"
	pwd := flag.String("p", "123456", "用户密码：定长小写32位字符")

	cmd := flag.String("c", "", "测试类型， single_send, batch_send, multi_send, get_mo, get_rpt, get_balance, get_remains")

	mainAddr := flag.String("mAddr", "api01.monyun.cn:7901", "主服务器地址<域名:端口>")
	bakAddr := flag.String("bAddr", "api01.monyun.cn:7901;api01.monyun.cn:7901;api01.monyun.cn:7901", "备用服务器地址<域名:端口;域名:端口> 最多支持三个")

	logName := flag.String("l", "./access.log", "输出日志文件名，默认为：./access.log")

	flag.Parse()

	address1 := ""
	address2 := ""
	address3 := ""

	bAddrs := strings.Split(*bakAddr, ";")
	for i, v := range bAddrs {
		switch {
		case 0 == i:
			address1 = v
		case 1 == i:
			address2 = v
		case 2 == i:
			address3 = v
		default:
		}
	}

	cm := smsutil.GetConfigManager()

	ret := cm.SetIpInfo(*mainAddr, address1, address2, address3)
	if 0 != ret {
		fmt.Println("ConfigManager.SetIpInfo failed, ", string(smsutil.PkgToJson(cm)[:]), ret)
	}

	file, err := os.OpenFile(*logName, os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalln("fail to create ", *logName, "file!")
	}
	smsutil.Logger = log.New(file, "", log.LstdFlags)
	params := flag.Args()

	switch {
	case "single_send" == *cmd: // 单条发送
		if len(params) != 2 {
			fmt.Println("参数错误，格式为：<mobile><content>")
		}
		singleSend(*userid, *pwd, params[0], params[1])
	case "batch_send" == *cmd: // 相同内容群发
		if len(params) != 2 {
			fmt.Println("参数错误，格式为：<moblies><content>")
		}
		batchSend(*userid, *pwd, params[0], params[1])
	case "multi_send" == *cmd: // 个性化群发
		if len(params) < 2 || 0 != len(params)%2 {
			fmt.Println("参数错误，格式为：<mobile><content><mobile><content>...")
		}
		mutli := make([]smsutil.SMData, 0)
		mobile := ""
		content := ""
		for i, v := range params {
			if 0 == i%2 {
				mobile = v
			} else {
				content = v
				mutli = append(mutli, *smsutil.NewSMData(mobile, content))
			}
		}
		multiSend(*userid, *pwd, mutli)
	case "get_mo" == *cmd: // 获取MO。
		if len(params) > 1 {
			fmt.Println("参数错误，格式为：<resize>")
		}
		resize := 200
		if nil != params {
			s, err := strconv.Atoi(params[0])
			if nil != err {
				s = 200
			}
			resize = s
		}
		getMo(*userid, *pwd, resize)
	case "get_rpt" == *cmd: // 获取rpt
		if len(params) > 1 {
			fmt.Println("参数错误，格式为：<resize>")
		}
		resize := 500
		if nil != params {
			re, err := strconv.Atoi(params[0])
			if nil != err {
				resize = 500
			}
			resize = re
		}
		getRpt(*userid, *pwd, resize)
	case "get_balance" == *cmd: // 查询余额
		getBalance(*userid, *pwd)
	case "get_remains" == *cmd: // 查询剩余金额或条数
		getRemains(*userid, *pwd)
	default:
		fmt.Println("未能识别的命令")
	}

	// mobile := "158xxxxxxxx"

	// content := "验证码：6666，打死都不要告诉别人哦。"

	// //主IP信息  必填
	// masterIpAddress := "api01.monyun.cn:7901"

	// //备IP1  选填
	// ipAddress1 := "api01.monyun.cn:7901"

	// //备IP2  选填
	// ipAddress2 := "api01.monyun.cn:7901"

	// //备IP3  选填
	// ipAddress3 := "api01.monyun.cn:7901"

	// cm := smsutil.GetConfigManager()

	// ret := cm.SetIpInfo(masterIpAddress, ipAddress1, ipAddress2, ipAddress3)
	// if 0 != ret {
	// 	fmt.Println("ConfigManager.SetIpInfo failed, ", string(smsutil.PkgToJson(cm)[:]), ret)
	// }

	// // 单条发送
	// singleSend(userid, pwd, mobile, content)
	// // 相同内容群发
	// mobile = "158xxxxxxxx,158xxxxxxxx"
	// batchSend(userid, pwd, mobile, content)
	// // 个性化群发
	// mobile1 := "158xxxxxxxx"
	// content1 := "您登录系统的动态码为：54321 ，动态码有效时间为60 ，请注意保密。"
	// mutli := make([]smsutil.SMData, 0)
	// mutli = append(mutli, *smsutil.NewSMData(mobile, content), *smsutil.NewSMData(mobile1, content1))
	// multiSend(userid, pwd, mutli)

	// // 查询余额
	// getBalance(userid, pwd)
	// // 查询剩余金额或条数
	// getRemains(userid, pwd)
	// // 每次请求想要获取的上行的最大条数。
	// getMo(userid, pwd, 200)
	// //retsizeMo := 100
	// //运行获取上行状态报告协程
	// getRpt(userid, pwd, 200)
	// //清除所有IP (此处为清除IP示例代码，如果需要修改IP，请先清除IP，再设置IP)
	cm.RemoveAllIpInfo()
}

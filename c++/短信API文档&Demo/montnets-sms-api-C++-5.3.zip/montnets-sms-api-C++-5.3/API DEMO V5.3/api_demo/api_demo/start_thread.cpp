
#include "get_mo.h"
#include "get_rpt.h"
#ifdef WIN32
#include <process.h>
#elif defined LINUX
#include <pthread.h>
#include <unistd.h>
#endif

#ifdef WIN32
unsigned int WINAPI thread_get_mo(void *p)
{
	HttpClient *httpClient = (HttpClient *)p;

	while (true)
	{
		//get_mo(*httpClient); // ��ȡ��������
		Sleep(2000);
	}

	return 0;
}

unsigned int WINAPI thread_get_rpt(void *p)
{
	HttpClient *httpClient = (HttpClient *)p;

	while (true)
	{
		//get_rpt(*httpClient); // ��ȡ����״̬����
		Sleep(2000);
	}

	return 0;
}

#elif defined LINUX
void *thread_get_mo(void *p)
{
	HttpClient *httpClient = (HttpClient *)p;

	while (true)
	{
		get_mo(*httpClient); // ��ȡ��������
		sleep(2);
	}

	return 0;
}

void *thread_get_rpt(void *p)
{
	HttpClient *httpClient = (HttpClient *)p;

	while (true)
	{
		get_rpt(*httpClient); // ��ȡ����״̬����
		sleep(2);
	}

	return 0;
}
#endif

void start_thread(HttpClient &httpClient)
{
#ifdef WIN32
	HANDLE handle1 = (HANDLE)_beginthreadex(NULL, 0, thread_get_mo, &httpClient, 0, NULL);
	//HANDLE handle2 = (HANDLE)_beginthreadex(NULL, 0, thread_get_rpt, &httpClient, 0, NULL);
	WaitForSingleObject(handle1, INFINITE);
	//WaitForSingleObject(handle2, INFINITE);
#elif defined LINUX
	::pthread_t thread1, thread2;
	pthread_create(&thread1, 0, thread_get_mo, &httpClient);
	pthread_create(&thread2, 0, thread_get_rpt, &httpClient);
	pthread_join(thread1, 0);
	pthread_join(thread2, 0);
#endif
}
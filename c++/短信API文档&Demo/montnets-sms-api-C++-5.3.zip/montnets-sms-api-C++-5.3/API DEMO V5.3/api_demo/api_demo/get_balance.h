#ifndef GET_BALANCE_H
#define GET_BALANCE_H

#include "HttpClient.h"

int get_balance(HttpClient &httpClient, std::string userid, std::string pwd);
std::string URLEncodeDirect(const char *pInBuf);

#endif
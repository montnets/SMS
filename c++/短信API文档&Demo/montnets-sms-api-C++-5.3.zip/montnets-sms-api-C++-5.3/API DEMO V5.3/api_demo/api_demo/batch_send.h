#ifndef BATCH_SEND_H
#define BATCH_SEND_H

#include "HttpClient.h"

int batch_send(HttpClient &httpClient, std::string userid, std::string pwd, std::string mobile, std::string content);
std::string URLEncodeDirect(const char *pInBuf);

#endif
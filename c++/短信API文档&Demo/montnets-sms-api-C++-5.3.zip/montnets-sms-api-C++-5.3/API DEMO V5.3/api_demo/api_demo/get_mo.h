#ifndef GET_MO_H
#define GET_MO_H

#include "HttpClient.h"

int get_mo(HttpClient &httpClient, std::string userid, std::string pwd);
std::string URLEncodeDirect(const char *pInBuf);

#endif
#ifndef WIN_MUTEX_H
#define WIN_MUTEX_H

#if defined(WIN32)

#include <windows.h>
#include "scoped_lock.h"

class win_mutex
{
public:
	typedef ::scoped_lock<win_mutex> scoped_lock;

	win_mutex()
	{
		::InitializeCriticalSection(&crit_section_);
	}

	~win_mutex()
	{
		::DeleteCriticalSection(&crit_section_);
	}

public:
	void lock()
	{
		::EnterCriticalSection(&crit_section_);
	}

	void unlock()
	{
		::LeaveCriticalSection(&crit_section_);
	}

private:
	::CRITICAL_SECTION crit_section_;
};

#endif

#endif
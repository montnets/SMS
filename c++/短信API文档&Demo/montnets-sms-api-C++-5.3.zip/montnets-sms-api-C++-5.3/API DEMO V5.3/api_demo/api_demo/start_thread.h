#ifndef START_THREAD_H
#define START_THREAD_H

#include "HttpClient.h"

void start_thread(HttpClient &);

#endif

#include "multi_send.h"
#include <json/json.h>
#include <stdio.h>
#include "md5.h"
#include <algorithm>
#include "tinyxml/tinyxml.h"
#include <time.h>

int multi_send(HttpClient &httpClient, std::string userid, std::string pwd, std::string mobile1, std::string mobile2, std::string content)
{
#ifdef JSON
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/json";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	//std::string userid = "E10FXA";
	std::string tmp = userid;
	//std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	Json::Value root;
	root["userid"] = userid;
	root["pwd"] = md5;
	root["timestamp"] = timestamp;

	Json::Value item;
	item["mobile"] = mobile1;
	item["content"] = URLEncodeDirect(content.c_str());
	item["svrtype"] = "SMS001";
	item["exno"] = "0006";
	item["custid"] = "b3d0a2783d31b21b8573";
	item["exdata"] = "exdata000002";
	root.append(item);

	Json::Value item1;
	item1["mobile"] = mobile2;
	item1["content"] = URLEncodeDirect(content.c_str());
	item1["svrtype"] = "SMS002";
	item1["exno"] = "0007";
	item1["custid"] = "b3d0a2783d31b21b8573";
	item1["exdata"] = "exdata000002";
	root.append(item1);

	Json::FastWriter writer;
	std::string strBody = writer.write(root);

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	if (httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "multi_send", &nHttpRespCode) == 0)
	{
		printf("RespCode: %d\n", nHttpRespCode);
		printf("RespBdoy: %s\n", strHttpRespBody.c_str());
	}

	return 0;

#elif defined XML
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/xml";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	std::string userid = "E10FXA";
	std::string tmp = userid;
	std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	TiXmlElement *pRootElement = new TiXmlElement("mtreq");

	TiXmlElement *pElement1 = new TiXmlElement("userid");
	TiXmlElement *pElement2 = new TiXmlElement("pwd");
	TiXmlElement *pElement3 = new TiXmlElement("timestamp");
	pRootElement->LinkEndChild(pElement1);
	pRootElement->LinkEndChild(pElement2);
	pRootElement->LinkEndChild(pElement3);

	TiXmlText *pText1 = new TiXmlText(userid.c_str());
	pElement1->InsertEndChild(*pText1);

	TiXmlText *pText2 = new TiXmlText(md5.c_str());
	pElement2->InsertEndChild(*pText2);

	TiXmlText *pText3 = new TiXmlText(timestamp);
	pElement3->InsertEndChild(*pText3);

	// ---------------------------------------------------------------------------------------
	TiXmlElement *pMultimt = new TiXmlElement("multimt");
	pRootElement->LinkEndChild(pMultimt);

	TiXmlElement *pMt = new TiXmlElement("mt");
	pMultimt->LinkEndChild(pMt);
	TiXmlElement *pElement11 = new TiXmlElement("mobile");
	TiXmlElement *pElement12 = new TiXmlElement("content");
	TiXmlElement *pElement13 = new TiXmlElement("svrtype");
	TiXmlElement *pElement14 = new TiXmlElement("exno");
	TiXmlElement *pElement15 = new TiXmlElement("custid");
	TiXmlElement *pElement16 = new TiXmlElement("exdata");
	pMt->LinkEndChild(pElement11);
	pMt->LinkEndChild(pElement12);
	pMt->LinkEndChild(pElement13);
	pMt->LinkEndChild(pElement14);
	pMt->LinkEndChild(pElement15);
	pMt->LinkEndChild(pElement16);

	TiXmlText *pText11 = new TiXmlText("13169924946");
	pElement11->InsertEndChild(*pText11);
	TiXmlText *pText12 = new TiXmlText(URLEncodeDirect("��¼��֤�룺hello world����Ǳ��˲���������Դ˶��š�").c_str());
	pElement12->InsertEndChild(*pText12);
	TiXmlText *pText13 = new TiXmlText("SMS001");
	pElement13->InsertEndChild(*pText13);
	TiXmlText *pText14 = new TiXmlText("0006");
	pElement14->InsertEndChild(*pText14);
	TiXmlText *pText15 = new TiXmlText("b3d0a2783d31b21b8573");
	pElement15->InsertEndChild(*pText15);
	TiXmlText *pText16 = new TiXmlText("exdata000002");
	pElement16->InsertEndChild(*pText16);

	// ---------------------------------------------------------------------------------------
	TiXmlElement *pMt1 = new TiXmlElement("mt");
	pMultimt->LinkEndChild(pMt1);
	TiXmlElement *pElement21 = new TiXmlElement("mobile");
	TiXmlElement *pElement22 = new TiXmlElement("content");
	TiXmlElement *pElement23 = new TiXmlElement("svrtype");
	TiXmlElement *pElement24 = new TiXmlElement("exno");
	TiXmlElement *pElement25 = new TiXmlElement("custid");
	TiXmlElement *pElement26 = new TiXmlElement("exdata");
	pMt1->LinkEndChild(pElement21);
	pMt1->LinkEndChild(pElement22);
	pMt1->LinkEndChild(pElement23);
	pMt1->LinkEndChild(pElement24);
	pMt1->LinkEndChild(pElement25);
	pMt1->LinkEndChild(pElement26);

	TiXmlText *pText21 = new TiXmlText("13726256729");
	pElement21->InsertEndChild(*pText21);
	TiXmlText *pText22 = new TiXmlText(URLEncodeDirect("��֤�룺hello world����������Ҫ���߱���Ŷ��").c_str());
	pElement22->InsertEndChild(*pText22);
	TiXmlText *pText23 = new TiXmlText("SMS002");
	pElement23->InsertEndChild(*pText23);
	TiXmlText *pText24 = new TiXmlText("0007");
	pElement24->InsertEndChild(*pText24);
	TiXmlText *pText25 = new TiXmlText("b3d0a2783d31b21b8573");
	pElement25->InsertEndChild(*pText25);
	TiXmlText *pText26 = new TiXmlText("exdata000002");
	pElement26->InsertEndChild(*pText26);

	TiXmlPrinter printer;
	pRootElement->Accept(&printer);
	std::string strBody = printer.CStr();

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	return httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "multi_send", &nHttpRespCode);

#elif defined URLENCODE
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/x-www-form-urlencoded";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	std::string userid = "E10FXA";
	std::string tmp = userid;
	std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	Json::Value root;
	Json::Value item;
	item["mobile"] = "13169924946";
	item["content"] = URLEncodeDirect("��¼��֤�룺hello world����Ǳ��˲���������Դ˶��š�");
	item["svrtype"] = "SMS001";
	item["exno"] = "0006";
	item["custid"] = "b3d0a2783d31b21b8573";
	item["exdata"] = "exdata000002";
	root.append(item);

	Json::Value item1;
	item1["mobile"] = "13726256729";
	item1["content"] = URLEncodeDirect("��������Ʒ�������ڣ��뾡�츶�����֧������ԣ�лл��");
	item1["svrtype"] = "SMS002";
	item1["exno"] = "0007";
	item1["custid"] = "b3d0a2783d31b21b8573";
	item1["exdata"] = "exdata000002";
	root.append(item1);
	Json::FastWriter writer;

	std::string strBody = "userid=";
	strBody += userid;
	strBody += "&pwd=";
	strBody += md5;
	strBody += "&timestamp=";
	strBody += timestamp;
	strBody += "&multimt=";
	strBody += writer.write(root);

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	return httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "multi_send", &nHttpRespCode);
#else
#error you must define either JSON, XML or URLENCODE!
#endif
}

#include "HttpClient.h"
#include <assert.h>

HttpClient::HttpClient()
{
	//assert(curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK);

	m_nConnectTimeout = 20;
	m_nReceiveTimeout = 120;
}

HttpClient::~HttpClient()
{
	//curl_global_cleanup();
}

CURL *HttpClient::getLink(bool bPost)
{
	CURL *link = NULL;
	{
		mutex::scoped_lock lock(mutex_);
		if (m_listLink.size())
		{
			link = m_listLink.back();
			m_listLink.pop_back();
		}
	}

	if (!link)
		link = createLink(bPost);

	return link;
}

static size_t onWriteData(void *buffer, size_t size, size_t nmemb, void *p)
{
	((std::string *)p)->append((const char *)buffer, size * nmemb);
	return nmemb;
}

CURL *HttpClient::createLink(bool bPost)
{
	CURLcode res = CURLE_FAILED_INIT;
	CURL* curl = curl_easy_init();

	do
	{
		if (NULL == curl)
			break;

		//ʹ��POST����
		if (bPost)
		{
			res = curl_easy_setopt(curl, CURLOPT_POST, 1);
			if (CURLE_OK != res)
				break;
		}
		else
		{
			res = curl_easy_setopt(curl, CURLOPT_HTTPGET, 1);
			if (CURLE_OK != res)
				break;
		}



		res = curl_easy_setopt(curl, CURLOPT_READFUNCTION, NULL);
		if (CURLE_OK != res)
			break;

		res = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, onWriteData);
		if (CURLE_OK != res)
			break;


		res = curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1);
		if (CURLE_OK != res)
			break;

		res = curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, m_nConnectTimeout);
		if (CURLE_OK != res)
			break;

		res = curl_easy_setopt(curl, CURLOPT_TIMEOUT, m_nReceiveTimeout);
		if (CURLE_OK != res)
			break;

	} while (0);

	if (CURLE_OK != res && NULL != curl)
	{
		curl_easy_cleanup(curl);
		curl = NULL;
	}

	return curl;
}

void HttpClient::freeLink(CURL *curl)
{
	if (curl)
	{
		mutex::scoped_lock lock(mutex_);
		m_listLink.push_back(curl);
	}
}

bool HttpClient::init(const char *url)
{
	m_strUrl = url;
	return true;
}

int HttpClient::postHttpRequest(const char *arrHeadLines[], size_t nHeadLines, const std::string &strBody, std::string &strHttpRespBody, const char *param, int *statusCode)
{
	CURLcode res;
	CURL* curl = getLink();
	if (NULL == curl)
	{
		return -1; // lv
	}

	struct curl_slist *headers = NULL;
	for (size_t n = 0; n<nHeadLines; ++n)
	{
		headers = curl_slist_append(headers, arrHeadLines[n]);
	}


	std::string  strUrl(m_strUrl);
	if (param && *param)
	{
		strUrl += param;
	}

	res = curl_easy_setopt(curl, CURLOPT_URL, strUrl.c_str());
	assert(CURLE_OK == res);

	res = curl_easy_setopt(curl, CURLOPT_POST, 1);
	assert(CURLE_OK == res);


	if (headers)
	{
		/* set the size of the postfields data */
		size_t nsize = strBody.size();
		res = curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, nsize);
		assert(CURLE_OK == res);
	}
	res = curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
	assert(CURLE_OK == res);

	res = curl_easy_setopt(curl, CURLOPT_POSTFIELDS, strBody.c_str());
	assert(CURLE_OK == res);


	res = curl_easy_setopt(curl, CURLOPT_WRITEDATA, &strHttpRespBody);
	assert(CURLE_OK == res);


	res = curl_easy_perform(curl);
	if (CURLE_OK == res)
	{
		long retcode = 0;
		res = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &retcode);
		if (statusCode)
		{
			*statusCode = retcode;
		}
	}

	if (headers)
	{
		curl_slist_free_all(headers);
	}

	freeLink(curl);

	if (CURLE_OK != res)
	{
		strHttpRespBody = curl_easy_strerror(res);
		return -1; // lv
	}

	/*
	if (nSpan >= 10*1000)
	{
	char szLogMsg[64];
	CSmsTools::WriteLogMsg(szLogMsg, sprintf(szLogMsg, "�����Ӧ����ﵽ��%u��\r\n", nSpan/1000), CSmsTools::LOG_LEVEL_ERROR);
	}*/


	return res;
}
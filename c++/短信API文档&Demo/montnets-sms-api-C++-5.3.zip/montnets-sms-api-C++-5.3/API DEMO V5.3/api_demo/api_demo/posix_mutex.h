#ifndef POSIX_MUTEX_H
#define POSIX_MUTEX_H

#if defined(LINUX)

#include <pthread.h>
#include "scoped_lock.h"

class posix_mutex
{
public:
	typedef ::scoped_lock<posix_mutex> scoped_lock;

	posix_mutex()
	{
		::pthread_mutex_init(&mutex_, 0);
	}

	~posix_mutex()
	{
		::pthread_mutex_destroy(&mutex_);
	}

public:
	void lock()
	{
		::pthread_mutex_lock(&mutex_);
	}

	void unlock()
	{
		::pthread_mutex_unlock(&mutex_);
	}

private:
	::pthread_mutex_t mutex_;
};

#endif

#endif
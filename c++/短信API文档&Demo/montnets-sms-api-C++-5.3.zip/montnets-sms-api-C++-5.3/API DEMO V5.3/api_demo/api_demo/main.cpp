
#include "HttpClient.h"
#include "./libcurl/curl/curl.h"
#include <assert.h>

#include "single_send.h"
#include "batch_send.h"
#include "multi_send.h"
#include "get_mo.h"
#include "get_rpt.h"
#include "get_balance.h"
#include "start_thread.h"
#include "template_send.h"

int main(int argc, char *argv[])
{
	assert(curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK);

	HttpClient httpClient;
	httpClient.init(argv[1]); // ����

	if (strcmp(argv[2], "single_send") == 0)
		single_send(httpClient, argv[3], argv[4], argv[5], argv[6]);
	else if (strcmp(argv[2], "batch_send") == 0)
		batch_send(httpClient, argv[3], argv[4], argv[5], argv[6]);
	else if (strcmp(argv[2], "multi_send") == 0)
		multi_send(httpClient, argv[3], argv[4], argv[5], argv[6], argv[7]);
	else if (strcmp(argv[2], "get_balance") == 0)
		get_balance(httpClient, argv[3], argv[4]);
	else if (strcmp(argv[2], "get_mo") == 0)
		get_mo(httpClient, argv[3], argv[4]);
	else if (strcmp(argv[2], "get_rpt") == 0)
		get_rpt(httpClient, argv[3], argv[4]);

	getchar();

	/*HttpClient httpClient1;
	httpClient1.init("http://api01.monyun.cn:7901/voice/v2/std/");*/
	//template_send(httpClient1);
	//get_rpt(httpClient1);
	//get_balance(httpClient1);

	/*HttpClient httpClient;
	httpClient.init("http://api01.monyun.cn:7901/sms/v2/std/");*/

	//single_send(httpClient);
	//batch_send(httpClient);
	//multi_send(httpClient);
	//get_balance(httpClient); // ��ѯ���
	//start_thread(httpClient);

	curl_global_cleanup();
}
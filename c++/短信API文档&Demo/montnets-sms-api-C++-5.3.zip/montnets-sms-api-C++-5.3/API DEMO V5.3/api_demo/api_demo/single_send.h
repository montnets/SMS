#ifndef SINGLE_SEND_H
#define SINGLE_SEND_H

#include "HttpClient.h"

int single_send(HttpClient &httpClient, std::string userid, std::string pwd, std::string mobile, std::string content);
std::string URLEncodeDirect(const char *pInBuf);

#endif
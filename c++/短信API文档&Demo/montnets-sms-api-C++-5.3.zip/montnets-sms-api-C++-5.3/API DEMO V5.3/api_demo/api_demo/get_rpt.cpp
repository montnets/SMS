
#include "get_rpt.h"
#include <json/json.h>
#include <stdio.h>
#include "md5.h"
#include <algorithm>
#include "tinyxml/tinyxml.h"
#include <time.h>

int get_rpt(HttpClient &httpClient, std::string userid, std::string pwd)
{
#ifdef JSON
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/json";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	//std::string userid = "E10FXA";
	std::string tmp = userid;
	//std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	Json::Value item;
	item["userid"] = userid;
	item["pwd"] = md5;
	item["timestamp"] = timestamp;
	item["retsize"] = 300;
	Json::FastWriter writer;
	std::string strBody = writer.write(item);

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	if (httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "get_rpt", &nHttpRespCode) == 0)
	{
		printf("RespCode: %d\n", nHttpRespCode);
		printf("RespBdoy: %s\n", strHttpRespBody.c_str());
	}

	return 0;

#elif defined XML
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/xml";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	std::string userid = "E10FXA";
	std::string tmp = userid;
	std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	TiXmlElement *pRootElement = new TiXmlElement("mtreq");
	TiXmlElement *pElement1 = new TiXmlElement("userid");
	TiXmlElement *pElement2 = new TiXmlElement("pwd");
	TiXmlElement *pElement3 = new TiXmlElement("timestamp");
	TiXmlElement *pElement4 = new TiXmlElement("retsize");
	pRootElement->LinkEndChild(pElement1);
	pRootElement->LinkEndChild(pElement2);
	pRootElement->LinkEndChild(pElement3);
	pRootElement->LinkEndChild(pElement4);

	TiXmlText *pText1 = new TiXmlText(userid.c_str());
	pElement1->InsertEndChild(*pText1);

	TiXmlText *pText2 = new TiXmlText(md5.c_str());
	pElement2->InsertEndChild(*pText2);

	TiXmlText *pText3 = new TiXmlText(timestamp);
	pElement3->InsertEndChild(*pText3);

	TiXmlText *pText4 = new TiXmlText("300");
	pElement4->InsertEndChild(*pText4);

	TiXmlPrinter printer;
	pRootElement->Accept(&printer);
	std::string strBody = printer.CStr();

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	return httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "get_rpt", &nHttpRespCode);

#elif defined URLENCODE
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/x-www-form-urlencoded";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	std::string userid = "E10FXA";
	std::string tmp = userid;
	std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	std::string strBody = "userid=";
	strBody += userid;
	strBody += "&pwd=";
	strBody += md5;
	strBody += "&timestamp=";
	strBody += timestamp;
	strBody += "&retsize=300";

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	return httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "get_rpt", &nHttpRespCode);
#else
#error you must define either JSON, XML or URLENCODE!
#endif
}
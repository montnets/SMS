#ifndef HTTP_CLIENT_H
#define HTTP_CLIENT_H

#include "./libcurl/curl/curl.h"
#include <list>
#include "mutex.h"
#include <string>

class HttpClient
{
private:
	std::list<CURL *> m_listLink;
	std::string m_strUrl;
	int m_nConnectTimeout;
	int m_nReceiveTimeout;

	mutex mutex_;

public:
	HttpClient();
	virtual ~HttpClient();

private:
	CURL *getLink(bool bPost = true);
	CURL *createLink(bool bPost = true);
	void freeLink(CURL *curl);

public:
	bool init(const char *url);
	int postHttpRequest(const char *arrHeadLines[], size_t nHeadLines, const std::string &strBody, std::string &strHttpRespBody, const char *param = NULL, int *statusCode = NULL);
};

#endif
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace Test.XML {
    class XMLMessageTemplate {


        /// <summary>
        /// 封装报文
        /// </summary>
        /// <param name="sendType"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static string getContentString(int sendType, Message message, int authenticationMode) {
            if (sendType == 1)
                return getSingleContentString(message, authenticationMode);
            else if (sendType == 2)
                return getBatchContentString(message, authenticationMode);
            else if (sendType == 3)
                return getMultiMtContentString(message, authenticationMode);
            else if (sendType == 4)
                return getMoContentString(message, authenticationMode);
            else if (sendType == 5)
                return getRptContentString(message, authenticationMode);
            else if (sendType == 6)
                return getBalanceContentString(message, authenticationMode);

            return null;
        }
        /// <summary>
        /// 获取相同内群发封装UrlContent数据
        /// userid=kuke33&pwd=26dad7f364507df18f3841cc9c4ff94d&mobile=13800138000,13000130000,18000180000&content=%b2%e2%ca%d4%b6%cc%d0%c5&timestamp=0803192020&exno=0006&custid=b3d0a2783d31b21b8573&exdata=exdata000002
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private static string getSingleContentString(Message message, int authenticationMode) {
            string contents = null;
            if (authenticationMode == 0) {
                contents = string.Format(TMP_SEND_CONTENT_XML_NORMAL,
                           message.UserId,
                           message.Pwd,
                           message.Mobile,
                           HttpUtility.UrlEncode(message.Content, Encoding.GetEncoding("GBK")),
                            message.TimeStamp,
                           (string.IsNullOrEmpty(message.SvrType) ? string.Empty : message.SvrType),
                           (string.IsNullOrEmpty(message.ExNo) ? string.Empty : message.ExNo),
                           (string.IsNullOrEmpty(message.CustId) ? string.Empty : message.CustId),
                           (string.IsNullOrEmpty(message.ExData) ? string.Empty : message.ExData));
            } else {
                contents = string.Format(  TMP_SEND_CONTENT_XML_APIKEY,
                      message.ApiKey,
                      message.Mobile,
                      HttpUtility.UrlEncode(message.Content, Encoding.GetEncoding("GBK")),
                      message.TimeStamp,
                    (string.IsNullOrEmpty(message.SvrType) ? string.Empty : message.SvrType),
                    (string.IsNullOrEmpty(message.ExNo) ? string.Empty : message.ExNo),
                    (string.IsNullOrEmpty(message.CustId) ? string.Empty : message.CustId),
                    (string.IsNullOrEmpty(message.ExData) ? string.Empty : message.ExData));
                 
                
            }
            return contents;
        }
        /// <summary>
        /// 获取相同内群发封装UrlContent数据
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private static string getBatchContentString(Message message, int authenticationMode) {
            return getSingleContentString(message, authenticationMode);
        }
        private static string getMultiMtContentString(Message message, int authenticationMode) {
            string contents = null;
            IList<MultiMt> list = message.Multimtes;
            StringBuilder sb = new StringBuilder();
            if (list != null && list.Count > 0) {
                foreach (MultiMt mt in list) {
                    sb.AppendFormat("<mt><mobile>{0}</mobile><content>{1}</content><svrtype>{2}</svrtype><exno>{3}</exno><custid>{4}</custid><exdata>{5}</exdata></mt>",
                        mt.mobile,
                        mt.content,
                        (string.IsNullOrEmpty(mt.svrtype) ? string.Empty : mt.svrtype),
                        (string.IsNullOrEmpty(mt.exno) ? string.Empty : mt.exno),
                        (string.IsNullOrEmpty(mt.custid) ? string.Empty : mt.custid),
                        (string.IsNullOrEmpty(mt.exdata) ? string.Empty : mt.exdata));
                }
            }
            if (authenticationMode == 0) {
                contents = string.Format(TMP_MULT_CONTENT_XML_NORMAL,
                                message.UserId,
                                message.Pwd,
                                message.TimeStamp,
                               sb.ToString());
            } else {
                contents = string.Format( TMP_MULT_CONTENT_XML_APIKEY,
                          message.ApiKey,
                          message.TimeStamp,
                              sb.ToString());
            }

            return contents;
        }


        private static string getMoContentString(Message message, int authenticationMode) {
            string contents = null;

            if (authenticationMode == 0) {
                contents = string.Format(TMP_MO_XML_NORMAL,
                                     message.UserId,
                                     message.Pwd,
                                     message.TimeStamp,
                                     message.RetSize);
            } else {
                contents = string.Format( TMP_MO_XML_APIKEY,
                       message.ApiKey,
                        message.TimeStamp,
                        message.RetSize);
            }

            return contents;
        }

        private static string getRptContentString(Message message, int authenticationMode) {
            string contents = null;

            if (authenticationMode == 0) {
                contents = string.Format(TMP_RPT_XML_NORMAL,
                                     message.UserId,
                                     message.Pwd,
                                     message.TimeStamp,
                                     message.RetSize);
            } else {
                contents = string.Format( TMP_RPT_XML_APIKEY,
                       message.ApiKey,
                        message.TimeStamp,
                        message.RetSize);
            }

            return contents;
        }

        private static string getBalanceContentString(Message message, int authenticationMode) {
            string contents = null;
            if (authenticationMode == 0) {
                contents = string.Format(TMP_BALANCE_XML_NORMAL,
                     message.UserId,
                     message.Pwd,
                     message.TimeStamp);
            } else {
                contents = string.Format(TMP_BALANCE_XML_APIKEY,
                       message.ApiKey,
                       message.TimeStamp);
            }

            return contents;
        }


        #region 发送报文模板
       
        /// <summary>
        /// 发送报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_SEND_CONTENT_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\"?><mtreq><userid>{0}</userid><pwd>{1}</pwd><mobile>{2}</mobile><content>{3}</content><timestamp>{4}</timestamp><svrtype>{5}</svrtype><exno>{6}</exno><custid>{7}</custid><exdata>{8}</exdata></mtreq>";

        /// <summary>
        /// 发送报文XML， APIKEY鉴权模板 
        /// </summary>
        public const string TMP_SEND_CONTENT_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\"?><mtreq><apikey>{0}</userid><mobile>{1}</mobile><content>{2}</content><timestamp>{3}</timestamp><svrtype>{4}</svrtype><exno>{5}</exno><custid>{6}</custid><exdata>{7}</exdata></mtreq>";


        #endregion

        #region 个性发送报文模板
      
        /// <summary>
        /// 个性发送报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_MULT_CONTENT_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><mtreq>	<userid>{0}</userid><pwd>{1}</pwd><timestamp>{2}</timestamp><multimt>{3}</multimt></mtreq>";

        /// <summary>
        /// 个性发送报文XML，APIKEY鉴权模板 
        /// </summary>
        public const string TMP_MULT_CONTENT_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><mtreq>	<apikey>{0}</apikey> <timestamp>{1}</timestamp><multimt>{2}</multimt></mtreq>";
        #endregion

        #region 获取上行报文模板
       
        /// <summary>
        /// 获取上行报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_MO_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><moreq>	<userid>{0}</userid><pwd>{1}</pwd><timestamp>{2}</timestamp><retsize>{3}</retsize></moreq>";

        /// <summary>
        /// 获取上行报文XML，APIKEY鉴权模板 
        /// </summary>
        public const string TMP_MO_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><moreq>	<apikey>{0}</apikey> <timestamp>{1}</timestamp><retsize>{2}</retsize></moreq>";
        #endregion

        #region 获取RPT报文模板
      
        /// <summary>
        /// 获取RPT报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_RPT_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><rptreq>	<userid>{0}</userid><pwd>{1}</pwd><timestamp>{2}</timestamp><retsize>{3}</retsize></rptreq>";

        /// <summary>
        /// 获取RPT报文XML，APIKEY鉴权模板 
        /// </summary>
        public const string TMP_RPT_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><rptreq>	<apikey>{0}</apikey> <timestamp>{1}</timestamp><retsize>{2}</retsize></rptreq>";

        #endregion

        #region 获取查询余额报文模板
      
        /// <summary>
        /// 获取查询余额报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_BALANCE_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><feereq>	<userid>{0}</userid><pwd>{1}</pwd><timestamp>{2}</timestamp></feereq>";

        /// <summary>
        /// 获取查询余额报文XML，APIKEY鉴权模板 
        /// </summary>
        public const string TMP_BALANCE_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><feereq>	<apikey>{0}</apikey> <timestamp>{1}</timestamp></feereq>";

        #endregion

    }
}

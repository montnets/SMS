﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.isms {
    public  interface ISMS {
         string execute(Message message, int sendType, string IpAndPort, int authenticationMode, bool bKeepAlive);
    }
}

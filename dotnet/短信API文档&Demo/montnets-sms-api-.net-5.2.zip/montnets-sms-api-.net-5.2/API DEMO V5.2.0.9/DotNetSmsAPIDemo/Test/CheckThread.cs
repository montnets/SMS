﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using Test.UrlEncode;

namespace Test {
    public class CheckThread {
        /// <summary>
        /// 写日志类
        /// </summary>
        private static log4net.ILog log = log4net.LogManager.GetLogger(typeof(CheckThread));
        //请求路径
        public const String requestPath = "/sms/v2/std/";
        /// <summary>
        /// 线程状态
        /// </summary>
        private static bool THREADSTATUS = false;
        /// <summary>
        /// 当前对象
        /// </summary>
        private static CheckThread service = null;

        /// <summary>
        /// 获得单件实例CheckAccountService
        /// </summary>
        /// <returns></returns>
        public static CheckThread getInstance() {
            if (service == null)
                service = new CheckThread();
            return service;
        }

        /// <summary>
        /// 停止
        /// </summary>
        public void stop() {
            THREADSTATUS = false;
        }
        public void start() {
            if (THREADSTATUS) {
                return;
            }
            THREADSTATUS = true;

            AutoResetEvent reseEvent = new AutoResetEvent(false);
            TaskThread task = new TaskThread();
            task.Description = "检测账号IP线程";
            task.Handle = ThreadPool.RegisterWaitForSingleObject(
                reseEvent,
                new WaitOrTimerCallback(waitProcCheck),
                task,
                100,
                false
                );
            Thread.Sleep(10);
            reseEvent.Set();
        }

        /// <summary>
        /// 解析域名
        /// </summary>
        /// <param name="domainName"></param>
        /// <returns></returns>
        private static string getIpByDomainName(String domainName) {
            try {
                IPHostEntry hostinfo = Dns.GetHostByName(domainName);//www.baidu.com
                IPAddress[] array = hostinfo.AddressList;
                return array[0].ToString();
            } catch (Exception ex) {
                log.ErrorFormat(@"解析域名（{0}）是发生错误，Error:{1}", domainName, ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 检测账号IP是否可用
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public int checkAddressAvailable(Account account, string ipport) {
            int result = 6;
            try {
                Message message = new Message();
                message.UserId = account.UserId.ToUpper();
                message.Pwd = account.PassWord;
                string url = string.Format("http://{0}{1}{2}", ((ipport == null) ? account.IpAndPort : ipport), requestPath, "get_balance");
                string contents = string.Format("userId={0}&password={1}",
                    message.UserId,
                    message.Pwd
                    );

                  httpPost(url, contents, false); 
                return 0;
            } catch (Exception ex) {
                log.ErrorFormat(@"获取账号余额时发生错误，userid:{0},Error:{1}", account.UserId, ex.Message);
                return result;
            }
        }

        private string httpPost(string uri, string contents, bool bKeepAlive) {
            //创建一个Http请求
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            //设置请求的方法。
            request.Method = "POST";
            //设置 Content-typeHTTP 标头的值。
            request.ContentType = "application/x-www-form-urlencoded";
            //请求所包含的 Connection HTTP 标头带有 Keep-alive 这一值，则为 true；否则为 false。默认值为  true。
            request.KeepAlive = bKeepAlive;
            //转为UTF-8
            byte[] bytes = Encoding.GetEncoding("utf-8").GetBytes(contents);
            //设置 Content-lengthHTTP 标头。
            request.ContentLength = bytes.Length;
            // 获取用于写入请求数据的 System.IO.Stream 对象。
            Stream os = request.GetRequestStream();
            os.Write(bytes, 0, bytes.Length);
            os.Close();
            //提供来自统一资源标识符 (URI) 的响应       
            System.Net.WebResponse response = request.GetResponse();
            if (response == null)
                return String.Empty;

            using (StreamReader sr = new StreamReader(response.GetResponseStream())) {
                //从流的当前位置到末尾读取流。
                return sr.ReadToEnd().Trim();
            }
        }

        public void waitProcCheck(object state, bool timeout) {
            TaskThread task = (TaskThread)state;
            if (!timeout) {
                try {
                    while (THREADSTATUS) {
                        try {
                            Account account = Account.getInstance();
                            if (account.MasterIPState == 1) {
                                //判断是否是用域名，如果是域名要重新获取IP
                                if (string.IsNullOrEmpty(account.Ip) || !string.IsNullOrEmpty(account.DomainName)) {
                                    string ip = getIpByDomainName(account.DomainName);
                                    if (!string.IsNullOrEmpty(ip)) {
                                        account.Ip = ip;
                                    }
                                }
                                int result = checkAddressAvailable(account, null);
                                if (result == 0)
                                    account.MasterIPState = 0;
                            }
                            IList<IpAddress> iaList = account.getIpAndPortBak();
                            if (iaList != null && iaList.Count > 0) {
                                // 循环检测备用IP是否可用
                                foreach (IpAddress ia in iaList) {
                                    //判断是否是用域名，如果是域名要重新获取IP
                                    if (string.IsNullOrEmpty(ia.Ip) || !string.IsNullOrEmpty(ia.DomainName)) {
                                        string ip = getIpByDomainName(ia.DomainName);
                                        if (!string.IsNullOrEmpty(ip)) {
                                            ia.Ip = ip;
                                        }
                                    }
                                    string ipport = ia.IpAndPort;
                                    if (!string.IsNullOrEmpty(ipport)) {
                                        // 调用查询余额的方法检测连接是否可用
                                        int result = checkAddressAvailable(account, ipport);
                                        // 查询余额成功
                                        if (result == 0) {
                                            ia.Status = true;
                                        }
                                    }
                                }
                            }

                        } catch (System.Exception ex) {
                            log.ErrorFormat("检测线程异常,Error:{0}", ex.Message);
                        } finally {
                            Thread.Sleep(5000);
                        }
                    }
                } catch (System.Exception ex) {
                    log.ErrorFormat("线程异常终止,Error:{0}", ex.Message);
                } finally {
                    THREADSTATUS = false;
                }
                //释放
                if (task.Handle != null) {
                    task.Handle.Unregister(null);
                }
            }
        }

    }
}

﻿namespace Test {
    partial class ApiDemo {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApiDemo));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb_aut_userid_pwd = new System.Windows.Forms.RadioButton();
            this.rb_auth_apikey = new System.Windows.Forms.RadioButton();
            this.rb_aut_userid = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rb_XML = new System.Windows.Forms.RadioButton();
            this.rb_Json = new System.Windows.Forms.RadioButton();
            this.rb_UrlEncode = new System.Windows.Forms.RadioButton();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.rd_no = new System.Windows.Forms.RadioButton();
            this.rd_yes = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.account_setting = new System.Windows.Forms.GroupBox();
            this.btn_ok = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_apikey = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_m_ipport = new System.Windows.Forms.TextBox();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.txt_userid = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabPG = new System.Windows.Forms.TabControl();
            this.tab_1 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btn_single_send = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_svrtype_s = new System.Windows.Forms.TextBox();
            this.txt_exdata_s = new System.Windows.Forms.TextBox();
            this.txt_custid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_exno = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.txt_message = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txt_result_single = new System.Windows.Forms.TextBox();
            this.tab_2 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_svrtype_b = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_exdata_b = new System.Windows.Forms.TextBox();
            this.btn_batch_send = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.b_txt_custid = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.b_txt_exno = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.b_txt_mobile = new System.Windows.Forms.TextBox();
            this.b_txt_message = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txt_result_batch = new System.Windows.Forms.TextBox();
            this.tab_3 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_svrtype_m = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_exdata_m = new System.Windows.Forms.TextBox();
            this.btn_multi_send = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.m_txt_custid = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.m_txt_exno = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.m_txt_mobile = new System.Windows.Forms.TextBox();
            this.m_txt_message = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txt_result_mu = new System.Windows.Forms.TextBox();
            this.tab_4 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btn_mo_thread_stop = new System.Windows.Forms.Button();
            this.btn_mo_thread_start = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.txt_mo_retsize = new System.Windows.Forms.TextBox();
            this.btn_mo_get = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.txt_result_mo = new System.Windows.Forms.TextBox();
            this.tab_5 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_rpt_thread = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_rpt_retsize = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.txt_result_rpt = new System.Windows.Forms.TextBox();
            this.tab_6 = new System.Windows.Forms.TabPage();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.btn_getBalance = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_b_ipport3 = new System.Windows.Forms.TextBox();
            this.txt_b_ipport2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txt_b_ipport1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.account_setting.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPG.SuspendLayout();
            this.tab_1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tab_2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tab_3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tab_4.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tab_5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tab_6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.account_setting);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1093, 182);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本设置";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.rd_no);
            this.groupBox2.Controls.Add(this.rd_yes);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(597, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(493, 162);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "其他设置";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rb_aut_userid_pwd);
            this.panel2.Controls.Add(this.rb_auth_apikey);
            this.panel2.Controls.Add(this.rb_aut_userid);
            this.panel2.Location = new System.Drawing.Point(123, 90);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(356, 27);
            this.panel2.TabIndex = 14;
            // 
            // rb_aut_userid_pwd
            // 
            this.rb_aut_userid_pwd.AutoSize = true;
            this.rb_aut_userid_pwd.Location = new System.Drawing.Point(141, 5);
            this.rb_aut_userid_pwd.Name = "rb_aut_userid_pwd";
            this.rb_aut_userid_pwd.Size = new System.Drawing.Size(77, 16);
            this.rb_aut_userid_pwd.TabIndex = 15;
            this.rb_aut_userid_pwd.Text = "账号+密码";
            this.rb_aut_userid_pwd.UseVisualStyleBackColor = true;
            this.rb_aut_userid_pwd.CheckedChanged += new System.EventHandler(this.rb_aut_userid_pwd_CheckedChanged);
            // 
            // rb_auth_apikey
            // 
            this.rb_auth_apikey.AutoSize = true;
            this.rb_auth_apikey.Location = new System.Drawing.Point(281, 6);
            this.rb_auth_apikey.Name = "rb_auth_apikey";
            this.rb_auth_apikey.Size = new System.Drawing.Size(59, 16);
            this.rb_auth_apikey.TabIndex = 14;
            this.rb_auth_apikey.Text = "ApiKey";
            this.rb_auth_apikey.UseVisualStyleBackColor = true;
            this.rb_auth_apikey.CheckedChanged += new System.EventHandler(this.rb_auth_apikey_CheckedChanged);
            // 
            // rb_aut_userid
            // 
            this.rb_aut_userid.AutoSize = true;
            this.rb_aut_userid.Checked = true;
            this.rb_aut_userid.Location = new System.Drawing.Point(4, 5);
            this.rb_aut_userid.Name = "rb_aut_userid";
            this.rb_aut_userid.Size = new System.Drawing.Size(107, 16);
            this.rb_aut_userid.TabIndex = 13;
            this.rb_aut_userid.TabStop = true;
            this.rb_aut_userid.Text = "MD5(账号+密码)";
            this.rb_aut_userid.UseVisualStyleBackColor = true;
            this.rb_aut_userid.CheckedChanged += new System.EventHandler(this.rb_aut_userid_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rb_XML);
            this.panel1.Controls.Add(this.rb_Json);
            this.panel1.Controls.Add(this.rb_UrlEncode);
            this.panel1.Location = new System.Drawing.Point(122, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 28);
            this.panel1.TabIndex = 13;
            // 
            // rb_XML
            // 
            this.rb_XML.AutoSize = true;
            this.rb_XML.Location = new System.Drawing.Point(153, 7);
            this.rb_XML.Name = "rb_XML";
            this.rb_XML.Size = new System.Drawing.Size(41, 16);
            this.rb_XML.TabIndex = 12;
            this.rb_XML.Text = "XML";
            this.rb_XML.UseVisualStyleBackColor = true;
            this.rb_XML.CheckedChanged += new System.EventHandler(this.rb_XML_CheckedChanged);
            // 
            // rb_Json
            // 
            this.rb_Json.AutoSize = true;
            this.rb_Json.Location = new System.Drawing.Point(89, 6);
            this.rb_Json.Name = "rb_Json";
            this.rb_Json.Size = new System.Drawing.Size(47, 16);
            this.rb_Json.TabIndex = 11;
            this.rb_Json.Text = "Json";
            this.rb_Json.UseVisualStyleBackColor = true;
            this.rb_Json.CheckedChanged += new System.EventHandler(this.rb_Json_CheckedChanged);
            // 
            // rb_UrlEncode
            // 
            this.rb_UrlEncode.AutoSize = true;
            this.rb_UrlEncode.Checked = true;
            this.rb_UrlEncode.Location = new System.Drawing.Point(4, 7);
            this.rb_UrlEncode.Name = "rb_UrlEncode";
            this.rb_UrlEncode.Size = new System.Drawing.Size(77, 16);
            this.rb_UrlEncode.TabIndex = 10;
            this.rb_UrlEncode.TabStop = true;
            this.rb_UrlEncode.Text = "UrlEncode";
            this.rb_UrlEncode.UseVisualStyleBackColor = true;
            this.rb_UrlEncode.CheckedChanged += new System.EventHandler(this.rb_UrlEncode_CheckedChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(42, 96);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 10;
            this.label40.Text = "鉴权方式：";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(42, 55);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 12);
            this.label39.TabIndex = 6;
            this.label39.Text = "报文类型：";
            // 
            // rd_no
            // 
            this.rd_no.AutoSize = true;
            this.rd_no.Location = new System.Drawing.Point(184, 23);
            this.rd_no.Name = "rd_no";
            this.rd_no.Size = new System.Drawing.Size(35, 16);
            this.rd_no.TabIndex = 4;
            this.rd_no.Text = "否";
            this.rd_no.UseVisualStyleBackColor = true;
            this.rd_no.CheckedChanged += new System.EventHandler(this.rd_no_CheckedChanged);
            // 
            // rd_yes
            // 
            this.rd_yes.AutoSize = true;
            this.rd_yes.Checked = true;
            this.rd_yes.Location = new System.Drawing.Point(127, 22);
            this.rd_yes.Name = "rd_yes";
            this.rd_yes.Size = new System.Drawing.Size(35, 16);
            this.rd_yes.TabIndex = 3;
            this.rd_yes.TabStop = true;
            this.rd_yes.Text = "是";
            this.rd_yes.UseVisualStyleBackColor = true;
            this.rd_yes.CheckedChanged += new System.EventHandler(this.rd_yes_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "是否长连接：";
            // 
            // account_setting
            // 
            this.account_setting.Controls.Add(this.label15);
            this.account_setting.Controls.Add(this.label16);
            this.account_setting.Controls.Add(this.txt_b_ipport3);
            this.account_setting.Controls.Add(this.txt_b_ipport2);
            this.account_setting.Controls.Add(this.label22);
            this.account_setting.Controls.Add(this.txt_b_ipport1);
            this.account_setting.Controls.Add(this.btn_ok);
            this.account_setting.Controls.Add(this.label41);
            this.account_setting.Controls.Add(this.label3);
            this.account_setting.Controls.Add(this.label2);
            this.account_setting.Controls.Add(this.txt_apikey);
            this.account_setting.Controls.Add(this.label1);
            this.account_setting.Controls.Add(this.txt_m_ipport);
            this.account_setting.Controls.Add(this.txt_pwd);
            this.account_setting.Controls.Add(this.txt_userid);
            this.account_setting.Dock = System.Windows.Forms.DockStyle.Left;
            this.account_setting.Location = new System.Drawing.Point(3, 17);
            this.account_setting.Name = "account_setting";
            this.account_setting.Size = new System.Drawing.Size(594, 162);
            this.account_setting.TabIndex = 1;
            this.account_setting.TabStop = false;
            this.account_setting.Text = "账号设置";
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(193, 133);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(75, 23);
            this.btn_ok.TabIndex = 8;
            this.btn_ok.Text = "确 定";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(24, 104);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(53, 12);
            this.label41.TabIndex = 1;
            this.label41.Text = "ApiKey：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "IP/PORT：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "密码：";
            // 
            // txt_apikey
            // 
            this.txt_apikey.Location = new System.Drawing.Point(95, 101);
            this.txt_apikey.Name = "txt_apikey";
            this.txt_apikey.Size = new System.Drawing.Size(212, 21);
            this.txt_apikey.TabIndex = 0;
            this.txt_apikey.Text = "9f76c26fd10c135f01c4e64b2042bef4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "账号：";
            // 
            // txt_m_ipport
            // 
            this.txt_m_ipport.Location = new System.Drawing.Point(94, 71);
            this.txt_m_ipport.Name = "txt_m_ipport";
            this.txt_m_ipport.Size = new System.Drawing.Size(213, 21);
            this.txt_m_ipport.TabIndex = 0;
            this.txt_m_ipport.Text = "192.169.3.240:8099";
            // 
            // txt_pwd
            // 
            this.txt_pwd.Location = new System.Drawing.Point(94, 44);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.Size = new System.Drawing.Size(213, 21);
            this.txt_pwd.TabIndex = 0;
            this.txt_pwd.Text = "123456";
            // 
            // txt_userid
            // 
            this.txt_userid.Location = new System.Drawing.Point(94, 17);
            this.txt_userid.Name = "txt_userid";
            this.txt_userid.Size = new System.Drawing.Size(213, 21);
            this.txt_userid.TabIndex = 0;
            this.txt_userid.Text = "YIYI01";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tabPG);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 182);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1093, 536);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "6个接口";
            // 
            // tabPG
            // 
            this.tabPG.Controls.Add(this.tab_1);
            this.tabPG.Controls.Add(this.tab_2);
            this.tabPG.Controls.Add(this.tab_3);
            this.tabPG.Controls.Add(this.tab_4);
            this.tabPG.Controls.Add(this.tab_5);
            this.tabPG.Controls.Add(this.tab_6);
            this.tabPG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabPG.Location = new System.Drawing.Point(3, 17);
            this.tabPG.Name = "tabPG";
            this.tabPG.SelectedIndex = 0;
            this.tabPG.Size = new System.Drawing.Size(1087, 516);
            this.tabPG.TabIndex = 0;
            // 
            // tab_1
            // 
            this.tab_1.Controls.Add(this.groupBox5);
            this.tab_1.Controls.Add(this.groupBox4);
            this.tab_1.Location = new System.Drawing.Point(4, 22);
            this.tab_1.Name = "tab_1";
            this.tab_1.Padding = new System.Windows.Forms.Padding(3);
            this.tab_1.Size = new System.Drawing.Size(1079, 490);
            this.tab_1.TabIndex = 0;
            this.tab_1.Text = "单条发送";
            this.tab_1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btn_single_send);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.txt_svrtype_s);
            this.groupBox5.Controls.Add(this.txt_exdata_s);
            this.groupBox5.Controls.Add(this.txt_custid);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.txt_exno);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.txt_mobile);
            this.groupBox5.Controls.Add(this.txt_message);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(3, 233);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1073, 254);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "发送";
            // 
            // btn_single_send
            // 
            this.btn_single_send.Location = new System.Drawing.Point(305, 221);
            this.btn_single_send.Name = "btn_single_send";
            this.btn_single_send.Size = new System.Drawing.Size(75, 23);
            this.btn_single_send.TabIndex = 7;
            this.btn_single_send.Text = "发 送";
            this.btn_single_send.UseVisualStyleBackColor = true;
            this.btn_single_send.Click += new System.EventHandler(this.btn_single_send_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "用户自定义流水编号(CustId)：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 12);
            this.label8.TabIndex = 6;
            this.label8.Text = "业务类型(svrtype)：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 160);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(149, 12);
            this.label11.TabIndex = 6;
            this.label11.Text = "自定义扩展数据(exdata)：";
            // 
            // txt_svrtype_s
            // 
            this.txt_svrtype_s.Location = new System.Drawing.Point(186, 182);
            this.txt_svrtype_s.MaxLength = 32;
            this.txt_svrtype_s.Name = "txt_svrtype_s";
            this.txt_svrtype_s.Size = new System.Drawing.Size(718, 21);
            this.txt_svrtype_s.TabIndex = 5;
            this.txt_svrtype_s.Text = "abc";
            // 
            // txt_exdata_s
            // 
            this.txt_exdata_s.Location = new System.Drawing.Point(186, 155);
            this.txt_exdata_s.MaxLength = 64;
            this.txt_exdata_s.Name = "txt_exdata_s";
            this.txt_exdata_s.Size = new System.Drawing.Size(718, 21);
            this.txt_exdata_s.TabIndex = 5;
            this.txt_exdata_s.Text = "123";
            // 
            // txt_custid
            // 
            this.txt_custid.Location = new System.Drawing.Point(186, 124);
            this.txt_custid.MaxLength = 64;
            this.txt_custid.Name = "txt_custid";
            this.txt_custid.Size = new System.Drawing.Size(718, 21);
            this.txt_custid.TabIndex = 5;
            this.txt_custid.Text = "c333333";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "扩展子号(ExNo)：";
            // 
            // txt_exno
            // 
            this.txt_exno.Location = new System.Drawing.Point(186, 86);
            this.txt_exno.Name = "txt_exno";
            this.txt_exno.Size = new System.Drawing.Size(718, 21);
            this.txt_exno.TabIndex = 3;
            this.txt_exno.Text = "333";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(113, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "手机号码(Mobile)：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "内容(Message)：";
            // 
            // txt_mobile
            // 
            this.txt_mobile.Location = new System.Drawing.Point(186, 56);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.Size = new System.Drawing.Size(718, 21);
            this.txt_mobile.TabIndex = 0;
            this.txt_mobile.Text = "15989321542";
            // 
            // txt_message
            // 
            this.txt_message.Location = new System.Drawing.Point(186, 26);
            this.txt_message.Name = "txt_message";
            this.txt_message.Size = new System.Drawing.Size(718, 21);
            this.txt_message.TabIndex = 0;
            this.txt_message.Text = "该接口每次只可以对一个手机号码发送短信";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txt_result_single);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1073, 230);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "单条发送返回报文";
            // 
            // txt_result_single
            // 
            this.txt_result_single.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_result_single.Location = new System.Drawing.Point(3, 17);
            this.txt_result_single.Multiline = true;
            this.txt_result_single.Name = "txt_result_single";
            this.txt_result_single.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_result_single.Size = new System.Drawing.Size(1067, 210);
            this.txt_result_single.TabIndex = 0;
            // 
            // tab_2
            // 
            this.tab_2.Controls.Add(this.groupBox7);
            this.tab_2.Controls.Add(this.groupBox6);
            this.tab_2.Location = new System.Drawing.Point(4, 22);
            this.tab_2.Name = "tab_2";
            this.tab_2.Padding = new System.Windows.Forms.Padding(3);
            this.tab_2.Size = new System.Drawing.Size(934, 490);
            this.tab_2.TabIndex = 1;
            this.tab_2.Text = "相同内容群发";
            this.tab_2.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.txt_svrtype_b);
            this.groupBox7.Controls.Add(this.label5);
            this.groupBox7.Controls.Add(this.txt_exdata_b);
            this.groupBox7.Controls.Add(this.btn_batch_send);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.b_txt_custid);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.b_txt_exno);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.b_txt_mobile);
            this.groupBox7.Controls.Add(this.b_txt_message);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(3, 233);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(928, 254);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "发送";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 183);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 12);
            this.label13.TabIndex = 11;
            this.label13.Text = "业务类型(svrtype)：";
            // 
            // txt_svrtype_b
            // 
            this.txt_svrtype_b.Location = new System.Drawing.Point(183, 178);
            this.txt_svrtype_b.MaxLength = 32;
            this.txt_svrtype_b.Name = "txt_svrtype_b";
            this.txt_svrtype_b.Size = new System.Drawing.Size(718, 21);
            this.txt_svrtype_b.TabIndex = 10;
            this.txt_svrtype_b.Text = "efg";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "自定义扩展数据(exdata)：";
            // 
            // txt_exdata_b
            // 
            this.txt_exdata_b.Location = new System.Drawing.Point(183, 151);
            this.txt_exdata_b.MaxLength = 64;
            this.txt_exdata_b.Name = "txt_exdata_b";
            this.txt_exdata_b.Size = new System.Drawing.Size(718, 21);
            this.txt_exdata_b.TabIndex = 8;
            this.txt_exdata_b.Text = "456";
            // 
            // btn_batch_send
            // 
            this.btn_batch_send.Location = new System.Drawing.Point(286, 225);
            this.btn_batch_send.Name = "btn_batch_send";
            this.btn_batch_send.Size = new System.Drawing.Size(75, 23);
            this.btn_batch_send.TabIndex = 7;
            this.btn_batch_send.Text = "发 送";
            this.btn_batch_send.UseVisualStyleBackColor = true;
            this.btn_batch_send.Click += new System.EventHandler(this.btn_batch_send_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(7, 126);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(173, 12);
            this.label17.TabIndex = 6;
            this.label17.Text = "用户自定义流水编号(CustId)：";
            // 
            // b_txt_custid
            // 
            this.b_txt_custid.Location = new System.Drawing.Point(183, 124);
            this.b_txt_custid.MaxLength = 64;
            this.b_txt_custid.Name = "b_txt_custid";
            this.b_txt_custid.Size = new System.Drawing.Size(718, 21);
            this.b_txt_custid.TabIndex = 5;
            this.b_txt_custid.Text = "c22222";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(7, 115);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(11, 12);
            this.label18.TabIndex = 4;
            this.label18.Text = " ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 88);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 12);
            this.label19.TabIndex = 4;
            this.label19.Text = "扩展子号(ExNo)：";
            // 
            // b_txt_exno
            // 
            this.b_txt_exno.Location = new System.Drawing.Point(183, 88);
            this.b_txt_exno.Name = "b_txt_exno";
            this.b_txt_exno.Size = new System.Drawing.Size(718, 21);
            this.b_txt_exno.TabIndex = 3;
            this.b_txt_exno.Text = "222";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(7, 59);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(113, 12);
            this.label20.TabIndex = 2;
            this.label20.Text = "多个手机(Mobile)：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(95, 12);
            this.label21.TabIndex = 2;
            this.label21.Text = "内容(Message)：";
            // 
            // b_txt_mobile
            // 
            this.b_txt_mobile.Location = new System.Drawing.Point(183, 56);
            this.b_txt_mobile.Name = "b_txt_mobile";
            this.b_txt_mobile.Size = new System.Drawing.Size(718, 21);
            this.b_txt_mobile.TabIndex = 0;
            this.b_txt_mobile.Text = "13980321442,15800321512,15983215410,13489311545";
            // 
            // b_txt_message
            // 
            this.b_txt_message.Location = new System.Drawing.Point(183, 26);
            this.b_txt_message.Name = "b_txt_message";
            this.b_txt_message.Size = new System.Drawing.Size(718, 21);
            this.b_txt_message.TabIndex = 0;
            this.b_txt_message.Text = "该接口每次只可以对一个或多个手机号码发送相同的短信";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txt_result_batch);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox6.Location = new System.Drawing.Point(3, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(928, 230);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "相同内容群发返回报文";
            // 
            // txt_result_batch
            // 
            this.txt_result_batch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_result_batch.Location = new System.Drawing.Point(3, 17);
            this.txt_result_batch.Multiline = true;
            this.txt_result_batch.Name = "txt_result_batch";
            this.txt_result_batch.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_result_batch.Size = new System.Drawing.Size(922, 210);
            this.txt_result_batch.TabIndex = 1;
            // 
            // tab_3
            // 
            this.tab_3.Controls.Add(this.groupBox8);
            this.tab_3.Controls.Add(this.groupBox9);
            this.tab_3.Location = new System.Drawing.Point(4, 22);
            this.tab_3.Name = "tab_3";
            this.tab_3.Padding = new System.Windows.Forms.Padding(3);
            this.tab_3.Size = new System.Drawing.Size(934, 490);
            this.tab_3.TabIndex = 2;
            this.tab_3.Text = "不同内容群发";
            this.tab_3.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.txt_svrtype_m);
            this.groupBox8.Controls.Add(this.label6);
            this.groupBox8.Controls.Add(this.txt_exdata_m);
            this.groupBox8.Controls.Add(this.btn_multi_send);
            this.groupBox8.Controls.Add(this.label23);
            this.groupBox8.Controls.Add(this.m_txt_custid);
            this.groupBox8.Controls.Add(this.label25);
            this.groupBox8.Controls.Add(this.m_txt_exno);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Controls.Add(this.m_txt_mobile);
            this.groupBox8.Controls.Add(this.m_txt_message);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(3, 233);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(928, 254);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "发送";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 180);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(119, 12);
            this.label14.TabIndex = 13;
            this.label14.Text = "业务类型(svrtype)：";
            // 
            // txt_svrtype_m
            // 
            this.txt_svrtype_m.Location = new System.Drawing.Point(186, 175);
            this.txt_svrtype_m.MaxLength = 32;
            this.txt_svrtype_m.Name = "txt_svrtype_m";
            this.txt_svrtype_m.Size = new System.Drawing.Size(718, 21);
            this.txt_svrtype_m.TabIndex = 12;
            this.txt_svrtype_m.Text = "hjk";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(149, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "自定义扩展数据(exdata)：";
            // 
            // txt_exdata_m
            // 
            this.txt_exdata_m.Location = new System.Drawing.Point(186, 148);
            this.txt_exdata_m.MaxLength = 64;
            this.txt_exdata_m.Name = "txt_exdata_m";
            this.txt_exdata_m.Size = new System.Drawing.Size(718, 21);
            this.txt_exdata_m.TabIndex = 10;
            this.txt_exdata_m.Text = "789";
            // 
            // btn_multi_send
            // 
            this.btn_multi_send.Location = new System.Drawing.Point(285, 225);
            this.btn_multi_send.Name = "btn_multi_send";
            this.btn_multi_send.Size = new System.Drawing.Size(75, 23);
            this.btn_multi_send.TabIndex = 7;
            this.btn_multi_send.Text = "发 送";
            this.btn_multi_send.UseVisualStyleBackColor = true;
            this.btn_multi_send.Click += new System.EventHandler(this.btn_multi_send_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 120);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(173, 12);
            this.label23.TabIndex = 6;
            this.label23.Text = "用户自定义流水编号(CustId)：";
            // 
            // m_txt_custid
            // 
            this.m_txt_custid.Location = new System.Drawing.Point(186, 118);
            this.m_txt_custid.MaxLength = 64;
            this.m_txt_custid.Name = "m_txt_custid";
            this.m_txt_custid.Size = new System.Drawing.Size(718, 21);
            this.m_txt_custid.TabIndex = 5;
            this.m_txt_custid.Text = "c111111111111";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 88);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(101, 12);
            this.label25.TabIndex = 4;
            this.label25.Text = "扩展子号(ExNo)：";
            // 
            // m_txt_exno
            // 
            this.m_txt_exno.Location = new System.Drawing.Point(186, 88);
            this.m_txt_exno.Name = "m_txt_exno";
            this.m_txt_exno.Size = new System.Drawing.Size(718, 21);
            this.m_txt_exno.TabIndex = 3;
            this.m_txt_exno.Text = "111";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(7, 59);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(113, 12);
            this.label26.TabIndex = 2;
            this.label26.Text = "多个手机(Mobile)：";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 29);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 12);
            this.label27.TabIndex = 2;
            this.label27.Text = "内容(Message)：";
            // 
            // m_txt_mobile
            // 
            this.m_txt_mobile.Location = new System.Drawing.Point(186, 56);
            this.m_txt_mobile.Name = "m_txt_mobile";
            this.m_txt_mobile.Size = new System.Drawing.Size(718, 21);
            this.m_txt_mobile.TabIndex = 0;
            this.m_txt_mobile.Text = "15989321542,15989321541,15989321540,15989321545";
            // 
            // m_txt_message
            // 
            this.m_txt_message.Location = new System.Drawing.Point(186, 29);
            this.m_txt_message.Name = "m_txt_message";
            this.m_txt_message.Size = new System.Drawing.Size(718, 21);
            this.m_txt_message.TabIndex = 0;
            this.m_txt_message.Text = "该接口每次只可以对一个或多个手机号码发送相同的短信";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txt_result_mu);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox9.Location = new System.Drawing.Point(3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(928, 230);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "不同内容群发返回报文";
            // 
            // txt_result_mu
            // 
            this.txt_result_mu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_result_mu.Location = new System.Drawing.Point(3, 17);
            this.txt_result_mu.Multiline = true;
            this.txt_result_mu.Name = "txt_result_mu";
            this.txt_result_mu.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_result_mu.Size = new System.Drawing.Size(922, 210);
            this.txt_result_mu.TabIndex = 1;
            // 
            // tab_4
            // 
            this.tab_4.Controls.Add(this.groupBox10);
            this.tab_4.Controls.Add(this.groupBox11);
            this.tab_4.Location = new System.Drawing.Point(4, 22);
            this.tab_4.Name = "tab_4";
            this.tab_4.Size = new System.Drawing.Size(934, 490);
            this.tab_4.TabIndex = 3;
            this.tab_4.Text = "接收上行";
            this.tab_4.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btn_mo_thread_stop);
            this.groupBox10.Controls.Add(this.btn_mo_thread_start);
            this.groupBox10.Controls.Add(this.label31);
            this.groupBox10.Controls.Add(this.txt_mo_retsize);
            this.groupBox10.Controls.Add(this.btn_mo_get);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(0, 374);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(934, 116);
            this.groupBox10.TabIndex = 8;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "发送";
            // 
            // btn_mo_thread_stop
            // 
            this.btn_mo_thread_stop.Location = new System.Drawing.Point(515, 38);
            this.btn_mo_thread_stop.Name = "btn_mo_thread_stop";
            this.btn_mo_thread_stop.Size = new System.Drawing.Size(75, 23);
            this.btn_mo_thread_stop.TabIndex = 10;
            this.btn_mo_thread_stop.Text = "停止线程";
            this.btn_mo_thread_stop.UseVisualStyleBackColor = true;
            this.btn_mo_thread_stop.Click += new System.EventHandler(this.btn_mo_thread_stop_Click);
            // 
            // btn_mo_thread_start
            // 
            this.btn_mo_thread_start.Location = new System.Drawing.Point(409, 36);
            this.btn_mo_thread_start.Name = "btn_mo_thread_start";
            this.btn_mo_thread_start.Size = new System.Drawing.Size(75, 23);
            this.btn_mo_thread_start.TabIndex = 11;
            this.btn_mo_thread_start.Text = "线程接收";
            this.btn_mo_thread_start.UseVisualStyleBackColor = true;
            this.btn_mo_thread_start.Click += new System.EventHandler(this.btn_mo_thread_start_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(20, 38);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(119, 12);
            this.label31.TabIndex = 9;
            this.label31.Text = "单次接收(retsize)：";
            // 
            // txt_mo_retsize
            // 
            this.txt_mo_retsize.Location = new System.Drawing.Point(139, 35);
            this.txt_mo_retsize.Name = "txt_mo_retsize";
            this.txt_mo_retsize.Size = new System.Drawing.Size(149, 21);
            this.txt_mo_retsize.TabIndex = 8;
            this.txt_mo_retsize.Text = "30";
            // 
            // btn_mo_get
            // 
            this.btn_mo_get.Location = new System.Drawing.Point(315, 35);
            this.btn_mo_get.Name = "btn_mo_get";
            this.btn_mo_get.Size = new System.Drawing.Size(75, 23);
            this.btn_mo_get.TabIndex = 7;
            this.btn_mo_get.Text = "获 取";
            this.btn_mo_get.UseVisualStyleBackColor = true;
            this.btn_mo_get.Click += new System.EventHandler(this.btn_mo_get_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.txt_result_mo);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox11.Location = new System.Drawing.Point(0, 0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(934, 374);
            this.groupBox11.TabIndex = 7;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "上行数据报文";
            // 
            // txt_result_mo
            // 
            this.txt_result_mo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_result_mo.Location = new System.Drawing.Point(3, 17);
            this.txt_result_mo.Multiline = true;
            this.txt_result_mo.Name = "txt_result_mo";
            this.txt_result_mo.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_result_mo.Size = new System.Drawing.Size(928, 354);
            this.txt_result_mo.TabIndex = 2;
            // 
            // tab_5
            // 
            this.tab_5.Controls.Add(this.groupBox12);
            this.tab_5.Controls.Add(this.groupBox13);
            this.tab_5.Location = new System.Drawing.Point(4, 22);
            this.tab_5.Name = "tab_5";
            this.tab_5.Size = new System.Drawing.Size(934, 490);
            this.tab_5.TabIndex = 4;
            this.tab_5.Text = "接收状态报告";
            this.tab_5.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button4);
            this.groupBox12.Controls.Add(this.btn_rpt_thread);
            this.groupBox12.Controls.Add(this.button6);
            this.groupBox12.Controls.Add(this.label30);
            this.groupBox12.Controls.Add(this.txt_rpt_retsize);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Location = new System.Drawing.Point(0, 368);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(934, 122);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "发送";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(587, 36);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "停止线程";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_rpt_thread
            // 
            this.btn_rpt_thread.Location = new System.Drawing.Point(481, 34);
            this.btn_rpt_thread.Name = "btn_rpt_thread";
            this.btn_rpt_thread.Size = new System.Drawing.Size(75, 23);
            this.btn_rpt_thread.TabIndex = 9;
            this.btn_rpt_thread.Text = "线程接收";
            this.btn_rpt_thread.UseVisualStyleBackColor = true;
            this.btn_rpt_thread.Click += new System.EventHandler(this.btn_rpt_thread_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(388, 31);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 7;
            this.button6.Text = "获 取";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(20, 36);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(119, 12);
            this.label30.TabIndex = 2;
            this.label30.Text = "单次接收(retsize)：";
            // 
            // txt_rpt_retsize
            // 
            this.txt_rpt_retsize.Location = new System.Drawing.Point(139, 33);
            this.txt_rpt_retsize.Name = "txt_rpt_retsize";
            this.txt_rpt_retsize.Size = new System.Drawing.Size(149, 21);
            this.txt_rpt_retsize.TabIndex = 0;
            this.txt_rpt_retsize.Text = "30";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.txt_result_rpt);
            this.groupBox13.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox13.Location = new System.Drawing.Point(0, 0);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(934, 368);
            this.groupBox13.TabIndex = 9;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "接收状态报告报文";
            // 
            // txt_result_rpt
            // 
            this.txt_result_rpt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_result_rpt.Location = new System.Drawing.Point(3, 17);
            this.txt_result_rpt.Multiline = true;
            this.txt_result_rpt.Name = "txt_result_rpt";
            this.txt_result_rpt.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_result_rpt.Size = new System.Drawing.Size(928, 348);
            this.txt_result_rpt.TabIndex = 2;
            // 
            // tab_6
            // 
            this.tab_6.Controls.Add(this.txt_balance);
            this.tab_6.Controls.Add(this.btn_getBalance);
            this.tab_6.Location = new System.Drawing.Point(4, 22);
            this.tab_6.Name = "tab_6";
            this.tab_6.Size = new System.Drawing.Size(934, 490);
            this.tab_6.TabIndex = 5;
            this.tab_6.Text = "获取剩余金额和剩下条数";
            this.tab_6.UseVisualStyleBackColor = true;
            // 
            // txt_balance
            // 
            this.txt_balance.Location = new System.Drawing.Point(193, 163);
            this.txt_balance.Multiline = true;
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.ReadOnly = true;
            this.txt_balance.Size = new System.Drawing.Size(340, 154);
            this.txt_balance.TabIndex = 1;
            // 
            // btn_getBalance
            // 
            this.btn_getBalance.Location = new System.Drawing.Point(286, 115);
            this.btn_getBalance.Name = "btn_getBalance";
            this.btn_getBalance.Size = new System.Drawing.Size(75, 23);
            this.btn_getBalance.TabIndex = 0;
            this.btn_getBalance.Text = "查询余额";
            this.btn_getBalance.UseVisualStyleBackColor = true;
            this.btn_getBalance.Click += new System.EventHandler(this.btn_getBalance_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(330, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 19;
            this.label15.Text = "备3IP/端口：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(330, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 20;
            this.label16.Text = "备2IP/端口：";
            // 
            // txt_b_ipport3
            // 
            this.txt_b_ipport3.Location = new System.Drawing.Point(413, 75);
            this.txt_b_ipport3.Name = "txt_b_ipport3";
            this.txt_b_ipport3.Size = new System.Drawing.Size(175, 21);
            this.txt_b_ipport3.TabIndex = 17;
            // 
            // txt_b_ipport2
            // 
            this.txt_b_ipport2.Location = new System.Drawing.Point(413, 48);
            this.txt_b_ipport2.Name = "txt_b_ipport2";
            this.txt_b_ipport2.Size = new System.Drawing.Size(175, 21);
            this.txt_b_ipport2.TabIndex = 18;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(330, 25);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 12);
            this.label22.TabIndex = 16;
            this.label22.Text = "备1IP/端口：";
            // 
            // txt_b_ipport1
            // 
            this.txt_b_ipport1.Location = new System.Drawing.Point(413, 22);
            this.txt_b_ipport1.Name = "txt_b_ipport1";
            this.txt_b_ipport1.Size = new System.Drawing.Size(175, 21);
            this.txt_b_ipport1.TabIndex = 15;
            // 
            // ApiDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 718);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ApiDemo";
            this.Text = "API 5.2 DEMO ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.account_setting.ResumeLayout(false);
            this.account_setting.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tabPG.ResumeLayout(false);
            this.tab_1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tab_2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tab_3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tab_4.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tab_5.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tab_6.ResumeLayout(false);
            this.tab_6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox account_setting;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_userid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_m_ipport;
        private System.Windows.Forms.TextBox txt_pwd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rd_yes;
        private System.Windows.Forms.RadioButton rd_no;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabControl tabPG;
        private System.Windows.Forms.TabPage tab_1;
        private System.Windows.Forms.TabPage tab_2;
        private System.Windows.Forms.TabPage tab_3;
        private System.Windows.Forms.TabPage tab_4;
        private System.Windows.Forms.TabPage tab_5;
        private System.Windows.Forms.TabPage tab_6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_message;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_exno;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_custid;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.Button btn_single_send;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btn_batch_send;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox b_txt_custid;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox b_txt_exno;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox b_txt_mobile;
        private System.Windows.Forms.TextBox b_txt_message;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btn_multi_send;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox m_txt_custid;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox m_txt_exno;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox m_txt_mobile;
        private System.Windows.Forms.TextBox m_txt_message;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btn_mo_get;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Button btn_getBalance;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt_rpt_retsize;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txt_mo_retsize;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txt_apikey;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rb_auth_apikey;
        private System.Windows.Forms.RadioButton rb_aut_userid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rb_XML;
        private System.Windows.Forms.RadioButton rb_Json;
        private System.Windows.Forms.RadioButton rb_UrlEncode;
        private System.Windows.Forms.TextBox txt_result_single;
        private System.Windows.Forms.TextBox txt_result_batch;
        private System.Windows.Forms.TextBox txt_result_mu;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.RadioButton rb_aut_userid_pwd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_exdata_s;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_exdata_b;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_exdata_m;
        private System.Windows.Forms.Button btn_mo_thread_stop;
        private System.Windows.Forms.Button btn_mo_thread_start;
        private System.Windows.Forms.TextBox txt_result_mo;
        private System.Windows.Forms.TextBox txt_result_rpt;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_rpt_thread;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_svrtype_s;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_svrtype_b;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_svrtype_m;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_b_ipport3;
        private System.Windows.Forms.TextBox txt_b_ipport2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txt_b_ipport1;

    }
}


﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;
using System.Windows.Forms;
using Test.isms;
using Test.Json;
using Test.UrlEncode;
using Test.XML;

namespace Test {

    public delegate void showRpt(string result, int messageType);
    public delegate void showMo(string result, int messageType);


    public partial class ApiDemo : Form {
        private static log4net.ILog log = log4net.LogManager.GetLogger(typeof(ApiDemo));


        private bool isKeepAlive = true;

        private Account account = Account.getInstance();

        //private bool isKeepAlive = true;
        //private string userid = string.Empty;
        //private string pwd = string.Empty;
        //private string ipport = string.Empty;
         private string apikey = string.Empty;
        private int messageType = 0;
        private int authenticationMode = 0;
         private bool isMd5 = true;
        ///// <summary>
        ///// 固定字串
        ///// </summary>
        private const string FIX_STRING = "00000000";

        public ApiDemo() {
            InitializeComponent();
        }

        #region 基本设置

        private void btn_ok_Click(object sender, EventArgs e) {
            loadConfig();
            //启动检测线程
            CheckThread.getInstance().start();
        }

        private void rd_yes_CheckedChanged(object sender, EventArgs e) {
            this.isKeepAlive = true;
        }

        private void rd_no_CheckedChanged(object sender, EventArgs e) {
            this.isKeepAlive = false;
        }

        private void loadConfig() {
            //这里有一个坑，账号一定要使用大写 

            account.UserId = this.txt_userid.Text.ToUpper().Trim();
            account.PassWord = this.txt_pwd.Text.Trim();
            IpAddress address = null;
            int errorCode = validateIpAndPort(this.txt_m_ipport.Text, out address);
            if (errorCode != 0) {
                MessageBox.Show("验证主IP/域名/端口失败.");
                return;
            }

            account.Ip = address.Ip;
            account.Port = address.Port;
            account.DomainName = address.DomainName;
            account.MasterIPState = 0;

            //  备用IP端口信息 IP和端口号以:号连接
            IList<IpAddress> ipAndPortBak = account.getIpAndPortBak();
            // 验证备用IP和端口是否合法
            errorCode = validateIpAndPortBak(ipAndPortBak, this.txt_b_ipport1.Text, this.txt_b_ipport2.Text, this.txt_b_ipport3.Text);
            if (errorCode != 0) {
                MessageBox.Show("警告：验证备用IP/域名/端口失败.");
                return;
            }
        }

        /// <summary>
        /// 验证备用IPADDRESS
        /// </summary>
        /// <param name="ipAndPortBak"></param>
        /// <param name="ipAddress1"></param>
        /// <param name="ipAddress2"></param>
        /// <param name="ipAddress3"></param>
        /// <returns></returns>
        private static int validateIpAndPortBak(IList<IpAddress> ipAndPortBak, String ipAddress1, String ipAddress2, String ipAddress3) {
            try {
                int result = 0;
                // 设置备IP1
                if (!string.IsNullOrEmpty(ipAddress1)) {
                    // 验证IP/域名和端口是否合法
                    IpAddress address1 = null;
                    result = validateIpAndPort(ipAddress1, out address1);
                    // IP和端口不合法
                    if (result != 0) {
                        return result; // 返回错误码
                    }
                    if (address1 != null)
                        ipAndPortBak.Add(address1);
                }
                // 设置备IP2
                if (!string.IsNullOrEmpty(ipAddress2)) {
                    // 验证IP/域名和端口是否合法
                    IpAddress address2 = null;
                    result = validateIpAndPort(ipAddress2, out address2);
                    // IP和端口不合法
                    if (result != 0) {
                        // 返回错误码
                        return result;
                    }
                    if (address2 != null)
                        ipAndPortBak.Add(address2);
                }
                // 设置备IP3
                if (!string.IsNullOrEmpty(ipAddress3)) {
                    // 验证IP/域名和端口是否合法
                    IpAddress address3 = null;
                    result = validateIpAndPort(ipAddress3, out address3);
                    // IP和端口不合法
                    if (result != 0) {
                        // 返回错误码
                        return result;
                    }
                    if (address3 != null)
                        ipAndPortBak.Add(address3);
                }

                // 都验证通过，返回0
                return 0;
            } catch (Exception ex) {
                // 清除备用IP集合
                ipAndPortBak.Clear();
                log.ErrorFormat(@"验证备用IPADDRESS时发生错误，Error:{0}", ex.Message);
                // IP和端口信息不合法
                return 300003;
            }
        }
        /**
       * @description 验证IP和端口信息是否合法
       * @param ipAddress
       *        IP和端口信息 IP和端口号以:号连接
       * @return 0：合法;非0:不合法
       * @author JoNllen <jonllen.zn@qq.com>
       * @datetime 2016-9-22 下午05:02:33
       */
        public static int validateIpAndPort(String ipAddress, out IpAddress address) {
            address = null;
            try {
                ////验证IP和端口 
                if (string.IsNullOrEmpty(ipAddress))
                    return 300003;

                string[] array = ipAddress.Split(':');
                if (array.Length != 2)
                    return 300003;
                //判断端口
                if (Convert.ToInt32(array[1]) > 65535)
                    return 300005;
                //
                address = new IpAddress();
                address.Port = Convert.ToInt32(array[1]);
                //验证是不是域名
                if (isDomainName(array[0])) {
                    address.DomainName = array[0];
                    address.Ip = getIpByDomainName(address.DomainName);
                } else {
                    address.Ip = array[0];
                }
                // 都验证通过，返回0
                return 0;
            } catch (Exception ex) {
                log.ErrorFormat(@"验证IP和端口信息时发生错误，Error:{0}", ex.Message);
                return 300003;
            }

        }
        /**
      * @description 检测IP地址和端口是否合法
      * @param ip
      *        IP地址
      * @return true:合法;false:非法
      * @author JoNllen <jonllen.zn@qq.com>
      * @datetime 2016-9-22 下午03:49:25
      */
        public static bool isDomainName(String domainName) {
            try {
                // IP不为空，则进行正则表达式验证
                if (string.IsNullOrEmpty(domainName))
                    return false;
                // 验证IP: 
                String regex = "^(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})){3}$";
                // 判断ip地址是否与正则表达式匹配
                return (!Regex.IsMatch(domainName, regex));

            } catch (Exception ex) {
                log.ErrorFormat(@"验证IP时发生错误，Error:{0}", ex.Message);
                return false;
            }
        }
        /// <summary>
        /// 通过域名获取IP
        /// </summary>
        /// <param name="domainName"></param>
        /// <returns></returns>
        private static string getIpByDomainName(String domainName) {
            try {
                IPHostEntry hostinfo = Dns.GetHostByName(domainName);
                IPAddress[] array = hostinfo.AddressList;
                return array[0].ToString();
            } catch (Exception ex) {
                log.ErrorFormat(@"解析域名（{0}）是发生错误，Error:{1}", domainName, ex.Message);
                return null;
            }
        }
        private void rb_UrlEncode_CheckedChanged(object sender, EventArgs e) {
            messageType = 0;
        }

        private void rb_Json_CheckedChanged(object sender, EventArgs e) {
            messageType = 1;
        }

        private void rb_XML_CheckedChanged(object sender, EventArgs e) {
            messageType = 2;
        }

        private void rb_aut_userid_CheckedChanged(object sender, EventArgs e) {
            isMd5 = true;
            authenticationMode = 0;
        }

        private void rb_auth_apikey_CheckedChanged(object sender, EventArgs e) {
            authenticationMode = 1;
        }
        private void rb_aut_userid_pwd_CheckedChanged(object sender, EventArgs e) {
            isMd5 = false;
            authenticationMode = 0;
        }
        #endregion

        /// <summary>
        /// 初始发送对象
        /// </summary>
        /// <returns></returns>
        private Message initMessage() {
            string imeStamp = DateTime.Now.ToString("MMddHHmmss");
            string password = isMd5 ? encode(account.UserId, account.PassWord, imeStamp) :account.PassWord;
            Message msg = new Message() {
                UserId = account.UserId,
                TimeStamp = imeStamp,
                Pwd =password,
                ApiKey = this.apikey
            };
            return msg;
        }

        #region  单条发送

        /// <summary>
        /// 单发
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_single_send_Click(object sender, EventArgs e) {
            Message msg = initMessage();
            msg.Mobile = this.txt_mobile.Text.Trim();
            msg.Content = this.txt_message.Text.Trim();
            msg.ExNo = this.txt_exno.Text.Trim();
            msg.CustId = this.txt_custid.Text.Trim();
            msg.ExData = this.txt_exdata_s.Text.Trim();
            msg.SvrType = this.txt_svrtype_s.Text.Trim();
            //提交
            txt_result_single.Text = submit(msg, 1);
        }


        #endregion


        #region 相同内容群发

        private void btn_batch_send_Click(object sender, EventArgs e) {
            Message msg = initMessage();
            msg.Mobile = this.b_txt_mobile.Text.Trim();
            msg.Content = this.b_txt_message.Text.Trim();
            msg.ExNo = this.b_txt_exno.Text.Trim();
            msg.CustId = this.b_txt_custid.Text.Trim();
            msg.ExData = this.txt_exdata_b.Text.Trim();
            msg.SvrType = this.txt_svrtype_b.Text.Trim();
            //提交
            txt_result_batch.Text = submit(msg, 2);
        }

        #endregion


        #region 不同内容群发
        private void btn_multi_send_Click(object sender, EventArgs e) {
            Message msg = initMessage();
            string Mobile = this.m_txt_mobile.Text.Trim();
            string Content = this.m_txt_message.Text.Trim();
            string ExNo = this.m_txt_exno.Text.Trim();
            string CustId = this.m_txt_custid.Text.Trim();
            string exData = this.txt_exdata_m.Text.Trim();
            string svrType = this.txt_svrtype_m.Text.Trim();
            if (string.IsNullOrEmpty(Mobile)) {
                MessageBox.Show("手机号码不能为空");
                return;
            }
            IList<MultiMt> list = new List<MultiMt>();
            string[] mArray = Mobile.Split(',');
            foreach (string m in mArray) {
                MultiMt entity = new MultiMt();
                entity.mobile = m;
                entity.content = HttpUtility.UrlEncode(Content, Encoding.GetEncoding("GBK"));
                entity.exno = ExNo;
                entity.custid = CustId;
                entity.exdata = exData;
                entity.svrtype = svrType;
                list.Add(entity);
            }
            try {
                //转为JSON
                msg.Multimt = JsonConvert.SerializeObject(list);
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
            msg.Multimtes = list;
            txt_result_mu.Text = submit(msg, 3);

        }

        #endregion

        #region 查询余额
        private void btn_getBalance_Click(object sender, EventArgs e) {
            Message msg = initMessage();
            txt_balance.Text = submit(msg, 6);
        }
        #endregion


        #region 获取状态报告
        private void button6_Click(object sender, EventArgs e) {
            try {
                Message msg = initMessage();
                msg.RetSize = Convert.ToInt32(this.txt_rpt_retsize.Text.Trim());
                string result = submit(msg, 5);
                txt_result_rpt.Text = result;
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region 接收上行
        private void btn_mo_get_Click(object sender, EventArgs e) {
            try {
                Message msg = initMessage();
                msg.RetSize = Convert.ToInt32(this.txt_mo_retsize.Text.Trim());
                string result = submit(msg, 4);
                txt_result_mo.Text = result;
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion


        /// <summary>
        /// 统一提交
        /// </summary>
        /// <param name="message">请求对象</param>
        /// <param name="sendType">请求类型,1:单发，2：相同内容群发，3：不同类型群发，4：获取上行，5：获取状态报告，6：获取账号余额</param>
        /// <returns></returns>
        private string submit(Message message, int sendtype) {
            try {
                ISMS sms = null;
                if (messageType == 0) {
                    sms = new UrlEncdoeSend();
                } else if (messageType == 1) {
                    sms = new JsonSend();
                } else if (messageType == 2) {
                    sms = new XMLSend();
                }
                String ipport = getIpPortByAccount(account);
                if (string.IsNullOrEmpty(ipport)) {
                    MessageBox.Show("没有可用的IP端口");
                    return "";
                }
                return sms.execute(message, sendtype, ipport, authenticationMode, this.isKeepAlive);
            } catch (Exception ex) {
                return ex.Message;
            } 
        }
        /// <summary>
        /// 通过账号获取连接对象
        /// </summary>
        /// <param name="returnAccount"></param>
        /// <param name="userid"></param>
        /// <param name="connectionMap"></param>
        /// <returns></returns>
        public static string getIpPortByAccount(Account acc) {
            try {
                if (acc.MasterIPState == 0)
                    return acc.IpAndPort;
                else {
                    //checkMasterIpState(acc);
                    IList<IpAddress> list = acc.getIpAndPortBak();
                    foreach (IpAddress ia in list) {
                        if (ia.Status)
                            return ia.IpAndPort;
                    }
                }
                return null;
            } catch (Exception ex) {
                log.ErrorFormat("通过账号获取连接对象时发生异常,Error:{0}", ex.Message);
                return null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="acc"></param>
        public static void checkMasterIpState(Account acc) {

        }
        /**
     * 对密码进行加密
     * 
     * @description
     * @param userid
     *        账号
     * @param pwd
     *        原始密码
     * @param timestamp
     *        时间戳
     * @return 加密后的密码
     * @author JoNllen <jonllen.zn@qq.com>
     * @datetime 2016-9-1 下午01:40:55
     */
        public string encode(String userid, String pwd, String timestamp) {
            // 加密后的字符串 
            try {
                return FormsAuthentication.HashPasswordForStoringInConfigFile((userid + FIX_STRING + pwd + timestamp), "MD5").ToLower();
            } catch (Exception ex) {
                MessageBox.Show(string.Format(@"MD5加密码错误，Error:{0}", ex.Message));
                return null;
            }
        }
        public static bool MO_THREADSTATUS = false;
        private void btn_mo_thread_stop_Click(object sender, EventArgs e) {
            MO_THREADSTATUS = false;
        }
        private void btn_mo_thread_start_Click(object sender, EventArgs e) {
            if (MO_THREADSTATUS) {
                MessageBox.Show("接收状态报告线程已开启");
                return;
            }
            try {
                Message message = initMessage();
                message.RetSize = Convert.ToInt32(this.txt_mo_retsize.Text.Trim());
                TaskThread task = new TaskThread();
                task.isKeepAlive = this.isKeepAlive;
                task.authenticationMode = this.authenticationMode;
                task.messageType = this.messageType;
                task.message = message;
                task.ipport = account.IpAndPort;
                startMoThread(task);

            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        public void startMoThread(TaskThread task) {
            MO_THREADSTATUS = true;
            AutoResetEvent reseEvent = new AutoResetEvent(false);
            task.Handle = ThreadPool.RegisterWaitForSingleObject(
                reseEvent,
                new WaitOrTimerCallback(waitProcMo),
                task,
                5,
                false
                );
            Thread.Sleep(5);
            reseEvent.Set();

        }

        public void waitProcMo(object state, bool timeout) {
            TaskThread task = (TaskThread)state;
            if (!timeout) {
                try {
                    ISMS sms = null;
                    if (task.messageType == 0) {
                        sms = new UrlEncdoeSend();
                    } else if (task.messageType == 1) {
                        sms = new JsonSend();
                    } else if (task.messageType == 2) {
                        sms = new XMLSend();
                    }

                    while (MO_THREADSTATUS) {
                        try {
                            string result = sms.execute(task.message, 4, task.ipport, task.authenticationMode, task.isKeepAlive);

                            this.Invoke(new showMo(this.showMo), result, task.messageType);
                            if ((task.messageType <= 1 && result.Length < 32) || result.Length < 100) { 
                                Thread.Sleep(5000);
                            }

                        } catch (Exception ex) {
                            log.ErrorFormat("接收状态报告线程内层异常, Error:{0}", ex.Message);
                        }
                    }
                } catch (System.Exception ex) {
                    log.ErrorFormat("接收状态报告线程异常终止,Error:{0}", ex.Message);
                } finally {
                    MO_THREADSTATUS = false;
                }
                //释放
                if (task.Handle != null) {
                    task.Handle.Unregister(null);
                }
            }
        }

        private void btn_rpt_thread_Click(object sender, EventArgs e) {
            if (RPT_THREADSTATUS) {
                MessageBox.Show("接收状态报告线程已开启");
                return;
            }
            try {

                Message message = initMessage();
                message.RetSize = Convert.ToInt32(this.txt_rpt_retsize.Text.Trim());
                TaskThread task = new TaskThread();
                task.isKeepAlive = this.isKeepAlive;
                task.authenticationMode = this.authenticationMode;
                task.messageType = this.messageType;
                task.message = message;
                task.ipport = account.IpAndPort;

                startRptThread(task);

            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        public static bool RPT_THREADSTATUS = false;
        public void startRptThread(TaskThread task) {
            RPT_THREADSTATUS = true;
            AutoResetEvent reseEvent = new AutoResetEvent(false);
            task.Handle = ThreadPool.RegisterWaitForSingleObject(
                reseEvent,
                new WaitOrTimerCallback(waitProcRpt),
                task,
                5,
                false
                );
            Thread.Sleep(5);
            reseEvent.Set();

        }

        public void waitProcRpt(object state, bool timeout) {
            TaskThread task = (TaskThread)state;
            if (!timeout) { 
                try {
                    ISMS sms = null;
                    if (task.messageType == 0) {
                        sms = new UrlEncdoeSend();
                    } else if (task.messageType == 1) {
                        sms = new JsonSend();
                    } else if (task.messageType == 2) {
                        sms = new XMLSend();
                    }
                   
                    while (RPT_THREADSTATUS) {
                        try {
                            string result = sms.execute(task.message, 5, task.ipport, task.authenticationMode, task.isKeepAlive);
                            this.Invoke(new showRpt(this.showRpt), result, task.messageType);
                            if ((task.messageType <= 1 && result.Length < 32) || result.Length < 100) { 
                                Thread.Sleep(5000);
                            }
                        } catch (Exception ex) {
                            log.ErrorFormat("接收状态报告线程内层异常,Error:{0}",  ex.Message);
                        }
                    }
                } catch (System.Exception ex) {
                    log.ErrorFormat("接收状态报告线程异常终止,Error:{0}", ex.Message);
                } finally {
                    RPT_THREADSTATUS = false;
                }
                //释放
                if (task.Handle != null) {
                    task.Handle.Unregister(null);
                }
            }
        }
        private void button4_Click(object sender, EventArgs e) {
            RPT_THREADSTATUS = false;
        }


        public void showMo(string result, int messagetype) {
            string s = txt_result_mo.Text;
            if (s.Length > 20000) {
                txt_result_mo.Text = result + "\r\n";
            } else {
                txt_result_mo.Text += result + "\r\n";
            }
            log.Info(result);
        }
        public void showRpt(string result, int messagetype) {
            string s = txt_result_rpt.Text;
            if (s.Length > 20000) {
                txt_result_rpt.Text = result+"\r\n";
            } else {
                txt_result_rpt.Text += result + "\r\n";
            }

            log.Info(result);
        }

    }
}

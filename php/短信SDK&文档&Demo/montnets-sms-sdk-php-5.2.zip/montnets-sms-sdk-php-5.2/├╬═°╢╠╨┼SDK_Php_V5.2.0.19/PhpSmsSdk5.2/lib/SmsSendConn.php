<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-13
 * Time: 10:14
 * @功能概要：发送管理类
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('SmsSendBiz.php');
require_once('EncryptUtil.php');
require_once('ValidateParamTool.php');
require_once('GlobalValue.php');
require_once('NotLog.php');
class SmsSendConn
{
    /**
     * 错误代码
     */
    public $error_code;

    /**
     * 获取错误代码文件内容
     */
    public function get_error()
    {
        $error=include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'ErrorCode.php');//获取错误代码
        return $error;
    }
    /**
     * 是否保持长连接,默认情况下为长连接
     * $isKeepAlive：true:长连接，false：短连接
     */
    public function SmsSendConn($isKeepAlive=true)
    {
        if($isKeepAlive==true)
        {
            $GLOBALS['KEEPALIVE'] = 1;//保持长连接
        }
        else
        {
            $GLOBALS['KEEPALIVE'] = 0;//不保持长连接
        }
    }
    /**
     * 单条发送
     * $data：请求提交数据
     */
    public function singleSend($data = array())//单条发送
    {
        $this->error_code = $this->get_error();//获取错误代码参数
        $SmsSendBiz=new SmsSendBiz();
        $Encrypt = new EncryptUtil();
        $Vakidate = new ValidateParamTool();
        $NotLog = new NotLog();
        try {
        $data=$Encrypt->single_filter($data);//字段过滤
            $vali = $Vakidate->vali_ordina_send($data);//验证单条短信数据
            if ($vali === true)//验证无错误
            {
                $data['content'] = $Encrypt->encrypt_content($data['content']);//短信内容加密
                $result=$SmsSendBiz->send_user($data,'single_send');//根据单条发送类型进行请求并返回值
                return $result;
            }
            $vali['returnValue'] = null;
            return $vali;//返回验证结果
        }
        catch (Exception $e) //检测到的异常处理
        {
            $NotLog->deposit_error_log($e->getMessage(),'单条发送失败！错误码:'.$this->error_code['ERROR_310001']);//日志记录捕获的异常消息
            $result['result'] =$this->error_code['ERROR_310001'];
            $result['returnValue'] = null;
            return $result;//返回异常结果

        }
    }
    /**
     * 相同内容群发
     * $data：请求提交数据
     */
    public function batchSend($data = array())
    {
        $this->error_code = $this->get_error();//获取错误代码参数
        $SmsSendBiz=new SmsSendBiz();
        $Encrypt = new EncryptUtil();
        $Vakidate = new ValidateParamTool();
        $NotLog = new NotLog();
        try {
        $data=$Encrypt->batch_filter($data);//字段过滤
            $vali = $Vakidate->vali_ordina_send($data);//验证相同内容短信群发数据
            if ($vali === true)//验证无错误
            {
                $mobile=explode(",",$data['mobile']);//电话号码转化为维数组
                $first_mobile=$mobile[0];//获取第一个电话号码
                $data['content'] = $Encrypt->encrypt_content($data['content']);//短信内容加密
                $result=$SmsSendBiz->send_user($data,'batch_send',$first_mobile);//根据相同内容群发类型进行请求并返回值
                return $result;
            }
            $vali['returnValue'] = null;
            return $vali;//返回验证结果
        }
        catch (Exception $e) //检测到的异常处理
        {
            $NotLog->deposit_error_log($e->getMessage(),'相同内容发送失败！错误码:'.$this->error_code['ERROR_310002']);//日志记录捕获的异常消息
            $result['result'] =$this->error_code['ERROR_310002'];
            $result['returnValue'] = null;
            return $result;//返回异常结果
        }
    }
    /**
     * 个性化群发
     * $data：请求提交数据
     */
    public function multiSend($data = array())
    {
        $this->error_code = $this->get_error();//获取错误代码参数
        $SmsSendBiz=new SmsSendBiz();
        $Encrypt = new EncryptUtil();
        $Vakidate = new ValidateParamTool();
        $NotLog = new NotLog();
        try {
        $data=$Encrypt->multi_filter($data);//字段过滤
            $vali = $Vakidate->vali_multi_send($data);//验证个性化短信群发数据
            if ($vali === true)//验证无错误
            {
                $first_mobile = reset($data['multimt'])['mobile'];//获取multimt包结构中第一个电话号码
                $data['multimt'] = json_encode($Encrypt->multi_encrypt_content($data['multimt']));//包内的短信内容全部加密并将整个multimt数组结构装化为JSON结构
                $result=$SmsSendBiz->send_user($data,'multi_send',$first_mobile);//根据个性化群发类型进行请求并返回值
                return $result;
            }
            $vali['returnValue'] = null;
            return $vali;//返回验证结果
        }
        catch (Exception $e) //检测到的异常处理
        {
            $NotLog->deposit_error_log($e->getMessage(),'个性化发送失败！错误码:'.$this->error_code['ERROR_310003']);//日志记录捕获的异常消息
            $result['result'] =$this->error_code['ERROR_310003'];
            $result['returnValue'] = null;
            return $result;//返回异常结果
        }
    }
    /**
     * 查询剩余金额或条数
     * $userid：用户账号
     */
    public function getRemains($userid=null)//查询剩余金额或条数
    {
        $this->error_code = $this->get_error();//获取错误代码参数
        $GlobalValue=new GlobalValue();
        $SmsSendBiz=new SmsSendBiz();
        $Vakidate = new ValidateParamTool();
        $NotLog = new NotLog();
        try {
            $vali = $Vakidate->vali_get($userid);//验证查询余额信息
            if ($vali === true) //用户已传入userid字段
            {
                $data = array();
                $user = $GlobalValue->get_userid(strtoupper($userid));//获取设置好的账号信息
                if (!empty($user)) {
                    $result = $SmsSendBiz->send_ip_dealt($data, $user, 'get_balance');//获取时对账号IP进行处理
                    if ($result['result'] === 0)//获取成功
                    {
                        return $result;//查询成功时返回查询结果
                    }
                    return $result;//查询不成功时返回查询结果
                }
                $NotLog->deposit_log('查询余额时,账号不存在或者账号不可用,错误码:'.$this->error_code['ERROR_310008'].',账号:'.$userid);//日志记录捕获的异常消息
                $result['result'] = $this->error_code['ERROR_310008'];
                return $result;
            }
            return $vali;//返回验证结果
        }
        catch (Exception $e) //检测到的异常处理
        {
            $NotLog->deposit_error_log($e->getMessage(),'查询余额失败！错误码:'.$this->error_code['ERROR_310006']);//日志记录捕获的异常消息
            $result['result'] =$this->error_code['ERROR_310006'];
            return $result;//返回异常结果
        }
    }
    /**
     * 获取上行
     * $userid：用户账号
     * $retsize：获取上行条数
     */
    public function getMo($userid=null,$retsize=null)//获取上行
    {
        $this->error_code = $this->get_error();//获取错误代码参数
        $data=array();//初始化数组
        $GlobalValue=new GlobalValue();
        $SmsSendBiz=new SmsSendBiz();
        $Vakidate = new ValidateParamTool();
        $NotLog = new NotLog();
        try {
            $vali = $Vakidate->vali_get($userid);//验证获取上行的信息
            if ($vali === true) //用户已传入userid字段
            {
                if(!empty($retsize))//已经设置获取条数且不为空
                {
                    $data['retsize'] = $retsize;
                }
                $user = $GlobalValue->get_userid(strtoupper($userid));//获取设置好的账号信息
                if (!empty($user)) {
                    $result = $SmsSendBiz->send_ip_dealt($data, $user, 'get_mo');//获取时对账号IP进行处理
                    if($result['result'] === 0&&empty($result['mos'])) //获取成功但无mos的值
                    {
                            $result['mos'] = '';
                            $NotLog->deposit_log('上行mos为空,错误码:'.$this->error_code['ERROR_300019'].',账号:'.$userid);//日志记录捕获的异常消息
                            $result['result'] = $this->error_code['ERROR_300019'];
                    }
                    return $result;
                }
                $NotLog->deposit_log('获取上行时,账号不存在或者账号不可用,错误码:'.$this->error_code['ERROR_310008'].',账号:'.$userid);//日志记录捕获的异常消息
                $result['result'] = $this->error_code['ERROR_310008'];
                return $result;
            }
            return $vali;//返回验证结果
        }
        catch (Exception $e) //检测到的异常处理
        {
            $NotLog->deposit_error_log($e->getMessage(),'获取上行失败！错误码:'.$this->error_code['ERROR_310004']);//日志记录捕获的异常消息
            $result['result'] =$this->error_code['ERROR_310004'];
            return $result;//返回异常结果
        }
    }
    /**
     * 获取状态报告
     * $userid：用户账号
     * $retsize：获取状态报告条数
     */
    public function getRpt($userid=null,$retsize=null)
    {
        $this->error_code = $this->get_error();//获取错误代码参数
        $data=array();//初始化数组
        $SmsSendBiz=new SmsSendBiz();
        $GlobalValue=new GlobalValue();
        $Vakidate = new ValidateParamTool();
        $NotLog = new NotLog();
        try {
            $vali = $Vakidate->vali_get($userid);//验证获取状态报告的信息
            if ($vali === true) //用户已传入userid字段
            {
                if(!empty($retsize))//已经设置获取条数且不为空
                {
                    $data['retsize'] = $retsize;
                }
                $user = $GlobalValue->get_userid(strtoupper($userid));//获取设置好的账号信息
                if (!empty($user)) {
                    $result = $SmsSendBiz->send_ip_dealt($data, $user, 'get_rpt');//获取时对账号IP进行处理
                    if($result['result'] === 0&&empty($result['rpts'])) //获取成功但无rpts的值
                    {
                            $result['rpts'] = '';
                            $NotLog->deposit_log('状态报告rpts为空,错误码:'.$this->error_code['ERROR_300020'].',账号:'.$userid);//日志记录捕获的异常消息
                            $result['result'] = $this->error_code['ERROR_300020'];
                    }
                    return $result;
                }
                $NotLog->deposit_log('获取状态报告时,账号不存在或者账号不可用,错误码:'.$this->error_code['ERROR_310008'].',账号:'.$userid);//日志记录捕获的异常消息
                $result['result'] = $this->error_code['ERROR_310008'];
                return $result;
            }
            return $vali;//返回验证结果
        }
        catch (Exception $e) //检测到的异常处理
        {
            $NotLog->deposit_error_log($e->getMessage(),'获取状态报告失败！错误码:'.$this->error_code['ERROR_310005']);//日志记录捕获的异常消息
            $result['result'] =$this->error_code['ERROR_310005'];
            return $result;//返回异常结果
        }
    }
}
?>
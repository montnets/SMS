<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-25
 * Time: 14:15
 * @功能概要： 异常IP检测线程
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */

class CheckAccountThread extends \Thread
{
    /**
     * 错误代码
     */
    public $error_code;

    /**
     * 获取错误代码文件内容
     */
    public function get_error()
    {
        $error=include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'ErrorCode.php');//获取错误代码
        return $error;
    }

    /**
     * 线程内部检测任务是否启动，true:启用,false:不启用，目前默认一直启用
     */
    public $ISRUNNING = false;

    /**
     * 停止线程
     */
    public function stopThread()
    {
        $NotLog = new NotLog();
        try {
            $this->ISRUNNING = false;
        } catch (Exception $e) {
            $this->error_code = $this->get_error();//获取错误代码参数
            $NotLog->deposit_error_log($e->getMessage(),'账号检查线程停止失败,错误码:'.$this->error_code['ERROR_310011']);//日志记录捕获的异常消息
        }
    }

    /**
     * 启用线程
     */
    public function startThread()
    {
        $NotLog = new NotLog();
        try {
            if (!$this->ISRUNNING) {
                $this->ISRUNNING = true;
                $GlobalValue = new GlobalValue();
                $GlobalValue->set_thread(1);//将线程状态设置为启用
                // 启动线程
                $this->running();
            }
        } catch (Exception $e) {
            $this->ISRUNNING = false;
            $this->error_code = $this->get_error();//获取错误代码参数
            $NotLog->deposit_error_log($e->getMessage(),'账号检查线程启动失败,错误码:'.$this->error_code['ERROR_310010']);//日志记录捕获的异常消息
        }
    }

    /**
     * 检测主IP异常
     */
    public function running()
    {
        $NotLog = new NotLog();
        try {
            while ($this->ISRUNNING) {
                try
                {
                    static $count=0;//设置静态变量作为计数单位进行计数
                    $count++;//计数单位每次加一
                    $count_num=30;//计数阈值
                    $this->get_abnormal_ip($count,$count_num);//检测IP异常，传入计数阈值及当前计数次数
                    sleep(2);//睡眠2秒
                    if($count==$count_num)//检查$count的值为30时
                    {
                        $count=0;//将计数单位初始化为0
                    }
				}
                catch (Exception $e)
				{
                    $count=0;//将计数单位初始化为0
                    $NotLog->deposit_error_log($e->getMessage(), "检测主IP是否正常，睡眠2秒，失败！");//日志记录捕获的异常消息
                }
            }
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), "异常主IP集合检测失败！");//日志记录捕获的异常消息
        }
    }

    /**
     * 查询余额方法
     * $data：请求提交数据
     * $ip：请求IP及端口地址
     * $mean：请求类型
     */
    public function balance($data, $ip, $mean)//查询余额方法
    {
        $NotLog = new NotLog();
        $GlobalValue = new GlobalValue();
        try {
            $url = $GlobalValue->get_url();//获取已设置的请求地址
            $url = 'http://' . $ip . $url . $mean;//拼接请求地址
            $result = CHttp::PostCURL($url, $data);//对应请求地址以短链接形式提交数据
            return $result;//对请求的返回参数进行返回
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'检测账号['.$data['userid'].']主IP是否可用时,进行请求出错！');//日志记录捕获的异常消息
        }
    }


    /**
     * 将异常集合中的正常IP抛出
     * $userid：用户账号
     */
    public function out_abnormal_ip($userid)//将异常集合中的正常IP抛出
    {
        $NotLog = new NotLog();
        $GlobalValue = new GlobalValue();
        try {
        $abnormal_ip = $GlobalValue->get_abnormal_ip();//获取缓存异常IP信息
        unset($abnormal_ip[$userid]);//将对应当前账号的异常IP从集合中抛出
        $GlobalValue->set_abnormal_ip($abnormal_ip);//存入异常主IP集合中
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'检测账号['.$userid.']主IP已恢复正常,未能将异常集合中的主IP信息移除！');//日志记录捕获的异常消息
        }
    }

    /**
     * 通过查询余额检测IP异常集合内的主IP
     * $count 当前计数次数
     * $count_num 当前计数阈值
     */
    public function get_abnormal_ip($count,$count_num)//通过查询余额检测IP异常集合内的主IP；
    {
        $Encrypt = new EncryptUtil();
        $GlobalValue = new GlobalValue();
        $NotLog = new NotLog();
        try{
            $abnormal_ip = $GlobalValue->get_abnormal_ip();//获取缓存异常IP信息
            $user = $GlobalValue->get_user();//获取所有账号信息
            if (!empty($abnormal_ip))//涵盖异常IP集合
            {
                foreach ($abnormal_ip as $k => $v) {
                    foreach ($user as $k1 => $v1) {
                        if ($k == $user[$k1]['userid']) {
                            $data['userid'] = $user[$k1]['userid'];//获取当前的账号
                            $data['pwd'] = $user[$k1]['pwd'];//获取当前的明文密码
                            $pwd = $Encrypt->encrypt_pwd($user[$k1]['userid'], $user[$k1]['pwd']);//对原密码进行格式封装
                            $data['pwd'] = $pwd['pwd'];//获取格式封装后的密码
                            $data['timestamp'] = $pwd['time'];//获取时间戳
                            $data['pwd'] = md5($data['pwd']);//密码MD5加密
                            $ip = $v['ip'];//获取当前IP及端口信息
                            $data=http_build_query($data);//将请求数据转化为urlencode格式
                            $start_time=microtime(true);//检测起始时间
                            $result = $this->balance($data, $ip, 'get_balance');//发送请求
                            $end_time=microtime(true);//检测结束时间
                            if ($result['result'] === 0)//查询余额成功
                            {
                                 if (array_key_exists($user[$k1]['userid'], $abnormal_ip)) {//如果异常集合中还存在当前账号的异常主IP
                                 $this->out_abnormal_ip($user[$k1]['userid']);//将当前正常的主IP从异常IP集合中抛出
                                 $user[$k1]['state'] = 0;//将用户账号信息主IP设置为启用
                                 $GlobalValue->set_user($user);//更新户用账号信息
                                 $interval_time=($end_time-$start_time)*1000;//间隔时间，转化为毫秒
                                 $NotLog->deposit_log('账号['.$user[$k1]['userid'].']的主IP['.$v['ip'].']恢复正常使用,检测耗时:'.$interval_time.'毫秒');
                               }
                            }
                            else
                            {
                                if($count==$count_num)//检查$count次数，每30次，记录一次日志
                                {
                                    $NotLog->deposit_log('检测账号['.$user[$k1]['userid'].']主IP是否可用时,主IP['.$v['ip'].']不可用');
                                }
                                if($v['isip']===0)//若果存在对应域名
                                {
                                    $analysis_ip=$GlobalValue->analysis_domain_name(array('ipAddress1'=>$user[$k1]['ip']['ipAddress1']));//通过域名再次获取IP
                                    $get_ip=$analysis_ip['ipAddress1']['ip'];//通过域名再次获取IP
                                    if(!empty($get_ip))//已成功通过域名再次获取到IP
                                    {
                                        if($count==$count_num)//检查$count次数，每30次，记录一次日志
                                        {
                                            $NotLog->deposit_log('检测账号[' . $user[$k1]['userid'] . ']主IP是否可用时,通过主域名[' . $user[$k1]['ip']['ipAddress1'] . ']获取到主IP[' . $v['ip'] . ']');
                                        }
                                        if ($get_ip != $v['ip'])//当前获取IP与IP集合中的IP不同
                                        {
                                            if($count==$count_num)//检查$count次数，每30次，记录一次日志
                                            {
                                                $NotLog->deposit_log('检测账号[' . $user[$k1]['userid'] . ']主IP是否可用时,主IP[' . $v['ip'] . ']与通过主域名[' . $user[$k1]['ip']['ipAddress1'] . ']获取到主IP[' . $get_ip . ']不一致,则检测主域名获取的主IP。');
                                            }
                                            $start_time1 = microtime(true);//检测起始时间
                                            $result = $this->balance($data, $get_ip, 'get_balance');//发送请求
                                            $end_time1 = microtime(true);//检测结束时间
                                            if ($result['result'] === 0)//获取成功
                                            {
                                                if (array_key_exists($user[$k1]['userid'], $abnormal_ip)) {//如果异常集合中还存在当前账号的异常主IP
                                                    $this->out_abnormal_ip($user[$k1]['userid']);//将当前正常的主IP从异常IP集合中抛出
                                                    $user[$k1]['state'] = 0;//将用户账号信息主IP设置为启用
                                                    $user[$k1]['analysis_ip']['ip'] = $get_ip;//赋值新的IP到对应账号已解析的IP集合中
                                                    $GlobalValue->set_user($user);//更新户用账号信息
                                                    $interval_time1 = ($end_time1 - $start_time1) * 1000;//间隔时间，转化为毫秒
                                                    $NotLog->deposit_log('检测账号['.$user[$k1]['userid'].']主IP是否可用时,通过主域名['.$user[$k1]['ip']['ipAddress1'].']获取的主IP['.$get_ip.']检测,检测出此主IP可用,检测耗时:'.$interval_time1.'毫秒。
                                                    账号的主IP从['.$v['ip'].']换成通过主域名获取的主IP['.$get_ip.'],主IP可正常使用。');
                                                }
                                            }
                                            else
                                            {
                                                if($count==$count_num)//检查$count次数，每30次，记录一次日志
                                                {
                                                    $NotLog->deposit_log('检测账号['.$user[$k1]['userid'].']主IP是否可用时,通过主域名['.$user[$k1]['ip']['ipAddress1'].']获取的主IP['.$get_ip.']检测,检测出此主IP不可用');
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if($count==$count_num)//检查$count次数，每30次，记录一次日志
                                            {
                                                $NotLog->deposit_log('检测账号['.$user[$k1]['userid'].']主IP是否可用时,主IP['.$v['ip'].']与通过主域名['.$user[$k1]['ip']['ipAddress1'].']获取到主IP['.$get_ip.']一致,这次不检测主域名获取的主IP。');
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if($count==$count_num)//检查$count次数，每30次，记录一次日志
                                        {
                                            $NotLog->deposit_log('检测账号['.$user[$k1]['userid'].']主IP是否可用时,通过主域名['.$user[$k1]['ip']['ipAddress1'].']获取主IP失败');
                                        }
                                    }
                                }
                                else
                                {
                                    if($count==$count_num)//检查$count次数，每30次，记录一次日志
                                    {
                                        $NotLog->deposit_log('检测账号[' . $user[$k1]['userid'] . ']主IP是否可用时,主IP['.$v['ip'].']不可用,该主IP没有对应的主域名,不通过主域名获取主IP进行检测。');
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'异常主IP集合检测失败');//日志记录捕获的异常消息
        }
    }

    /**
     * 执行线程任务
     */
    public function run()
    {
        $NotLog = new NotLog();
        try {
            set_time_limit(0);//永久执行该线程任务
            $this->startThread();//开始线程任务*/
        }catch (Exception $e) {
            $this->ISRUNNING = false;
            $this->error_code = $this->get_error();//获取错误代码参数
            $NotLog->deposit_error_log($e->getMessage(),'账号检查线程启动失败,错误码:'.$this->error_code['ERROR_310010']);//日志记录捕获的异常消息
        }
    }
}

?>
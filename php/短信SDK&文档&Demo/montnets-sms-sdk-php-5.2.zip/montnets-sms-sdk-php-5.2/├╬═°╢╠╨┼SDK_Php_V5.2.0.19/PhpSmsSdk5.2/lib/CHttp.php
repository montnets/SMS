<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016-10-13
 * Time: 9:08
 * @功能概要： HTTP请求类
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('SmsSendConn.php');
require_once('NotLog.php');
error_reporting(0);
class CHttp
{
    /**
     * $url：请求地址
     * $post_data：请求数据
     * $mean：请求类型
     */
    public static function PostCURL($url,$post_data)
    {
        $NotLog = new NotLog();
        try {
            $error_code=include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'ErrorCode.php');//获取错误代码
            $attributes = array('Accept:text/plain;charset=utf-8', 'Content-Type:application/x-www-form-urlencoded', 'charset=utf-8','Expect:','Connection: Keep-Alive');//请求属性
            $ch = curl_init();//初始化一个会话
            /* 设置验证方式 */
            curl_setopt($ch, CURLOPT_HTTPHEADER, $attributes);//设置访问
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);//设置返回结果为流
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);//设置请求超时时间
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);//设置响应超时时间
            /* 设置通信方式 */
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);//使用urlencode格式请求

            $result = curl_exec($ch);//获取返回结果集
            $result = json_decode($result, true);//将返回结果集json格式解析转化为数组格式

            if (curl_errno($ch) !== 0) //网络问题请求失败
            {
                $result['result'] = $error_code['ERROR_310099'];
                $NotLog->deposit_log('向网关请求失败,错误码:'.$error_code['ERROR_310099']);//日志记录捕获的异常消息
                curl_close($ch);//关闭请求会话
                return $result;
            } else {
                $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($statusCode != 200)//域名问题请求失败
                {
                    $result['result'] = $error_code['ERROR_310099'];
                    $NotLog->deposit_log('短连接请求失败,错误码:'.$error_code['ERROR_310099']);//日志记录捕获的异常消息
                }
                curl_close($ch);//关闭请求会话
                return $result;
            }
        }catch (Exception $e) {
            $result['result'] = $error_code['ERROR_310099'];//输出捕获的异常消息
            $NotLog->deposit_error_log($e->getMessage(), '短连接请求失败,错误码:'.$error_code['ERROR_310099']);//日志记录捕获的异常消息
            return $result;
        }
    }

    /**
     * 长连接请求方法
     * $ip：请求IP
     * $port：请求IP的端口号(必须int类型)
     * $url：请求地址
     * $post_data：请求数据
     * $time 异常情况下请求次数
     */
    public static function PostScoket($ip,$port,$url,$post_data,$time=null)
    {
        $NotLog = new NotLog();
        try {
            $error_code = include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'ErrorCode.php');//获取错误代码
            //各个参数分别表示：地址和端口，２个错误的变量，timeout设置
            $fp = pfsockopen($ip, $port, $errno, $errstr, 30);//打开连接通道
            if (!$fp)//打开连接通道失败
            {
                $result['result'] = $error_code['ERROR_310099'];
                $NotLog->deposit_log('向网关请求失败,错误码:'.$error_code['ERROR_310099'].',打开连接通道失败');//日志记录捕获的异常消息
                return $result;
            }
            else
            {
                $socket = new CHttp();
                $out = "POST " . $url . " HTTP/1.1\r\n";
                $out .= "Host:" . $ip . ":" . $port . "\r\n";
                $out .= "Connection: Keep-Alive\r\n";
                $out .= "Accept:text/plain;charset=utf-8\r\n";
                $out .= "Content-Type:application/x-www-form-urlencoded\r\n";
                $out .= "Content-Length:" . strlen($post_data) . "\r\n\r\n";
                $out .= "${post_data}";
                //fwrite()写入内容
                if (fwrite($fp, $out) == false)//如果请求失败
                {
                    if ($time == null) {
                        fclose($fp);//释放当前端口
                        $result = $socket->PostScoket($ip, $port, $url, $post_data, 1);//重新进行请求并获取返回结果
                    } else {
                        $result['result'] = $error_code['ERROR_310099'];
                        $NotLog->deposit_log('长连接请求失败,错误码:'.$error_code['ERROR_310099']);//日志记录捕获的异常消息
                    }
                    return $result;
                } else {
                    $str = fread($fp, 1024);//获取第一批1024字节的报文内容
                    $result = $str;
                    $first = strlen($result);//第一页数据的字节长度
                    preg_match_all('/HTTP([^<]*)\r\n\r\n/is', $result, $heard);//正则匹配heard内容
                    preg_match_all('/Content-Length: ([^<]*)\r\n/is', $result, $content_len);//正则匹配返回内容长度
                    $statusCode = substr($heard[0][0], 9, 3);//截取请求状态码
                    if ((int)$statusCode == 200) //请求成功
                    {
                        $heard_len = strlen($heard[0][0]);//头部字节长度
                        $all = $heard_len + (int)$content_len[1][0];//请求总字节数

                        $result = substr($result, $heard_len - 1, $first - 1);//去除http报文头部
                        if ($all > 1024) //如果返回的总字节长度大于1024个字节
                        {
                            $read_time = ceil(($all - 1024) / 1024);//剩余读取次数
                            $get_num = 1024;//第一次已经读取了1024字节
                            for ($i = 1; $i <= $read_time; $i++) {
                                if ($i == $read_time)//读取最后一批数据时
                                {
                                    $str = fread($fp, ($all - $get_num));//获取剩余未读取的字节数
                                    $result .= $str;//拼接字符串
                                } else {
                                    $str = fread($fp, 1024);//获取1024个字节数
                                    $result .= $str;//拼接字符串
                                    $get_num += 1024;//已获取条数累加
                                }
                            }
                        }
                        $result = json_decode($result, true);//将返回结果集json格式解析转化为数组格式
                    } else//域名问题请求失败
                    {
                        $result='';//清空result集合
                        $result['result'] = $error_code['ERROR_310099'];
                        $NotLog->deposit_log('长连接请求失败,错误码:'.$error_code['ERROR_310099'].',状态码没有返回200');//日志记录捕获的异常消息
                    }
                    return $result;
                }
            }
        }
        catch (Exception $e) {
            $result['result'] = $error_code['ERROR_310099'];//输出捕获的异常消息
            $NotLog->deposit_error_log($e->getMessage(), '长连接请求失败,错误码:'.$error_code['ERROR_310099']);//日志记录捕获的异常消息
            return $result;
        }
    }
}
?>
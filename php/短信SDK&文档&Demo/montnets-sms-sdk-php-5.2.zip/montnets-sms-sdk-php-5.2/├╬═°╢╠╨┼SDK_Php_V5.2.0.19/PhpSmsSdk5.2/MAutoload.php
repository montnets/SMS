<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016-10-13
 * Time: 8:48
 * @功能概要：自动加载类
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
    function MAutoload($classname)
    {
        $filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lib\\'. $classname . '.php';
        if (is_readable($filename)) {
            require $filename;
        }
    }

    if (version_compare(PHP_VERSION, '5.1.2', '>=')) {
        if (version_compare(PHP_VERSION, '5.3.0', '>=')) {
            spl_autoload_register('MAutoload', true, true);
        } else {
            spl_autoload_register('MAutoload');
        }
    } else {
        function __autoload($classname)
        {
            MAutoload($classname);
        }
    }
?>
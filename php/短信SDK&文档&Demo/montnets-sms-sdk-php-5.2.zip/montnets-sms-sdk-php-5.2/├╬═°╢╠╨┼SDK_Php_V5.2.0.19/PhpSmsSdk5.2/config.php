<?php
/*
 * Created by PhpStorm.
 * Date: 2016-10-13
 * Time: 9:21
 * @功能概要：配置文件
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */

$mw_config = array();

/*
 * 单条发送短信可提交参数
 */
$mw_config['SINGLE_SEND_PARM'] = array('userid','mobile','content','svrtype','exno','custid','packid','exdata');

/*
 * 相同内容发送可提交参数
 */
$mw_config['BATCH_SEND_PARM'] = array('userid','mobile','content','svrtype','exno','custid','packid','exdata');

/*
 * 个性化发送可提交参数
 */
$mw_config['MULTI_SEND_PARM'] = array('userid','packid','multimt');

/*
 * 个性化请求短信包请求参数
 */
$mw_config['MULTI_PACK'] = array('mobile','content','svrtype','exno','custid','exdata');

/*
 * 将参数进行返回
 */
return  $mw_config;
?>
<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-13
 * Time: 9:21
 * @功能概要：全局错误参数
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */

    $error_code=array();

    /*
    * 账号格式不合法
    */
    $error_code['ERROR_300001']= -300001;

    /*
    * 密码格式不合法
    */
    $error_code['ERROR_300002']= -300002;

    /*
    * IP和端口信息不合法
    */
    $error_code['ERROR_300003']= -300003;

    /*
    * IP不合法
    */
    $error_code['ERROR_300004']= -300004;

    /*
    * 端口不合法
    */
    $error_code['ERROR_300005']= -300005;

    /*
    * 手机号码格式不合法
    */
    $error_code['ERROR_300006']= -300006;

    /*
    * 短信内容长度不合法
    */
    $error_code['ERROR_300007']= -300007;

    /*
    * 扩展子号不合法
    */
    $error_code['ERROR_300008']= -300008;

    /*
    * 流水号不合法
    */
    $error_code['ERROR_300009']= -300009;

    /*
    * 密码加密失败
    */
    $error_code['ERROR_300010']= -300010;

    /*
    * 业务类型不合法
    */
    $error_code['ERROR_300011']= -300011;

    /*
    * exdata不合法
    */
    $error_code['ERROR_300012']= -300012;

    /*
    * 发送优先级不合法
    */
    $error_code['ERROR_300013']= -300013;

    /*
    * 个性化群发发送条数不在0到100之间
    */
    $error_code['ERROR_300014']= -300014;

    /*
    * Message对象为空
    */
    $error_code['ERROR_300015']= -300015;

    /*
    * msgId参数为空或者msgId长度不为0
    */
    $error_code['ERROR_300016']= -300016;

    /*
    * 账号或者密码错误
    */
    $error_code['ERROR_300017']= -300017;

    /*
    * 发送类型错误
    */
    $error_code['ERROR_300018']= -300018;

    /*
    * 上行mos为空或者mos集合大于0
    */
    $error_code['ERROR_300019']= -300019;

    /*
    * 状态报告rpts为空或者rpts集合大于0
    */
    $error_code['ERROR_300020']= -300020;

   /*
   * 请求路径为空
   */
    $error_code['ERROR_300021']= -300021;

   /*
   * 是否需要日志设置不合法
   */
   $error_code['ERROR_300023']= -300023;

    /*业务类错误-31开头*/
    /*
    * 单条发送失败
    */
    $error_code['ERROR_310001']= -310001;

    /*
    * 相同内容发送失败
    */
    $error_code['ERROR_310002']= -310002;

    /*
    * 个性发送失败
    */
    $error_code['ERROR_310003']= -310003;

    /*
    * 获取余额失败
    */
    $error_code['ERROR_310006']= -310006;

    /*
    * 获取上行失败
    */
    $error_code['ERROR_310004']= -310004;

    /*
    * 获取状态报告失败
    */
    $error_code['ERROR_310005']= -310005;

    /*
    * 设置账号信息失败
    */
    $error_code['ERROR_310007']= -310007;

    /*
     * 账号不存在或者账号不可用
     */
    $error_code['ERROR_310008']= -310008;

    /*
     * 无可用的账号
     */
    $error_code['ERROR_310009']= -310009;

    /*
     * 设置账号检查线程启动失败
     */
    $error_code['ERROR_310010']= -310010;

    /*
     * 设置账号检查线程停止失败
     */
    $error_code['ERROR_310011']= -310011;

    /*
     * 设置全局参数失败
     */
    $error_code['ERROR_310012']= -310012;

    /*
     * 移除设置账号失败
     */
    $error_code['ERROR_310013']= -310013;

   /*
    * 该账号在账号列表不存在，无需移除
    */
    $error_code['ERROR_310014']= -310014;

    /*
     * http请求失败
     */
    $error_code['ERROR_310099']= -310099;

    /*
     * 将对应的错误提示参数返回
     */
    return $error_code;

?>


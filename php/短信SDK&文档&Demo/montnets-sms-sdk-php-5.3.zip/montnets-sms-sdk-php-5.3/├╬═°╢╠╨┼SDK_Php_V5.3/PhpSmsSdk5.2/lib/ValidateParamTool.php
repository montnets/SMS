<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-14
 * Time: 14:30
 * @功能概要：参数合法性验证类
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('EncryptUtil.php');
require_once('GlobalValue.php');
require_once('NotLog.php');
class ValidateParamTool{
        /**
         * 错误代码
         */
        public $error_code;

        /**
         * 获取错误代码文件内容
         */
        public function get_error()
        {
            $error=include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'ErrorCode.php');//获取错误代码
            return $error;
        }

        /*
         * 请求地址验证
         * $url：请求地址
        */
        public function vali_url($url)
        {
            $NotLog = new NotLog();
           try{
                $url_length=strlen($url);//获取请求地址长度
                $this->error_code = $this->get_error();//获取错误代码参数
                if($url_length==0)
                {
                        return array('result'=>$this->error_code['ERROR_300021']);//返回错误代码
                }
                return true;//验证通过
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证请求地址是否合法失败');//日志记录捕获的异常消息
           }
        }
        /*
        * 是否需要日志验证
        * $log：是否需要日志
       */
        public function vali_log($log)
        {
            $NotLog = new NotLog();
            try{
                $this->error_code = $this->get_error();//获取错误代码参数
                if($log===0||$log===1)//设置日志时是否为数字类型的1或0
                {
                    return true;//验证通过
                }
                return array('result'=>$this->error_code['ERROR_300023']);//返回错误代码
            }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(),'验证是否需要日志是否合法失败');//日志记录捕获的异常消息
            }
        }
        /*
         * 是否已经设置请求地址验证
         */
        public function vali_set_url()
        {
           $NotLog = new NotLog();
           $GlobalValue=new GlobalValue();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                $url=$GlobalValue->get_url();//获取已设置的请求地址
                if(empty($url))
                {
                    return array('result'=>$this->error_code['ERROR_300021']);//返回错误代码
                }
                return true;//验证通过
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证是否已经设置过请求地址失败');//日志记录捕获的异常消息
           }
        }
        /*
         * 是否已经设置用户信息
         */
        public function vali_set_user()
        {
            $NotLog = new NotLog();
            $GlobalValue=new GlobalValue();
            try{
                   $this->error_code = $this->get_error();//获取错误代码参数
                   $user=$GlobalValue->get_user();//获取已设置好的用户信息
                   if(empty($user))
                   {
                       return array('result'=>$this->error_code['ERROR_310009']);//返回错误代码
                   }
                   return true;//验证通过
                }catch (Exception $e) {
                 $NotLog->deposit_error_log($e->getMessage(),'验证是否已经设置过用户账号信息失败');//日志记录捕获的异常消息
                }
        }
        /*
         * 数据验证
         * $userid：用户账号
         */
        public function vali_usreid($userid)//验证帐号格式
        {
           $NotLog = new NotLog();
           try{
               $this->error_code = $this->get_error();//获取错误代码参数
               if(!empty($userid)&&!ctype_space($userid))//用户名不为空或空格组成的空字符串
               {
                   $userid_length = strlen($userid);//获取用户名长度
                   if ($userid_length > 6 || $userid_length <= 0) {
                       $NotLog->deposit_log('验证账号不合法,错误码:' . $this->error_code['ERROR_300001'] . ',账号:' . $userid);//日志记录捕获的异常消息
                       return array('result' => $this->error_code['ERROR_300001']);//返回错误代码
                   }
                   return true;//验证通过
               }
               $NotLog->deposit_log('验证账号不合法,错误码:' . $this->error_code['ERROR_300001'] . ',账号:' . $userid);//日志记录捕获的异常消息
               return array('result' => $this->error_code['ERROR_300001']);//返回错误代码
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证账号是否合法失败,账号:'.$userid);//日志记录捕获的异常消息
           }
        }
        /*
         * 验证密码格式
         * $pwd：用户密码
         */
        public function vali_pwd($pwd)
        {
          $NotLog = new NotLog();
          try{
                $this->error_code = $this->get_error();//获取错误代码参数
              if(!empty($pwd)&&!ctype_space($pwd)) //密码不为空或空格组成的空字符串
              {
                  $pwd_length = strlen($pwd);//获取用户名长度
                  if ($pwd_length > 32 || $pwd_length <= 0)//密码长度在1~32位之间
                  {
                      $NotLog->deposit_log('验证密码不合法,错误码:' . $this->error_code['ERROR_300002']);//日志记录捕获的异常消息
                      return array('result' => $this->error_code['ERROR_300002']);//返回错误代码
                  }
                  return true;//验证通过
              }
              $NotLog->deposit_log('验证密码不合法,错误码:' . $this->error_code['ERROR_300002']);//日志记录捕获的异常消息
              return array('result' => $this->error_code['ERROR_300002']);//返回错误代码
          }catch (Exception $e) {
              $NotLog->deposit_error_log($e->getMessage(),'验证密码是否合法失败。');//日志记录捕获的异常消息
          }
        }
        /*
         * 验证主IP及端口
         * $ip：请求主IP
         */
        public function vali_ip($ip)
        {
           $NotLog = new NotLog();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                if(!empty($ip)&&!ctype_space($ip))//IP不为空或空格组成的空字符串
                {
                        if($port_position=strpos($ip,':'))//判断是否为IP地址
                        {
                              $ip_str=substr($ip,0,$port_position-1);//截取IP地址
                                if(!empty($ip_str))//IP地址不为空
                                {
                                     $ip_len=strlen($ip);//获取IP长度
                                     $port_str=substr($ip,$port_position+1,$ip_len);//截取端口号
                                        if(!empty($port_str)&&is_numeric($port_str))//端口不为空且为数字
                                        {
                                                return true;
                                        }
                                        return array('result'=>$this->error_code['ERROR_300005']);//返回错误代码
                                }
                                return array('result'=>$this->error_code['ERROR_300004']);//返回错误代码
                        }
                        return true;//验证通过
                }
               $NotLog->deposit_log('验证IP和端口信息不合法,错误码:'.$this->error_code['ERROR_300003'].',IP和端口信息:'.$ip);//日志记录捕获的异常消息
               return array('result'=>$this->error_code['ERROR_300003']);//返回错误代码
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证IP和端口信息是否合法失败,IP和端口信息:'.$ip);//日志记录捕获的异常消息
           }
        }
        /*
         * 验证备IP及端口
         * $ip：请求备IP
         */
        public function vali_spare_ip($ip)
        {
          $NotLog = new NotLog();
          try{
                $this->error_code = $this->get_error();//获取错误代码参数
                if(!empty($ip)&&!ctype_space($ip)) //IP不为空或空格组成的空字符串
                {
                        if ($port_position = strpos($ip, ':'))//判断是否有端口号
                        {
                                $ip_str = substr($ip,0,$port_position);//截取IP地址
                                if (!empty($ip_str))//IP地址不为空
                                {
                                        $ip_len = strlen($ip);//获取IP长度
                                        $port_str = substr($ip, $port_position + 1, $ip_len);//截取端口号
                                        if (!empty($port_str) && is_numeric($port_str))//端口不为空且为数字
                                        {
                                                return true;
                                        }
                                        return array('result'=>$this->error_code['ERROR_300005']);//返回错误代码
                                }
                                return array('result'=>$this->error_code['ERROR_300004']);//返回错误代码
                        }
                        return true;//验证通过
                }
               $NotLog->deposit_log('验证IP和端口信息不合法,错误码:'.$this->error_code['ERROR_300003'].',IP和端口信息:'.$ip);//日志记录捕获的异常消息
               return array('result'=>$this->error_code['ERROR_300003']);//返回错误代码
          }catch (Exception $e) {
              $NotLog->deposit_error_log($e->getMessage(),'验证IP和端口信息是否合法失败,IP和端口信息:'.$ip);//日志记录捕获的异常消息
          }
        }
        /*
        * 验证手机号码
        * $mobile：发送的手机号码(单个或多个)
        */
        public function vali_mobile($mobile)
        {
           $NotLog = new NotLog();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                $mobile=explode(",",$mobile);//电话号码转化为维数组
                foreach($mobile as $k=>$v)
                {
                        if(empty($mobile[$k])||ctype_space($mobile[$k])||!is_numeric($mobile[$k]))//电话号码为空或为空格组成的空字符串或不为数字
                        {
                            $NotLog->deposit_log('验证手机号码不合法,错误码:'.$this->error_code['ERROR_300006'].',错误手机号码:'.$mobile[$k]);//日志记录捕获的异常消息
                            return array('result'=>$this->error_code['ERROR_300006']);//返回错误代码
                        }
                }
                return true;
           }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(),'验证手机号码是否合法失败,手机号码:'.$mobile);//日志记录捕获的异常消息
           }
        }
       /*
       * 验证短信内容
        * $content：短信内容
       */
        public function vali_content($content)
        {
            $NotLog = new NotLog();
            $Encrypt=new EncryptUtil();
            try{
                $this->error_code = $this->get_error();//获取错误代码参数
                if(!empty($content)&&!ctype_space($content)) //短信内容不为空或空格组成的空字符串
                {
                    $con_len = $Encrypt->utf8_strlen($content);//获取字符长度(中文，英文都视为1个字)
                    if ($con_len <= 0 || $con_len > 350)//验证短信内容长度在1~350之间
                    {
                        $NotLog->deposit_log('验证短信内容不合法,错误码:' . $this->error_code['ERROR_300007'] . ',短信内容为空或超长,短信内容:' . $content);//日志记录捕获的异常消息
                        return array('result' => $this->error_code['ERROR_300007']);//返回错误代码
                    }
                    return true;//验证通过
                }
                $NotLog->deposit_log('验证短信内容不合法,错误码:' . $this->error_code['ERROR_300007'] . ',短信内容为空或超长,短信内容:' . $content);//日志记录捕获的异常消息
                return array('result' => $this->error_code['ERROR_300007']);//返回错误代码
            }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(),'验证短信内容是否合法失败,短信内容:'.$content);//日志记录捕获的异常消息
            }
        }
       /*
       * 验证扩展号
       * $exno：扩展号
       */
        public function vali_exno($exno)
        {
           $NotLog = new NotLog();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                $exno_len=strlen($exno);//获取扩展号长度
                if(is_numeric($exno)) //验证扩展号是否为数字
                {
                        if ($exno_len > 6)//验证扩展号内容长度大于6位(可为空)
                        {
                                $NotLog->deposit_log('验证扩展子号不合法,错误码:'.$this->error_code['ERROR_300008'].',扩展子号超长,扩展子号:'.$exno);//日志记录捕获的异常消息
                                return array('result'=>$this->error_code['ERROR_300008']);//返回错误代码
                        }
                        return true;//验证通过
                }
                $NotLog->deposit_log('验证扩展子号不合法,错误码:'.$this->error_code['ERROR_300008'].',扩展子号:'.$exno);//日志记录捕获的异常消息
                return array('result'=>$this->error_code['ERROR_300008']);//返回错误代码
           }catch (Exception $e) {
                 $NotLog->deposit_error_log($e->getMessage(),'验证扩展子号是否合法失败,扩展子号:'.$exno);//日志记录捕获的异常消息
           }
        }
       /*
       * 验证自定义流水号
       * $custid：自定义流水号
       */
        public function vali_custid($custid)
        {
           $NotLog = new NotLog();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                $custid_len=strlen($custid);//获取自定义流水号长度
                if($custid_len>64||ctype_space($custid))//验证流水号内容长度大于64位(可为空)或为空格组成的空字符串
                {
                        $NotLog->deposit_log('验证流水号不合法,错误码:'.$this->error_code['ERROR_300009'].',流水号:'.$custid);//日志记录捕获的异常消息
                        return array('result'=>$this->error_code['ERROR_300009']);//返回错误代码
                }
               return true;
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证流水号是否合法失败,流水号:'.$custid);//日志记录捕获的异常消息
           }
        }
       /*
       * 验证业务类型
       * $svrtype：业务类型
       */
        public function vali_svrtype($svrtype)
        {
           $NotLog = new NotLog();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                $svrtype_len=strlen($svrtype);//获取业务类型长度
                if($svrtype_len>32||ctype_space($svrtype))//验证业务类型长度大于32位(可为空)或为空格组成的空字符串
                {
                        $NotLog->deposit_log('验证业务类型不合法,错误码:'.$this->error_code['ERROR_300011'].',业务类型:'.$svrtype);//日志记录捕获的异常消息
                        return array('result'=>$this->error_code['ERROR_300011']);//返回错误代码
                }
                return true;//验证通过
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证业务类型是否合法失败,业务类型:'.$svrtype);//日志记录捕获的异常消息
           }
        }
       /*
       * 验证自定义扩展数据
       * $exdata：自定义扩展数据
       */
        public function vali_exdata($exdata)
        {
           $NotLog = new NotLog();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                $exdata_len=strlen($exdata);//获取自定义扩展数据长度
                if($exdata_len>64||ctype_space($exdata))//验证自定义扩展数据长度大于64位(可为空)或为空格组成的空字符串
                {
                        $NotLog->deposit_log('验证自定义扩展数据不合法,错误码:'.$this->error_code['ERROR_300012'].',自定义扩展数据:'.$exdata);//日志记录捕获的异常消息
                        return array('result'=>$this->error_code['ERROR_300012']);//返回错误代码
                }
                return true;//验证通过
           }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(),'验证自定义扩展数据是否合法失败,自定义扩展数据:'.$exdata);//日志记录捕获的异常消息
           }
        }
       /*
       * 验证发送优先级
       * $priority：发送优先级
       */
        public function vali_priority($priority)
        {
           $NotLog = new NotLog();
           try{
                $this->error_code = $this->get_error();//获取错误代码参数
                if(is_numeric($priority))//验证所设置的发送优先级是否位数字
                {
                       if($priority>=1&&$priority<=9&&strlen($priority)==1)//验证优先级数字在1~9范围以内
                       {
                               return true;//验证通过
                       }
                       $NotLog->deposit_log('验证发送优先级不合法,错误码:'.$this->error_code['ERROR_300013']);//日志记录捕获的异常消息
                       return array('result'=>$this->error_code['ERROR_300013']);//返回错误代码
                }
                $NotLog->deposit_log('验证发送优先级不合法,错误码:'.$this->error_code['ERROR_300013']);//日志记录捕获的异常消息
                return array('result'=>$this->error_code['ERROR_300013']);//返回错误代码
           }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(),'验证发送优先级是否合法失败');//日志记录捕获的异常消息
           }
        }
      /*
      * 验证个性化群发条数
      * $data：multimt结构数据
      */
        public function vali_multimt($data)
        {
           $NotLog = new NotLog();
           try{
               $this->error_code = $this->get_error();//获取错误代码参数
               if(!empty($data))//数组不为空
               {
                    $count=0;//初始化multimt结构数据条数
                    foreach($data as $k=>$v)
                    {
                            $count++;
                    }
                    if($count>100)//如果个性化群发条数大于100条
                    {
                            $NotLog->deposit_log('验证个性化群发条数不合法,错误码:'.$this->error_code['ERROR_300014'].',个性化群发条数超过最大可发送条数');//日志记录捕获的异常消息
                            return array('result'=>$this->error_code['ERROR_300014']);//返回错误代码
                    }
                    return true;//验证通过
               }
               else
               {
                       $NotLog->deposit_log('验证个性化群发条数不合法,错误码:'.$this->error_code['ERROR_300014']);//日志记录捕获的异常消息
                       return array('result'=>$this->error_code['ERROR_300014']);//返回错误代码
               }
           }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(),'验证个性化群发条数是否合法失败');//日志记录捕获的异常消息
           }
        }
        /*
         * 验证一般发送类型短信请求数据(单条发送，相同内容群发)
         * $data：单条或相同内容发送请求数据
         */
        public function vali_ordina_send($data)
        {
          $NotLog = new NotLog();
          try{
                $is_set_ulr=$this->vali_set_url();//是否已设置过请求路径
                $is_set_user=$this->vali_set_user();//是否已经设置过账号
                if($is_set_ulr===true)//已设置过请求路径
                {
                   if($is_set_user===true)//已设置过账号
                   {
                           $data=$this->necessary_field($data);//必要字段为空处理
                           $result=$this->vali_public($data);//验证请求公共数据
                           return $result;//返回验证结果
                   }
                   return $is_set_user;
                }
                return $is_set_ulr;
          }catch (Exception $e) {
              $NotLog->deposit_error_log($e->getMessage(),'验证单条发送或相同内容群发的请求数据失败');//日志记录捕获的异常消息
          }
        }
        /*
         * 验证个性化群发信息
         * $data：个性化群发信息请求数据
         */
        public function vali_multi_send($data)
        {
          $NotLog = new NotLog();
          try{
             $is_set_ulr=$this->vali_set_url();//是否已设置过请求路径
             $is_set_user=$this->vali_set_user();//是否已经设置过账号
             if($is_set_ulr===true) //已设置请求路径
             {
                 if($is_set_user===true)//已设置账号信息
                 {
                          if (!array_key_exists('multimt',$data))//用户遗漏字段参数给于补充并填充null,在下列验证方法中验证并返回错误码
                          {
                                $data['multimt']=null;
                           }
                            $multimt = $this->vali_multimt($data['multimt']);//验证个性化发送条数
                            if ($multimt!==true)//个性化发送条数不正确
                            {
                                    return $multimt;
                            }
                            foreach ($data['multimt']as $k => $v)//数据验证
                            {
                                $v=$this->necessary_field($v);//必要字段为空处理
                                $result=$this->vali_public($v);//验证请求公共数据
                                if($result!==true) //单条验证不通过
                                {
                                    return $result;//返回验证结果
                                }
                            }
                            return true;//验证通过
                 }
                 return $is_set_user;
             }
             return $is_set_ulr;
          }catch (Exception $e) {
              $NotLog->deposit_error_log($e->getMessage(),'验证个性化群发的请求数据失败');//日志记录捕获的异常消息
          }
        }
        /*
         * 验证设置账号
         * $data：账号信息
         */
        public function vali_setAccountInfo($data)
        {
           $NotLog = new NotLog();
           try{
                $key_value=array('userid','pwd','priority');//用户遗漏字段参数给于补充并填充null,在下列验证方法中验证并返回错误码
                foreach($key_value as $k=>$v)
                {
                        if (!array_key_exists($v,$data))
                        {
                                $data[$v]=null;
                        }
                }
                foreach ($data as $k => $v)//用户名、密码、发送优先级数据验证
                {
                        switch ($k) {
                                case 'userid':
                                        $userid = $this->vali_usreid($data[$k]);//验证用户名
                                        if ($userid!==true) {
                                                return $userid;
                                        }
                                        break;
                                case 'pwd':
                                        $pwd = $this->vali_pwd($data[$k]);//验证密码
                                        if ($pwd!==true) {
                                                return $pwd;
                                        }
                                        break;
                                case 'priority':
                                        $priority = $this->vali_priority($data[$k]);//验证密码
                                        if ($priority!==true) {
                                                return $priority;
                                        }
                                        break;

                        }
                    }
               foreach($data['ip'] as $k=>$v)//主备IP数据验证
               {
                   switch ($k) {
                       case 'ipAddress1':
                           $ip1 = $this->vali_ip($data['ip'][$k]);//验证主IP
                           if ($ip1 !== true) {
                               return $ip1;
                           }
                           break;
                       case 'ipAddress2':
                           $ip2 = $this->vali_spare_ip($data['ip'][$k]);//验证备IP
                           if ($ip2 !== true) {
                               return $ip2;
                           }
                           break;
                       case 'ipAddress3':
                           $ip3 = $this->vali_spare_ip($data['ip'][$k]);//验证备IP
                           if ($ip3 !== true) {
                               return $ip3;
                           }
                           break;
                       case 'ipAddress4':
                           $ip4 = $this->vali_spare_ip($data['ip'][$k]);//验证备IP
                           if ($ip4 !== true) {
                               return $ip4;
                           }
                           break;
                   }
               }
                return true;//验证通过
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证账号设置信息失败');//日志记录捕获的异常消息
           }
        }
        /*
        * 验证获取的信息
         * $user：用户账号信息
        */
        public function vali_get($user)
        {
           $NotLog = new NotLog();
           try{
                $is_set_ulr=$this->vali_set_url();//是否已设置过请求路径
                $is_set_user=$this->vali_set_user();//是否已经设置过账号
                if($is_set_ulr===true) //已设置请求路径
                {
                  if($is_set_user===true)//已设置账号信息
                  {
                          $userid = $this->vali_usreid($user);//验证用户名
                          if ($userid !== true) {
                                  return $userid;
                          }
                          return true;//验证通过
                  }
                  return $is_set_user;
                }
               return $is_set_ulr;
           }catch (Exception $e) {
               $NotLog->deposit_error_log($e->getMessage(),'验证已获取到的用户账号信息失败');//日志记录捕获的异常消息
           }
        }
        /*
        * 公共参数验证
         * $data：请求数据
        */
        public function vali_public($data)
        {
            $NotLog = new NotLog();
            try{
                foreach ($data as $k => $v)//数据验证
                {
                        switch ($k) {
                                case'mobile':
                                        $mobile = $this->vali_mobile($data[$k]);//验证电话号码
                                        if ($mobile !== true) {
                                                return $mobile;
                                        }
                                        break;
                                case'content':
                                        $content = $this->vali_content($data[$k]);//验证短信内容
                                        if ($content !== true) {
                                                return $content;
                                        }
                                        break;
                                case'exno':
                                        $exno = $this->vali_exno($data[$k]);//扩展子号内容
                                        if ($exno !== true) {
                                                return $exno;
                                        }
                                        break;
                                case'custid':
                                        $custid = $this->vali_custid($data[$k]);//扩展子号内容
                                        if ($custid !== true) {
                                                return $custid;
                                        }
                                        break;
                                case'svrtype':
                                        $svrtype = $this->vali_svrtype($data[$k]);//扩展子号内容
                                        if ($svrtype !== true) {
                                                return $svrtype;
                                        }
                                        break;
                                case'exdata':
                                        $exdata = $this->vali_exdata($data[$k]);//自定义扩展数据内容
                                        if ($exdata !== true) {
                                                return $exdata;
                                        }
                                        break;
                        }
                }
                return true;//验证通过
            }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(),'验证公共参数失败');//日志记录捕获的异常消息
            }
        }
    /*
   * 必要字段为空处理
   * $data：请求数据
   */
    public function necessary_field($data)
    {
        $key_value = array('mobile', 'content');//用户遗漏字段参数给于补充并填充null,在下列验证方法中验证并返回错误码
        foreach ($key_value as $k => $v) {
            if (!array_key_exists($v, $data)) //检测必填字段是否存在
            {
                $data[$v] = null;
            }
        }
        return $data;
    }
}
?>
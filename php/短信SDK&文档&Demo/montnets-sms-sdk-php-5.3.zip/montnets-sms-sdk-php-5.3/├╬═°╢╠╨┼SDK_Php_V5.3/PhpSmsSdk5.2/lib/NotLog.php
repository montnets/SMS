<?php

/**
 * Created by PhpStorm.
 * Date: 2017-01-15
 * Time: 12:19
 * @功能概要：记录日志类
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('GlobalValue.php');
class NotLog
{
    /*
     *存放一般日志
     * $text 写入日志内容
     */
    public function deposit_log($text)
    {
        try {
            $GlobalValue = new GlobalValue();
            $needLog=$GlobalValue->get_needLog();
            if($needLog===1||!empty($needLog)) //已经设置是否需要日志或没有设置时都进行记录日志的操作
            {
                $path = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'SmsSdkLog';//获取日志文件目录
                $time = time();//获取当前时间
                $year = date('Y', $time);//获取当前年份
                $month = date('m', $time);//获取当前月份
                $day = date('d', $time);//获取当前日期
                if (!is_dir($path . DIRECTORY_SEPARATOR . $year))//如果没有年文件
                {
                    mkdir($path . DIRECTORY_SEPARATOR . $year);//创建年文件
                }
                if (!is_dir($path . DIRECTORY_SEPARATOR . $year . DIRECTORY_SEPARATOR . $month))//如果没有月文件
                {
                    mkdir($path . DIRECTORY_SEPARATOR . $year . DIRECTORY_SEPARATOR . $month);//创建月文件
                }
                $file_url = $path . DIRECTORY_SEPARATOR . $year . DIRECTORY_SEPARATOR . $month . DIRECTORY_SEPARATOR . $year . $month . $day . '.txt';//日期文件路径
                if (file_exists($file_url)) //判断是否存在该文件
                {
                    return $this->write_file($text, $file_url);//进行写入文件操作并返回写入结果
                }
                fopen($file_url, "w");//不存在则创建文件
                return $this->write_file($text, $file_url);//进行写入文件操作并返回写入结果
            }
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /*
    *存放错误日志
     * $error 异常错误信息
    * $text 写入日志内容
    */
    public function deposit_error_log($error,$text)
    {
        try {
            $text=$text.PHP_EOL.$error;//拼接错误问题内容及系统反馈的错误内容
            $this->deposit_log($text);
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /*
     *写入日志文件
     * $text 写入日志内容
     * $text 写入文件地址
     */
    public function write_file($text,$file_url)
    {
        $utimestamp = microtime(true);//获取毫秒级时间戳
        $timestamp = floor($utimestamp);//毫秒以上取整数
        $milliseconds = round(($utimestamp - $timestamp) * 1000);//获取毫秒
        $time=date('Y-m-d H:i:s',$timestamp).'.'.$milliseconds;//拼接时间字符串
        $text=$time.' '.$text.PHP_EOL;//在内容前拼接时间并对内容进行换行
        if (is_writable($file_url)) //文件是否可写入
        {
            if (file_put_contents($file_url, $text, FILE_APPEND))//对当前文件写入内容累加
            {
                return true;
            }
            return false;
        }
    }
}
<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-14
 * Time: 11:25
 * @功能概要：全局参数定义类
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('CHttp.php');
require_once('ValidateParamTool.php');
require_once('CheckAccountThread.php');
require_once('NotLog.php');
class GlobalValue
{
    /**
     * 错误代码
     */
    public $error_code;

    /**
     * 获取错误代码文件内容
     */
    public function get_error()
    {
        $error=include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'ErrorCode.php');//获取错误代码
        return $error;
    }

    /**
     * 获取缓存文件地址
     */
    public function filename()
    {
        $NotLog = new NotLog();
        try {
            $file_url = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'cache.txt';//获取缓存文件路径
            if (file_exists($file_url)) //判断是否存在该文件
            {
                return $file_url;//存在则返回文件路径
            }
            fopen($file_url, "w");//不存在则创建文件
            return $file_url;//返回创建文件路径
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
            $NotLog->deposit_error_log($e->getMessage(), "获取缓存文件失败。");//日志记录捕获的异常消息
        }
    }
    /**
     * 设置全局参数
     * $url：请求地址
     * $log：是否需要日志
     */
    public function setGlobalParams($url=null,$log=null)//设置全局参数
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        try {
            $set_path = $this->setRequestPath($url);//设置请求地址
            $set_url = $this->setNeedLog($log);//设置是否需要日志
            if ($set_path['result'] !== 0)//设置请求地址失败
            {
                return $set_path;//返回设置请求地址错误码
            } else if ($set_url['result'] !== 0)//设置是否需要日志失败
            {
                return $set_url;//返回是否需要日志错误码
            } else//设置地址及是否需要日志都成功时
            {
                $result['result'] = 0;
                return $result;
            }
        }catch (Exception $e) {
            $result['result'] =$this->error_code['ERROR_310012'];
            $NotLog->deposit_error_log($e->getMessage(), '设置全局参数失败,错误码:'.$this->error_code['ERROR_310012'].'。');//日志记录捕获的异常消息
            return $result;//返回验证结果
        }
    }
    /**
     * 设置请求地址
     * $url：请求地址
     */
    public function setRequestPath($url)//设置请求地址
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        $Vakidate = new ValidateParamTool();
        try {
            $vali = $Vakidate->vali_url($url);//验证设置请求地址
            if ($vali === true) {
                if ($this->set_url($url))//请求地址设置成功
                {
                    $result['result'] =0;
                    return $result;
                }
                $result['result'] = $this->error_code['ERROR_310012'];
                $NotLog->deposit_log('设置全局参数的请求路径失败,错误码:'.$this->error_code['ERROR_310012'].'。');//日志记录捕获的异常消息
                return $result;
            }
            $NotLog->deposit_log('请求路径不合法,错误码:'.$vali.',请求路径为空。');//日志记录捕获的异常消息
            return $vali;
        }  catch (Exception $e) //检测到的异常处理
        {
            $result['result'] =$this->error_code['ERROR_310012'];
            $NotLog->deposit_error_log($e->getMessage(), '设置全局参数的请求路径失败,错误码:'.$this->error_code['ERROR_310012'].'。');//日志记录捕获的异常消息
            return $result;//返回验证结果
        }
    }
    /**
     * 设置是否需要日志
     * $log：是否需要日志
     */
    public function setNeedLog($log)//设置是否需要日志
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        $Vakidate = new ValidateParamTool();
        try {
            if(empty($log)&&$log!==0)//没有设置是否需要日志时
            {
                $log=1;//默认设置为1(默认需要日志)
            }
            $vali = $Vakidate->vali_log($log);//验证设置请求地址
            if ($vali === true) {
                if ($this->set_needLog($log))//请求地址设置成功
                {
                    $result['result'] =0;
                    return $result;
                }
                $result['result'] = $this->error_code['ERROR_310012'];
                $NotLog->deposit_log('设置全局参数的是否需要日志失败,错误码:'.$this->error_code['ERROR_310012'].'。');//日志记录捕获的异常消息
                return $result;
            }
            $NotLog->deposit_log('是否需要日志设置不合法,错误码:'.$vali['result'].'。');//日志记录捕获的异常消息
            return $vali;
        }  catch (Exception $e) //检测到的异常处理
        {
            $result['result'] =$this->error_code['ERROR_310012'];
            $NotLog->deposit_error_log($e->getMessage(), '设置全局参数的是否需要日志失败,错误码:'.$this->error_code['ERROR_310012'].'。');//日志记录捕获的异常消息
            return $result;//返回验证结果
        }
    }
    /**
     * 设置账号信息
     * $userid：用户账号
     * $pwd：用户密码
     * $priority：发送优先级
     * $ipAddress1：主IP
     * $ipAddress2，$ipAddress3，$ipAddress4：备用IP
     */
    public function setAccountInfo($userid=null,$pwd=null,$priority=null,$ipAddress1=null,$ipAddress2=null,$ipAddress3=null,$ipAddress4=null)//设置账号信息
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        $Vakidate = new ValidateParamTool();
        $user=$this->get_user();//获取用户信息
        $abnormal_ip=$this->get_abnormal_ip();//获取异常IP集合
        try {
            $userid = strtoupper($userid);//用户名设置为大写
            if (!empty($user))//已经设置过账号信息
            {
                $is_cover = 0;//是否有重复账号标识
                $i = 0;
                foreach ($user as $k => $v)//检测账号是否存在，存在则进行覆盖
                {
                    if ($user[$k]['userid'] == $userid) {
                        $user[$k]['userid'] = $userid;
                        $user[$k]['pwd'] = $pwd;
                        $user[$k]['priority'] = $priority;
                        $user[$k]['ip']['ipAddress1'] = $ipAddress1;
                        for($i=2;$i<=4;$i++) {
                            if(!empty(${ipAddress.$i})) {
                                $user[$k]['ip']['ipAddress' . $i] = ${ipAddress . $i};
                            }
                            else if(isset($user[$k]['ip']['ipAddress'. $i])&&empty(${ipAddress.$i}))
                            {
                                unset($user[$k]['ip']['ipAddress'. $i]);
                            }
                        }
                        $vali = $Vakidate->vali_setAccountInfo($user[$k]);//验证设置账号信息
                        if ($vali === true)//设置账号验证通过
                        {
                            $analysis_list=$user[$k]['ip'];//将域名(IP)放入解析队列
                            $user[$k]['analysis_ip']=$this->analysis_domain_name($analysis_list);//将域名解析为IP，若原本为IP则返回IP，若无端口号则自动加上'80'端口号
                            if ($this->set_user($user))//用户信息保存成功
                            {
                                if (!empty($abnormal_ip)) //如果存在异常IP集合
                                {
                                    if (array_key_exists($user[$k]['userid'], $abnormal_ip))//异常信息中包含此账号的主IP
                                    {
                                        $abnormal_ip[$user[$k]['userid']] = $user[$k]['analysis_ip']['ipAddress1'];//更新异常账号中的对应主IP信息
                                        $this->set_abnormal_ip($abnormal_ip);
                                    }
                                }
                                $result['result'] = 0;
                            } else {
                                $result['result'] = $this->error_code['ERROR_310007'];
                                $NotLog->deposit_log('设置账号信息失败,错误码:'.$this->error_code['ERROR_310007'].'。');//日志记录捕获的异常消息
                            }
                            return $result;
                        } else {
                            return $vali;
                        }
                        $is_cover = 1;//判断为已有重复账号标识
                    }
                    $i++;//账号个数累加
                }
                if ($is_cover == 0) //如果没有重复帐号进行累加
                {
                    $user[$i]['userid'] = $userid;
                    $user[$i]['pwd'] = $pwd;
                    $user[$i]['priority'] = $priority;
                    $user[$i]['ip']['ipAddress1'] = $ipAddress1;
                    for($j=2;$j<=4;$j++) {
                        if(!empty(${ipAddress.$j})) {
                            $user[$i]['ip']['ipAddress' . $j] = ${ipAddress . $j};
                        }
                    }
                    $user[$i]['state'] = 0;
                    $vali = $Vakidate->vali_setAccountInfo($user[$i]);//验证设置账号信息
                    if ($vali === true)//设置账号验证通过
                    {
                        $analysis_list=$user[$i]['ip'];//将域名(IP)放入解析队列
                        $user[$i]['analysis_ip']=$this->analysis_domain_name($analysis_list);//将域名解析为IP，若原本为IP则返回IP，若无端口号则自动加上'80'端口号
                        // 保存数据
                        if ($this->set_user($user))//用户信息保存成功
                        {
                            $result['result'] =0;
                        } else//用户信息保存失败
                        {
                            $result['result'] = $this->error_code['ERROR_310007'];
                            $NotLog->deposit_log('设置账号信息失败,错误码:'.$this->error_code['ERROR_310007'].'。');//日志记录捕获的异常消息
                        }
                        return $result;
                    }
                    return $vali;
                }
            } else//设置第一个账号信息
            {
                $thread = $this->get_thread();//获取线程启动状态
                if(empty($thread))//未启动线程
                {
                    $CheckAccountThread = new CheckAccountThread();
                    $CheckAccountThread->start();//开始执行线程
                    $CheckAccountThread->detach();//分离线程，不与主线程造成阻塞
                }
                $user[0]['userid'] = $userid;
                $user[0]['pwd'] = $pwd;
                $user[0]['priority'] = $priority;
                $user[0]['ip']['ipAddress1'] = $ipAddress1;
                for($i=2;$i<=4;$i++) {
                    if(!empty(${ipAddress.$i})) {
                        $user[0]['ip']['ipAddress' . $i] = ${ipAddress . $i};
                    }
                }
                $user[0]['state'] = 0;
                $vali = $Vakidate->vali_setAccountInfo($user[0]);//验证设置账号信息
                if ($vali === true)//设置账号验证通过
                {
                    $analysis_list=$user[0]['ip'];//将域名(IP)放入解析队列
                    $user[0]['analysis_ip']=$this->analysis_domain_name($analysis_list);//将域名解析为IP，若原本为IP则返回IP，若无端口号则自动加上'80'端口号
                    if ($this->set_user($user))//用户信息保存成功
                    {
                        $result['result'] =0;
                    }
                    else//用户信息保存失败
                    {
                        $result['result'] = $this->error_code['ERROR_310007'];
                        $NotLog->deposit_log('设置账号信息失败,错误码:'.$this->error_code['ERROR_310007'].'。');//日志记录捕获的异常消息
                    }
                    return $result;
                }
                return $vali;
            }
        }
        catch (Exception $e) //检测到的异常处理
        {
            $result['result'] =$this->error_code['ERROR_310007'];
            $NotLog->deposit_error_log($e->getMessage(),'设置账号信息失败,错误码:'.$this->error_code['ERROR_310007'].'。');//日志记录捕获的异常消息
            return $result;//返回验证结果
        }
    }
    /**
     * 移除已设置过的帐号
     * $userid：用户账号
     */
    public function removeAccount($userid=null)
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        $Vakidate = new ValidateParamTool();
        try {
            $user = $this->get_user();//获取缓存用户信息
            $abnormal_ip =  $this->get_abnormal_ip();//获取异常IP信息
            if (!empty($user)) {
                $userid = strtoupper($userid);//用户名设置为大写
                $vali = $Vakidate->vali_usreid($userid);//验证设置账号信息
                if ($vali === true)//账号验证通过
                {
                    $userid = strtoupper($userid);//用户名设置为大写
                    foreach ($user as $k => $v) {
                        if ($v['userid'] == $userid) //账户信息中存在该账号
                        {
                            unset($user[$k]);
                            $user = array_values($user);//移除数组键值
                            if ($this->set_user($user))//用户信息保存成功
                            {
                                if (!empty($abnormal_ip)) //如果存在异常IP集合
                                {
                                    if (array_key_exists($userid, $abnormal_ip)) {
                                        unset($abnormal_ip[$userid]);//抛出已删除的账号异常IP
                                        $this->set_abnormal_ip($abnormal_ip);
                                    }
                                }
                                $result['result'] =0;
                            }else//用户信息移除失败
                            {
                                $result['result'] = $this->error_code['ERROR_310013'];
                                $NotLog->deposit_log('根据账号['.$userid.']移除账号信息失败,错误码:'.$this->error_code['ERROR_310013'].'。');//日志记录捕获的异常消息
                            }
                            return $result;
                        }
                    }
                    $result['result'] = $this->error_code['ERROR_310014'];
                    $NotLog->deposit_log('账号['.$userid.']在账号列表不存在,无需移除,错误码:'.$this->error_code['ERROR_310014'].'。');//日志记录捕获的异常消息
                    return $result;
                }
                return $vali;
            }
            $result['result'] = $this->error_code['ERROR_310009'];
            $NotLog->deposit_log('无可用帐号,错误码:'.$this->error_code['ERROR_310009'].'。');//日志记录捕获的异常消息
            return $result;
        } catch (Exception $e) //检测到的异常处理
        {
            $result['result'] =$this->error_code['ERROR_310013'];
            $NotLog->deposit_error_log($e->getMessage(),'根据账号['.$userid.']移除账号信息失败,错误码:'.$this->error_code['ERROR_310013'].'。');//日志记录捕获的异常消息
            return $result;//返回验证结果
        }
    }
    /**
     * 如传入userid则返回对应userid的值，如没有则进行排序返回所有账号
     * $userid：用户账号
     */
    public function get_userid($userid=null)
    {
        $NotLog = new NotLog();
        try {
            $user = $this->get_user();//获取缓存用户信息
            if(!empty($user))//账号信息不为空
            {
                if(!empty($userid))//指定发送
                {
                    foreach ($user as $k => $v) {
                        if ($user[$k]['userid'] == $userid) {
                            return $user[$k];
                        }
                    }
                }
                else//无指定帐号将优先级账号排序
                {
                    $user_priority=array();//初始帐号将优先级排序的数组对象
                    for($i=1;$i<=9;$i++)//根据账号优先级分类
                    {
                        foreach ($user as $k => $v) {
                            switch($user[$k]['priority'])
                            {
                                case $i:$user_priority[$i][]=$user[$k];//所有账号按照优先级排序
                            }
                        }
                    }
                    return $user_priority;
                }
            }
            return null;//无账号信息
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), "获取缓存文件中的账号信息并进行优先级排序失败。");//日志记录捕获的异常消息
            return null;//无账号信息
        }
    }
    /*
    *获取文件内容
    */
    public function get_file()
    {
        $NotLog = new NotLog();
        try {
            $file_name = $this->filename();//获取文件
            if (is_readable($file_name))//判断缓存文件是否可读
            {
                if ($cache = file_get_contents($file_name))//读取对应文件内容
                {
                    return json_decode(base64_decode($cache), true);//解析数据
                }
                return null;//读取文件失败返回null
            }
            return null;//读取文件失败返回null
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), "获取缓存文件中的内容信息失败。");//日志记录捕获的异常消息
            return null;//读取文件失败返回null
        }
    }
    /*
    *获取用户账号信息
    */
    public function get_user()
    {
        $file=$this->get_file();//获取文件内容
        $user=!empty($file['user'])?$file['user'] : null;//读取用户账号信息，若无信息则返回null
        return $user;
    }
    /*
    *获取用户设置的请求地址
    */
    public function get_url()
    {
        $file=$this->get_file();//获取文件内容
        $url=!empty($file['url'])? $file['url'] : null;//读取请求地址信息，若无信息则返回null
        return $url;
    }
    /*
    *获取用户设置的是否需要日志
    */
    public function get_needLog()
    {
        $file=$this->get_file();//获取文件内容
        $url=!empty($file['needLog'])? $file['needLog'] : null;//读取请求地址信息，若无信息则返回null
        return $url;
    }
    /*
   *获取线程状态
   */
    public function get_thread()
    {
        $file=$this->get_file();//获取文件内容
        $user=!empty($file['thread_state'])?$file['thread_state'] : null;//读取用户账号信息，若无信息则返回null
        return $user;
    }
    /*
    *获取异常IP集合
    */
    public function get_abnormal_ip()
    {
        $file=$this->get_file();//获取文件内容
        $abnormal_ip=!empty($file['abnormal_ip'])?$file['abnormal_ip'] : null;//读取异常IP集合信息，若无信息则返回null
        return $abnormal_ip;
    }
    /*
    *设置用户账号信息保存
     * $user：用户信息
    */
    public function set_user($user)
    {
        $NotLog = new NotLog();
        try {
            $all = $this->get_file();//获取文件内容
            $all['user'] = $user;
            $all = base64_encode(json_encode($all));//对用户信息进行加密
            if (is_writable($this->filename())) //文件是否可写入
            {
                if (file_put_contents($this->filename(), $all, LOCK_EX))//对当前文件进行写入操作时将文件锁死
                {
                    return true;
                }
                return false;
            }
            return false;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '设置用户账号['.$user['userid'].']保存失败。');//日志记录捕获的异常消息
            return false;
        }
    }
    /*
    *设置用户账号信息保存
     * $state：线程状态
    */
    public function set_thread($state)
    {
        $NotLog = new NotLog();
        try {
            $all = $this->get_file();//获取文件内容
            $all['thread_state'] = $state;
            $all = base64_encode(json_encode($all));//对用户信息进行加密
            if (is_writable($this->filename())) //文件是否可写入
            {
                if (file_put_contents($this->filename(), $all, LOCK_EX))//对当前文件进行写入操作时将文件锁死
                {
                    return true;
                }
                return false;
            }
            return false;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '主IP检测线程已设为开启状态。');//日志记录捕获的异常消息
            return false;
        }
    }
    /*
    *设置请求地址信息保存
     * $url：请求地址
    */
    public function set_url($url)
    {
        $NotLog = new NotLog();
        try {
            $all=$this->get_file();//获取文件内容
            $all['url']=$url;
            $all=base64_encode(json_encode($all));//对请求地址信息进行加密
            if (is_writable($this->filename()))//文件是否可写入
            {
                if(file_put_contents($this->filename(),$all,LOCK_EX))//对当前文件进行写入操作时将文件锁死
                {
                    return true;
                }
                 return false;
            }
            return false;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '设置请求地址['.$url.']保存失败。');//日志记录捕获的异常消息
            return false;
        }
    }
    /*
   *设置是否需要日志
    * $log：是否需要日志判断字段
   */
    public function set_needLog($log)
    {
        $NotLog = new NotLog();
        try {
            $all=$this->get_file();//获取文件内容
            $all['needLog']=$log;
            $all=base64_encode(json_encode($all));//对请求地址信息进行加密
            if (is_writable($this->filename()))//文件是否可写入
            {
                if(file_put_contents($this->filename(),$all,LOCK_EX))//对当前文件进行写入操作时将文件锁死
                {
                    return true;
                }
                return false;
            }
            return false;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '设置是否需要日志保存失败。');//日志记录捕获的异常消息
            return false;
        }
    }
    /*
    *将异常IP放入异常IP结果集中
     * $abnormal_ip：异常IP
    */
    public function set_abnormal_ip($abnormal_ip)
    {
        $NotLog = new NotLog();
        try {
            $all=$this->get_file();//获取文件内容
            $all['abnormal_ip']=$abnormal_ip;
            $all=base64_encode(json_encode($all));//对异常IP集合信息进行加密
            if (is_writable($this->filename())) //文件是否可写入
            {
                if(file_put_contents($this->filename(),$all,LOCK_EX))//对当前文件进行写入操作时将文件锁死
                {
                    return true;
                }
                return false;
            }
           return false;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '异常主IP集合保存失败。');//日志记录捕获的异常消息
            return false;
        }
    }
    /*
    *解析域名
    * $ip 用户账号信息主备IP(域名)解析，若无端口号则自动加上'80'端口号
    */
    public function analysis_domain_name($ip)
    {
        $NotLog = new NotLog();
        try {
            $analysis=array();//初始化数组
           foreach($ip as $k=>$v)
           {
               if ($port_position=strpos($v, ':'))//判断是否有端口号
               {
                   $ip_str = substr($v,0,$port_position);//截取IP或域名地址
                   $ip_len = strlen($v);//获取IP长度
                   $port_str = substr($v, $port_position + 1, $ip_len);//截取端口号
                   $analysis[$k]=gethostbyname($ip_str).':'.$port_str;//将域名解析为IP，若为IP，则仍然为IP,解析完成与端口号进行拼接
               }
               else
               {
                   $analysis[$k]=gethostbyname($v);//将域名解析为IP，若为IP，则仍然为IP
                   $analysis[$k]=$analysis[$k].':80';//无端口号时自动加上80端口
               }
               if (preg_match('/[a-zA-Z]/',$v))//判断用户设置的是IP还是域名
               {
                   $isip=0;//用户设置的为域名
               }
               else
               {
                   $isip=1;//用户设置的为IP
               }
               $analysis_ip[$k] = array('ip' => $analysis[$k], 'isip' =>$isip);//与解析前的域名(IP)进行键值对应
           }
            return $analysis_ip;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '域名(IP)['.$ip.']解析失败。');//日志记录捕获的异常消息
        }
    }
 }

?>
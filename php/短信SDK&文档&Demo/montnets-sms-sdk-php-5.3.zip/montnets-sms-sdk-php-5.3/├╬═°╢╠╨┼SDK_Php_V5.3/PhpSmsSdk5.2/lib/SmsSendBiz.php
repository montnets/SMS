<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-13
 * Time: 10:15
 * @功能概要：发送业务层
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('CHttp.php');
require_once('GlobalValue.php');
require_once('EncryptUtil.php');
require_once('NotLog.php');
class SmsSendBiz
{
    /**
     * 错误代码
     */
    public $error_code;

    /**
     * 获取错误代码文件内容
     */
    public function get_error()
    {
        $error=include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'ErrorCode.php');//获取错误代码
        return $error;
    }

    /**
     * 公有发送短信方法
     * $data：请求提交数据
     * $ip：请求IP地址
     * $mean：请求类型
     * $first_mobile：第一个手机号(个性化发送，相同内容群发)
     */
    public function send($data, $ip, $mean, $first_mobile = null)
    {
        $NotLog = new NotLog();
        $GlobalValue = new GlobalValue();
            try{
                $url = $GlobalValue->get_url('url');//获取所用缓存请求地址
                $url = 'http://' . $ip . $url . $mean;//拼接请求URL
                if ($mean=='multi_send')//个性化群发时对数据进行合并处理
                {
                    $multimt = $data['multimt'];//单独将multimt包结构中的数据提出来
                    unset($data['multimt']);//移除multimt包结构在请求时单独拼接
                    $data=http_build_query($data).'&multimt='.$multimt;//拼接数据，multimt包结构体中为JSON格式
                }
                else //单发或者相同内容群发时
                {
                    $content = $data['content'];//单独将content包结构中的数据提出来
                    unset($data['content']);//移除content包结构在请求时单独拼接
                    $mobile=$data['mobile'];//单独将电话号码提取出来
                    unset($data['mobile']);//移除组内的电话号码在请求时单独拼接
                    $data=http_build_query($data).'&mobile='.$mobile.'&content='.$content;//拼接数据，电话号码中的豆号不能转为URLENCODE格式
                }
                $result = CHttp::PostCURL($url, $data);//发送请求地址
                if ($result['result'] === 0)//发送成功
                {
                    if (!empty($first_mobile)) {
                        $mobile = $first_mobile;//如果发送类型为群发，存在首个手机号码，将号码进行赋值
                    }
                    $result['returnValue'] = $mobile . ',' . $result['custid'] . ',' . $result['msgid'];//把电话号码,自定义流水号,平台流水号进行字符串的拼接
                } else {
                    $result['returnValue'] = null;//返回值为空
                }
                unset($result['custid']);//移除自定义流水号
                unset($result['msgid']);//移除平台流水号
                return $result;
            }catch (Exception $e) {
                $NotLog->deposit_error_log($e->getMessage(), '公有发送短信方法失败。');//日志记录捕获的异常消息
            }
    }
    /**
     * 公有长连接发送短信方法
     * $data：请求提交数据
     * $ip：请求IP地址
     * $mean：请求类型
     * $first_mobile：第一个手机号(个性化发送，相同内容群发)
     */
    public function send_keep($data, $ip, $mean, $first_mobile = null)
    {
        $NotLog = new NotLog();
        $GlobalValue = new GlobalValue();
        try{
            $url = $GlobalValue->get_url('url');//获取所用缓存请求地址
            $url = $url.$mean;//拼接请求URL
            $port_position = strpos($ip, ':');//获取IP的字符串结束位置
            $ip_str=substr($ip,0,$port_position);//截取IP地址
            $ip_len = strlen($ip);//获取IP及端口总长度
            $port_str = substr($ip, $port_position + 1, $ip_len);//截取端口号
            $ip=$ip_str;//赋值IP信息
            $port=(int)$port_str;//赋值端口信息并强制转化为INT类型
            if ($mean=='multi_send')//个性化群发时对数据进行合并处理
            {
                $multimt = $data['multimt'];//单独将multimt包结构中的数据提出来
                unset($data['multimt']);//移除multimt包结构在请求时单独拼接
                $data=http_build_query($data).'&multimt='.$multimt;//拼接数据，multimt包结构体中为JSON格式
            }
            else //单发或者相同内容群发时
            {
                $content = $data['content'];//单独将content包结构中的数据提出来
                unset($data['content']);//移除content包结构在请求时单独拼接
                $mobile=$data['mobile'];//单独将电话号码提取出来
                unset($data['mobile']);//移除组内的电话号码在请求时单独拼接
                $data=http_build_query($data).'&mobile='.$mobile.'&content='.$content;//拼接数据，电话号码中的豆号不能转为URLENCODE格式
            }
            $result = CHttp::PostScoket($ip,$port,$url, $data);//发送请求地址
            if ($result['result'] === 0)//发送成功
            {
                if (!empty($first_mobile)) {
                    $mobile = $first_mobile;//如果发送类型为群发，存在首个手机号码，将号码进行赋值
                }
                $result['returnValue'] = $mobile . ',' . $result['custid'] . ',' . $result['msgid'];//把电话号码,自定义流水号,平台流水号进行字符串的拼接
            } else {
                $result['returnValue'] = null;//返回值为空
            }
            unset($result['custid']);//移除自定义流水号
            unset($result['msgid']);//移除平台流水号
            return $result;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '公有长连接发送短信方法失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 公有获取方法
     * $data：请求提交数据
     * $ip：请求IP地址
     * $mean：请求类型
     */
    public function get_mess($data, $ip, $mean)//公有获取方法
    {
        $NotLog = new NotLog();
        $GlobalValue = new GlobalValue();
        try{
            $url = $GlobalValue->get_url('url');//获取所用缓存用户
            $url = 'http://' . $ip . $url . $mean;//拼接请求URL
            $data=http_build_query($data);//将请求数据转化为urlencode格式
            $result = CHttp::PostCURL($url, $data);//发送请求地址
            return $result;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '公有获取方法失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 公有长连接获取方法
     * $data：请求提交数据
     * $ip：请求IP地址
     * $mean：请求类型
     */
    public function get_mess_keep($data, $ip, $mean)//公有获取方法
    {
        $NotLog = new NotLog();
        $GlobalValue = new GlobalValue();
        try{
            $url = $GlobalValue->get_url('url');//获取所用缓存用户
            $url = $url.$mean;//拼接请求URL
            $port_position = strpos($ip, ':');//获取IP的字符串结束位置
            $ip_str=substr($ip,0,$port_position);//截取IP地址
            $ip_len = strlen($ip);//获取IP及端口总长度
            $port_str = substr($ip, $port_position + 1, $ip_len);//截取端口号
            $ip=$ip_str;//赋值IP信息
            $port=(int)$port_str;//赋值端口信息并强制转化为INT类型
            $data=http_build_query($data);//将请求数据转化为urlencode格式
            $result = CHttp::PostScoket($ip,$port,$url, $data);//发送请求地址
            return $result;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '公有长连接获取方法失败。');//日志记录捕获的异常消息
        }
    }

    /**
     * 主备IP请求方法
     * $data：请求提交数据
     * $user：账号信息
     * $mean：请求类型
     * $first_mobile：第一个手机号(个性化发送，相同内容群发)
     */
    public function send_ip_dealt($data, $user, $mean, $first_mobile = null)//时对IP的异常处理
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        $Encrypt = new EncryptUtil();
        $GlobalValue = new GlobalValue();
        try {
            $data['userid'] = $user['userid'];//数组中放入账号
            $pwd = $Encrypt->encrypt_pwd($user['userid'], $user['pwd']);//生成加密密码明文
            $data['pwd'] = $pwd['pwd'];//数组中放入密码
            $data['timestamp'] = $pwd['time'];//获取时间戳
            if ($data['pwd'] = md5($data['pwd']))//密码加密成功
            {
                $send_ip=$this->dispose_ip($user);//获取已处理的IP及IP是否存在域名的状态
                $ip=$send_ip['ip'];//已处理IP信息赋值
                $isip=$send_ip['isip'];//是否存在域名的状态赋值
                $ip_count=count($ip);//获取IP个数(主、备IP)
                foreach ($ip as $k => $v) {
                    $result = $this->request_type($data, $v, $mean, $first_mobile);//根据请求类型发送请求
                    if ($result['result'] === 0)//请求成功
                    {
                        return $result;
                    } else {
                        if($result['result']===-310099) //返回网络错误时
                        {
                            $NotLog->deposit_log('通过账号[' . $user['userid'] . ']下的IP[' . $v . ']请求失败,此IP不可用');
                        }
                        if($isip[$k]===0)//若果存在对应域名
                        {
                            if($get_ip=$GlobalValue->analysis_domain_name(array($k=>$user['ip'][$k])))//通过域名再次获取IP成功
                            {
                                $NotLog->deposit_log('通过账号['.$user['userid'].']下的域名['.$user['ip'][$k].']获取到IP['.$get_ip[$k]['ip'].']');
                                if ($get_ip[$k]['ip'] != $v)//当前获取IP与IP集合中的IP不同
                                {
                                    $NotLog->deposit_log('账号['.$user['userid'].']下的IP['.$v.']与通过域名['.$user['ip'][$k].']获取到IP['.$get_ip[$k]['ip'].']不一致');
                                    $user['analysis_ip'][$k]['ip'] = $get_ip[$k]['ip'];//赋值新的IP到对应账号已解析的IP集合中
                                    $start_time1 = microtime(true);//检测起始时间
                                    $result = $this->request_type($data, $get_ip[$k]['ip'], $mean, $first_mobile);//根据请求类型发送请求
                                    $end_time1 = microtime(true);//检测结束时间
                                    if ($result['result'] === 0)//请求成功
                                    {
                                        $interval_time1 = ($end_time1 - $start_time1) * 1000;//间隔时间，转化为毫秒
                                        $NotLog->deposit_log('账号['.$user['userid'].']下的IP['.$v.']与通过域名['.$user['ip'][$k].']获取到IP['.$get_ip[$k]['ip'].']不一致,使用获取到IP进行请求时请求成功,请求耗时:'.$interval_time1.'毫秒,此IP可用,账号的IP从['.$v.']换成通过域名获取的IP['.$get_ip[$k]['ip'].']');
                                        $GlobalValue->set_user($user);//更新已解析的IP集合
                                        return $result;
                                    } else//请求失败
                                    {
                                        if ($k == 'ipAddress1' && $result['result'] === -310099)//如果当前为主域名且返回网络错误时
                                        {
                                            if($ip_count>1) {
                                                $spare_ip='';//初始化备IP字符串
                                                for($n=2;$n<=$ip_count;$n++)
                                                {
                                                    if($n==$ip_count) {
                                                        $spare_ip .= '[ipAddress'. $n .']=>['. $ip['ipAddress' . $n] .']';//拼接备IP信息字符串
                                                    }
                                                    else
                                                    {
                                                        $spare_ip .= '[ipAddress'. $n .']=>['. $ip['ipAddress' . $n] .'],';//拼接备IP信息字符串
                                                    }
                                                }
                                                $NotLog->deposit_log('该账号有备IP,备IP信息为 ' .$spare_ip.' 将切换到备IP。待主IP恢复正常后,再切换回主IP');
                                            }
                                            $this->set_abnormal_ip($user['userid'], $v, $isip[$k]);//将当前主IP放入异常IP集合中
                                        } else if ($result['result'] !== -310099)//除了主IP以外的IP外返回非网络错误时
                                        {
                                            return $result;
                                        }
                                        else if($result['result']===-310099) //返回网络错误时
                                        {
                                            $NotLog->deposit_log('账号['.$user['userid'].']下的IP['.$v.']与通过域名['.$user['ip'][$k].']获取到IP['.$get_ip[$k]['ip'].']不一致,使用获取到的IP进行请求时请求失败，获取到的IP不可用');
                                        }
                                    }
                                } else//当前获取IP与IP集合中的IP相同
                                {
                                    $NotLog->deposit_log('账号['.$user['userid'].']下的IP['.$v.']与通过域名['.$user['ip'][$k].']获取到IP['.$get_ip[$k]['ip'].']一致');
                                    if ($k == 'ipAddress1' && $result['result'] === -310099)//如果当前为主域名时且返回网络错误时
                                    {
                                        if($ip_count>1) {
                                            $spare_ip='';//初始化备IP字符串
                                            for($n=2;$n<=$ip_count;$n++)
                                            {
                                                if($n==$ip_count) {
                                                    $spare_ip .= '[ipAddress'. $n .']=>['. $ip['ipAddress' . $n] .']';//拼接备IP信息字符串
                                                }
                                                else
                                                {
                                                    $spare_ip .= '[ipAddress'. $n .']=>['. $ip['ipAddress' . $n] .'],';//拼接备IP信息字符串
                                                }
                                            }
                                            $NotLog->deposit_log('该账号有备IP,备IP信息为 ' .$spare_ip.' 将切换到备IP。待主IP恢复正常后,再切换回主IP');
                                        }
                                        $this->set_abnormal_ip($user['userid'], $v, $isip[$k]);//将当前主IP放入异常IP集合中
                                    } else if ($result['result'] !== -310099)//除了主IP以外的IP外返回非网络错误时
                                    {
                                        return $result;
                                    }
                                }
                            }
                            else
                            {
                                $NotLog->deposit_log('通过账号['.$user['userid'].']下的域名['.$user['ip'][$k].']获取IP失败');
                            }
                        }
                        else//不存在对应域名
                        {
                            $NotLog->deposit_log('通过账号['.$user['userid'].']下的IP['.$v.']请求失败,此IP不可用并且没有对应的域名,不通过域名获取IP');
                            if ($k == 'ipAddress1'&&$result['result']===-310099)//如果当前为主IP时且返回网络错误时
                            {
                                if($ip_count>1) {
                                    $spare_ip='';//初始化备IP字符串
                                    for($n=2;$n<=$ip_count;$n++)
                                    {
                                        if($n==$ip_count) {
                                            $spare_ip .= '[ipAddress'. $n .']=>['. $ip['ipAddress' . $n] .']';//拼接备IP信息字符串
                                        }
                                        else
                                        {
                                            $spare_ip .= '[ipAddress'. $n .']=>['. $ip['ipAddress' . $n] .'],';//拼接备IP信息字符串
                                        }
                                    }
                                    $NotLog->deposit_log('该账号有备IP,备IP信息为 ' .$spare_ip.' 将切换到备IP。待主IP恢复正常后,再切换回主IP');
                                }
                                $this->set_abnormal_ip($user['userid'],$v,$isip[$k]);//将当前主IP放入异常IP集合中
                            }
                            else if($result['result']!==-310099)//除了主IP以外的IP返回非网络错误时
                            {
                                return $result;
                            }
                        }
                    }
                }
                $NotLog->deposit_log('账号不可用,错误码:'.$this->error_code['ERROR_310008'].',当前账号下的主IP(域名)及所有备IP(域名)都请求失败。');//日志记录捕获的异常消息
                $result['result'] = $this->error_code['ERROR_310008'];//该账号下的主IP(域名)及所有备IP(域名)请求失败
                return $result;
            } else//密码加密失败
            {
                $NotLog->deposit_log('对密码进行加密时加密失败,错误码:'.$this->error_code['ERROR_300010']);//日志记录捕获的异常消息
                $result['reslut'] = $this->error_code['ERROR_300010'];
                return $result;
            }
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '主备IP请求方法失败。');//日志记录捕获的异常消息
        }
    }

    /**
     * 获取并处理发送IP及IP是否存在域名的状态
     * $user：账号信息
     */
    public function dispose_ip($user)//获取并处理发送IP及IP是否存在域名的状态
    {
        $ip=array();//初始化数组
        if ($user['state'] === 0)//主IP正常中
        {
            foreach($user['analysis_ip'] as $k=>$v)
            {
                $ip['ip'][$k]=$user['analysis_ip'][$k]['ip'];
                $ip['isip'][$k]=$user['analysis_ip'][$k]['isip'];
            }
        } else//主IP异常中，不使用主IP
        {
            foreach($user['analysis_ip'] as $k=>$v)
            {
                if($k!='ipAddress1') {
                    $ip['ip'][$k] = $user['analysis_ip'][$k]['ip'];
                    $ip['isip'][$k] = $user['analysis_ip'][$k]['isip'];
                }
            }
        }
        return $ip;
    }

    /**
     * 异常IP处理方法
     * $userid：用户账号
     * $ip：请求IP地址
     */
    public function set_abnormal_ip($userid,$ip,$isip)//将异常IP放入异常集合中
    {
        $NotLog = new NotLog();
        $GlobalValue = new GlobalValue();
        try {
            $abnormal_ip = $GlobalValue->get_abnormal_ip();//获取所用缓存异常IP
            $user = $GlobalValue->get_user();//获取所用缓存用户
            foreach ($user as $k => $v) {
                if ($user[$k]['userid'] == $userid) {
                    $user[$k]['state'] = 1;//将异常IP的用户账户禁用
                }
            }
            $abnormal_ip[$userid] = array('ip'=>$ip,'isip'=>$isip);//记录异常主IP及对应域名
            $GlobalValue->set_abnormal_ip($abnormal_ip);//存入异常主IP集合中
            $GlobalValue->set_user($user);//更新用户账号的状态
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '异常IP处理方法失败。');//日志记录捕获的异常消息
        }
    }

    /**
     * 是否指定帐号处理
     * *$data：请求提交数据
     * $mean：请求类型
     * $first_mobile：第一个手机号(个性化发送，相同内容群发)
     */
    public function send_user($data,$mean,$first_mobile=null)
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        $GlobalValue=new GlobalValue();
        try {
            if (!empty($data['userid']))//已指定账号且账号不为空
            {
                $user = $GlobalValue->get_userid(strtoupper($data['userid']));//获取设置好的账号信息
                if (!empty($user)) {
                    $result = $this->send_ip_dealt($data, $user,$mean, $first_mobile);//指定账号发送
                    return $result;
                }
                $NotLog->deposit_log('指定账号发送时,账号不存在,错误码:'.$this->error_code['ERROR_310008'].',账号:'.$data['userid']);//日志记录捕获的异常消息
                $result['result'] = $this->error_code['ERROR_310008'];
                return $result;
            } else//未指定账号时根据优先级及设置次序排序账号并使用当前已有的账号进行发送
            {
                $user = $GlobalValue->get_userid($data['userid'] = null);//获取所有可用账号
                if (!empty($user)) //设置账号存在
                {
                    foreach ($user as $k => $v) {
                        foreach ($user[$k] as $k1 => $v1) {
                            $result = $this->send_ip_dealt($data, $v1, $mean, $first_mobile);//发送时对账号IP进行处理
                            if ($result['result'] === 0)//如果发送成功
                            {
                                return $result;
                            }
                        }
                    }
                    return $result;//循环结束返回result
                }
                $NotLog->deposit_log('未指定账号发送时,无可用的账号,错误码:'.$this->error_code['ERROR_310009']);//日志记录捕获的异常消息
                $result['result'] = $this->error_code['ERROR_310009'];
                return $result;
            }
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '是否指定帐号处理方法失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 根据请求方式进行请求操作
     * *$data：请求提交数据
     * $user：账号信息
     * $mean：请求类型
     * $first_mobile：第一个手机号(个性化发送，相同内容群发)
     */
    public function request_type($data, $ip, $mean, $first_mobile = null)
    {
        $NotLog = new NotLog();
        $this->error_code = $this->get_error();//获取错误代码参数
        try {
            if($GLOBALS['KEEPALIVE']==0||!isset($GLOBALS['KEEPALIVE']))//用户设置为短连接时
            {
                switch ($mean) {
                    case 'get_mo':
                        $result = $this->get_mess($data, $ip, $mean, $first_mobile);//请求类型为获取上行
                        return $result;
                        break;
                    case 'get_rpt':
                        $result = $this->get_mess($data, $ip, $mean, $first_mobile);//请求类型为获取状态报告
                        return $result;
                        break;
                    case 'get_balance':
                        $result = $this->get_mess($data, $ip, $mean);//请求类型为查询余额或条数
                        return $result;
                        break;
                    case 'single_send':
                        $result = $this->send($data, $ip, $mean);//请求类型为单条发送
                        return $result;
                        break;
                    case 'batch_send':
                        $result = $this->send($data, $ip, $mean, $first_mobile);//请求类型为相同内容群发
                        return $result;
                        break;
                    case 'multi_send':
                        $result = $this->send($data, $ip, $mean, $first_mobile);//请求类型为个性化群发
                        return $result;
                        break;
                    default : $NotLog->deposit_log('发送类型错误,错误代码:'.$this->error_code['ERROR_300018']);//日志记录捕获的异常消息
                        $result['result']=$this->error_code['ERROR_300018'];
                        return $result;
                        break;
                }
            }
            else if($GLOBALS['KEEPALIVE']==1)//用户设置为长连接或没有调用设置链接方法进行设置时
            {
                switch ($mean) {
                    case 'get_mo':
                        $result = $this->get_mess_keep($data, $ip, $mean, $first_mobile);//请求类型为获取上行
                        return $result;
                        break;
                    case 'get_rpt':
                        $result = $this->get_mess_keep($data, $ip, $mean, $first_mobile);//请求类型为获取状态报告
                        return $result;
                        break;
                    case 'get_balance':
                        $result = $this->get_mess_keep($data, $ip, $mean);//请求类型为查询余额
                        return $result;
                        break;
                    case 'single_send':
                        $result = $this->send_keep($data, $ip, $mean);//请求类型为单条发送
                        return $result;
                        break;
                    case 'batch_send':
                        $result = $this->send_keep($data, $ip, $mean, $first_mobile);//请求类型为相同内容群发
                        return $result;
                        break;
                    case 'multi_send':
                        $result = $this->send_keep($data, $ip, $mean, $first_mobile);//请求类型为个性化群发
                        return $result;
                        break;
                    default : $NotLog->deposit_log('发送类型错误,错误代码:'.$this->error_code['ERROR_300018']);//日志记录捕获的异常消息
                        $result['result']=$this->error_code['ERROR_300018'];
                        return $result;
                        break;
                }
            }
        }
        catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(), '根据请求方式进行请求操作失败。');//日志记录捕获的异常消息
        }
    }
}
?>
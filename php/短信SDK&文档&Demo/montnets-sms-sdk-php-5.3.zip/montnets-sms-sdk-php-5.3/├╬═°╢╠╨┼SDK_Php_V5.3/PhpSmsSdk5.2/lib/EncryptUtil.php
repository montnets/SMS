<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-14
 * Time: 16:40
 * @功能概要： 字段加密过滤类
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('NotLog.php');
class EncryptUtil{
    /**
     * 获取配置文件请求字段内容
     */
    public function get_config()
    {
        $error=include(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'config.php');//获取请求字段
        return $error;
    }
    /**
     * 密码加密
     * $userid：用户账号
     * $pwd：用户密码
     */
    public function encrypt_pwd($userid,$pwd)
    {
        $NotLog = new NotLog();
        try {
            $char = '00000000';//固定字符串
            $time = date('mdHis', time());//时间戳
            $pwd = $userid . $char . $pwd . $time;//拼接字符串进行加密
            return array('pwd' => $pwd, 'time' => $time);
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'账号、固定字符串、密码、时间戳进行字符串拼接失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 短信内容加密
     * $content：短信内容
     */
    public function encrypt_content($content)
    {
        $NotLog = new NotLog();
        try {
            return urlencode(iconv('UTF-8', 'GBK', $content));//短信内容转化为GBK格式再进行urlencode格式加密
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'短信内容加密失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 中英文字符长度计算验证
     * $string：字符串
     */
    public function utf8_strlen($string = null) //中英文字符长度验证
    {
        $NotLog = new NotLog();
        try {
            // 将字符串分解为单元
            preg_match_all("/./us", $string, $match);
            // 返回单元个数
            return count($match[0]);
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'中英文字符长度计算验证失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 个性化短信内容加密
     * $data：multimt包结构数据
     */
    public function multi_encrypt_content($data)
    {
        $NotLog = new NotLog();
        try {
            foreach ($data as $k => $v) {
                $data[$k]['content'] = urlencode(iconv('UTF-8', 'GBK', $v['content']));//短信内容转化为GBK格式再进行urlencode格式加密
            }
            return $data;
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'个性化短信内容加密失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 单条短信字段过滤
     * $data：单条短信请求数据
     */
    public function single_filter($data)
    {
        $requisite=array('timestamp'=>null,'mobile'=>null,'content'=>null);//必填字段键值
        $mw_config=$this->get_config();//获取配置文件返回参数
        $sing_send_parm=$mw_config['SINGLE_SEND_PARM'];//获取单条短信可提交字段
        $data=$this->data_filter($data,$sing_send_parm);//过滤数据
        $data=$this->no_requisite_filter($data,$requisite);//非必填字段为空处理
        return $data;
    }
    /**
     * 相同内容短信字段过滤
     * $data：相同内容群发请求数据
     */
    public function batch_filter($data)
    {
        $requisite=array('timestamp'=>null,'mobile'=>null,'content'=>null);//必填字段键值
        $mw_config=$this->get_config();//获取配置文件返回参数
        $batch_send_parm=$mw_config['BATCH_SEND_PARM'];//获取相同短信可提交字段
        $data=$this->data_filter($data,$batch_send_parm);//过滤数据
        $data=$this->no_requisite_filter($data,$requisite);//非必填字段为空处理
        return $data;
    }
    /**
     * 个性化短信字段过滤
     * $data：个性化短信发送请求数据
     */
    public function multi_filter($data)
    {
        $requisite=array('multimt'=>null);//必填字段键值
        $mw_config=$this->get_config();//获取配置文件返回参数
        $multi_parm=$mw_config['MULTI_SEND_PARM'];//获取个性化短信可提交字段
        $data=$this->data_filter($data,$multi_parm);//过滤数据
        if(!empty($data['multimt']))//含有短信包字段
        {
            foreach($data['multimt'] as $k=>$v)
            {
                $data['multimt'][$k]=$this->pack_filter($v);//过滤短信包中的多余字段
            }
        }
        $data=$this->no_requisite_filter($data,$requisite);//非必填字段为空处理
        return $data;
    }
    /**
     * 个性化短信multimt包结构字段过滤
     * $data：个性化短信multimt包结构数据
     */
    public function pack_filter($data)
    {
        $requisite=array('timestamp'=>null,'mobile'=>null,'content'=>null);//必填字段
        $mw_config=$this->get_config();//获取配置文件返回参数
        $pack_parm=$mw_config['MULTI_PACK'];//获取个性化短信可提交字段
        $data=$this->data_filter($data,$pack_parm);//过滤数据
        $data=$this->no_requisite_filter($data,$requisite);//非必填字段为空处理
        return $data;
    }
    /**
     * 非必填字段为空时过滤
     * $data 请求数据
     * $requisite必填字段键值
     */
    public function no_requisite_filter($data,$requisite)
    {
        $NotLog = new NotLog();
        try {
            $no_requisite = array_diff_key($data, $requisite);//获取非必填字段
            foreach ($no_requisite as $k => $v) {
                if (empty($v))//字段为空值
                {
                    unset($data[$k]);//移除该非必填字段
                }
            }
            return $data;//返回已处理的数组
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'非必填字段过滤失败。');//日志记录捕获的异常消息
        }
    }
    /**
     * 非接口字段过滤
     * $data 请求数据
     */
    public function data_filter($data,$set_filter)//请求数据过滤
    {
        $NotLog = new NotLog();
        try {
            $data_filter=array();//设置过滤数组
            foreach($set_filter as $k=>$v)
            {
                if(!empty($data[$v]))//如果所传数组中含有这个配置文件中已设置好的键值
                {
                    $data_filter[$v]=$data[$v];//赋值
                }
            }
            return $data_filter;//返回已处理的数组
        }catch (Exception $e) {
            $NotLog->deposit_error_log($e->getMessage(),'非接口字段过滤失败。');//日志记录捕获的异常消息
        }
    }
}
?>
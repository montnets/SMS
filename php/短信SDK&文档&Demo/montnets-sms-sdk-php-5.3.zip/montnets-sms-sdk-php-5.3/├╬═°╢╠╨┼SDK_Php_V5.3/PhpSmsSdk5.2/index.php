<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-13
 * Time: 14:20
 * @功能概要：示例文件
 * @项目名称： phpSmsSdk
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('MAutoload.php');

/*
* 设置全局参数(请求地址及是否需要日志)
*/
/*$GlobalValue=new GlobalValue();

try {
    $result = $GlobalValue->setGlobalParams('/sms/v2/std/', 1);
    if ($result['result'] == 0) {
        print_r('全局参数设置成功');
    } else {
        print_r('全局参数设置失败，错误码为：' . $result['result']);
    }
}catch (Exception $e) {
    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
* 设置账号信息
*/
/*$GlobalValue=new GlobalValue();
//账号
$userid='kuku76';
//密码
$pwd='123456';
//发送优先级
$priority='8';
//主IP(域名)
$ipAddress1='192.168.2.6:1000';
//备IP1(域名)
$ipAddress2='192.168.2.6:1001';
//备IP2(域名)
$ipAddress3='192.168.2.6:1002';
//备IP3(域名)
$ipAddress4='192.168.2.6:1003';

try {
    $result = $GlobalValue->setAccountInfo($userid, $pwd, $priority, $ipAddress1, $ipAddress2, $ipAddress3, $ipAddress4);
    if ($result['result'] == 0) {
        print_r('账号设置成功');
    } else {
        print_r('账号设置失败，错误码为：' . $result['result']);
    }
}catch (Exception $e) {
    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
* 移除账号信息
*/
/*$GlobalValue=new GlobalValue();

try {
    $result = $GlobalValue->removeAccount('kuku16');
    if ($result['result'] == 0) {
        print_r('移除账号成功');
    } else {
        print_r('移除账号失败，错误码为：' . $result['result']);
    }
}catch (Exception $e) {
    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
* 单条发送
*/
/*$smsSendConn = new smsSendConn();
$data=array();//初始化数组
//指定对应账号发送
$data['userid']='kuku06';
// 设置手机号码 此处只能设置一个手机号码
$data['mobile']='136xxxxxxxx';
// 设置内容
$data['content']='测试短信';
// 业务类型
$data['svrtype']='SMS001';
// 设置扩展号
$data['exno']='11';
//用户自定义流水编号
$data['custid']='b3d1a2783d31b21b8573';
// 自定义扩展数据
$data['exdata']='12316';

try{
    $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
    $result = $smsSendConn->singleSend($data);
    print_r($result);
    if($result['result']===0)
    {
        print_r("单条信息发送成功！");
    }
    else
    {
        print_r("单条信息发送失败，错误码：" .$result['result']);
    }
}
catch (Exception $e) {
    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
* 相同内容群发
*/
/*$smsSendConn = new smsSendConn();
$data=array();//初始化数组
//指定对应账号发送
$data['userid']='kuku06';
// 设置手机号码
$data['mobile']='136xxxxxxxx,138xxxxxxxx';
// 设置内容
$data['content']='测试短信';
// 业务类型
$data['svrtype']='SMS001';
// 设置扩展号
$data['exno']='11111';
//用户自定义流水编号
$data['custid']='b3d1a2783d31b21b8573';
// 自定义扩展数据
$data['exdata']='1231611';

try{
    $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
    $result = $smsSendConn->batchSend($data);
    print_r($result);
    if($result['result']===0)
    {
        print_r("相同内容群发成功！");
    }
    else
    {
        print_r("相同内容群发失败，错误码：" .$result['result']);
    }
}
catch (Exception $e) {

    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
* 个性化群发
*/
/*$smsSendConn = new smsSendConn();
$data=array();//初始化数组
//指定对应账号发送
$data['userid']='fxx22b';
$data['multimt']=array();
for($i=0;$i<=2;$i++)
{
    $data['multimt'][]=array(
        'mobile'=>(string)('136xxxxxxxx'+$i),
        'content'=>'测试短信',
        'svrtype'=>'SMS001',
        'exno'=>'11111',
        'custid'=>'b3d1a2783d31b21b8573',
        'exdata'=>'1231611');
}*/
/*$data['multimt']=array(
    array(
        'mobile'=>'136xxxxxxxx',
        'content'=>'测试短信',
        'svrtype'=>'SMS001',
        'exno'=>'11111',
        'custid'=>'b3d1a2783d31b21b8573',
        'exdata'=>'1231611'
    ),
    array(
        'mobile'=>'136xxxxxxxx',
        'content'=>'测试短信',
        'svrtype'=>'SMS001',
        'exno'=>'11111',
        'custid'=>'b3d1a2783d31b21b8573',
        'exdata'=>'1231611'
    )
);*/
//定义multimt包为数组形式

/*try{
    $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
    $result = $smsSendConn->multiSend($data);
    print_r($result);
    if($result['result']===0)
    {
        print_r("个性化群发成功！");
    }
    else
    {
        print_r("个性化群发失败，错误码：" .$result['result']);
    }
}
catch (Exception $e) {

    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
 * 查询剩余金额或条数
 */
/*$smsSendConn = new smsSendConn();

try{
    $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
    $result = $smsSendConn->getRemains('kuku06');//查询剩余金额或条数
    if($result['result']>=0)
    {
        if($result['chargetype']===0) {
            print_r("查询成功,当前计费模式为条数计费,剩余条数为：" . $result['balance']);
        }
        else if($result['chargetype']===1)
        {
            print_r("查询成功,当前计费模式为金额计费,剩余金额为：" . $result['money']."元");
        }
        else
        {
            print_r("未知的计费类型");
        }
    }
    else
    {
        print_r("查询余额失败，错误码：" .$result['result']);
    }
}
catch (Exception $e) {
    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
* 获取上行
*/
/*$smsSendConn = new smsSendConn();

try{
    $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
    $result = $smsSendConn->getMo('fxx22b',1);//获取上行
    if($result['result']==0) {
        foreach($result['mos'] as $k=>$v)
        {
            $result['mos'][$k]['content']=urldecode($v['content']);//将内容进行utf-8解码
        }
        print_r("获取上行成功");
        print_r($result['mos']);
    }
    else
    {
        print_r("获取上行失败，错误码：" .$result['result']);
    }
}
catch (Exception $e) {

    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/

/*
* 获取状态报告
*/
/*$smsSendConn = new smsSendConn();

try{
    $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
    $result = $smsSendConn->getRpt('kuk76',1);//获取状态报告
    if($result['result']==0)
    {
        print_r("获取状态报告成功");
        print_r($result['rpts']);//输出状态报告信息
    }
    else
    {
        print_r("获取状态报告失败，错误码：" .$result['result']);
    }
}
catch (Exception $e) {
    echo  $e->getMessage(), "\n";  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
}*/


/*
 * 线程获取上行(由于此处线程已设置为永久执行，一旦启用只能通过重启服务器关闭，不要多次调用该线程方法，否则每次调用都会开启一个新的线程占用资源，请谨慎使用)
 */
/*class RecvMoThreadThread extends \Thread
{
    public function running()
    {
        require_once('MAutoload.php');//自动加载类文件需在线程类中进行引用,此处由于顶部已经进行了引用，使用线程时需将顶部的引用进行删除或注释
        $smsSendConn = new SmsSendConn();
        try {
            $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
            while (true) {
                $result = $smsSendConn->getMo('kuku06', 1);//获取上行;
                if ($result['mos'] == null) {
                    /*
                    *此处获取到状态报告后可根据需要写入将上行数据录入数据库的代码
                    */
                    /*sleep(2);//睡眠2秒
                }
            }
        } catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
        }
    }


    public function run()
    {
        try {
            set_time_limit(0);//永久执行该线程任务
            $this->running();//开始线程任务
        } catch (Exception $e) {
             print_r($e->getMessage());  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
        }
    }
}


$RecvMoAccountThread =new RecvMoThreadThread();
$RecvMoAccountThread->start();//开始执行线程
*/

/*
 * 线程获取状态报告(由于此处线程已设置为永久执行，一旦启用只能通过重启服务器关闭，不要多次调用该线程方法，否则每次调用都会开启一个新的线程占用资源，请谨慎使用)
 */
/*class RecvRptThreadThread extends \Thread
{
    public function running()
    {
        require_once('MAutoload.php');//自动加载类文件需在线程类中进行引用,此处由于顶部已经进行了引用，使用线程时需将顶部的引用进行删除或注释
        $smsSendConn=new SmsSendConn();
        try {
            $smsSendConn->SmsSendConn(true);//设置长连接或短链接，true保持长连接，false短连接
            while (true) {
                $result=$smsSendConn->getRpt('kuku06',1);//获取状态报告;
                if($result['rpts']==null)
                {
                     /*
                     *此处获取到状态报告后可根据需要写入将上行数据录入数据库的代码
                     */
                    /*sleep(2);//睡眠2秒
                }
            }
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
        }
    }

    public function run()
    {
        try {
            set_time_limit(0);//永久执行该线程任务
            $this->running();//开始线程任务
        } catch (Exception $e) {
             print_r($e->getMessage());  //输出捕获的异常消息，请根据实际情况，添加异常处理代码
        }

    }
}

$RecvRptAccountThread =new RecvRptThreadThread();
$RecvRptAccountThread->start();//开始执行线程
*/

?>
<?php
/**
 * Created by PhpStorm.
 * Date: 2017-2-28
 * Time: 10:15
 * @功能概要：调用DEMO
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('SmsSendConn.php');
require_once('ConfigManager.php');

/*
* 设置主备IP信息
*/
/*$ConfigManager=new ConfigManager();
//主IP
$ip['ipAddress1']='sdktest01.monyun.cn:7832';
//备IP1
$ip['ipAddress2']='sdktest02.monyun.cn:7832';
//备IP2
$ip['ipAddress3']='192.169.2.28:8080';
//备IP3
$ip['ipAddress4']='192.169.2.6:7832';
try {
    if ($ConfigManager->set_usableip($ip)) {
        print_r("IP设置成功！");
    } else {
        print_r("IP设置失败！");
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/

/*
* 清除所有IP信息
*/
/*$ConfigManager = new ConfigManager();
try {
    if ($ConfigManager->removeAllIpInfo()) {
        print_r("所有IP信息清除成功！");
    } else {
        print_r("所有IP信息清除失败！");
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/

/*
* 单条发送
*/
/*$SmsSendConn=new SmsSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置手机号码 此处只能设置一个手机号码
$data['mobile']='13600112211';
//设置发送短信内容
$data['content']='测试短信';
// 业务类型
$data['svrtype']='SMS001';
// 设置扩展号
$data['exno']='11';
//用户自定义流水编号
$data['custid']='b3d1a2783d31b21b8573';
// 自定义扩展数据
$data['exdata']='12316';
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $SmsSendConn->singleSend($url, $data, $isEncryptPwd);
    if ($result['result'] === 0) {
        print_r("单条信息发送成功！");
    } else {
        print_r("单条信息发送失败，错误码：" . $result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/

/*
 * 相同内容群发
 */
/*$SmsSendConn=new SmsSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置手机号码 此处只能设置一个手机号码
$data['mobile']='13600112211,13600112211,13600112211';
//设置发送短信内容
$data['content']='测试短信';
// 业务类型
$data['svrtype']='SMS001';
// 设置扩展号
$data['exno']='11';
//用户自定义流水编号
$data['custid']='b3d1a2783d31b21b8573';
// 自定义扩展数据
$data['exdata']='12316';
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $SmsSendConn->batchSend($url, $data, $isEncryptPwd);

    if ($result['result'] === 0) {
        print_r("相同内容信息发送成功！");
    } else {
        print_r("相同内容信息发送失败，错误码：" . $result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/

/*
 * 个性化群发
 */
/*$SmsSendConn=new SmsSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
//multimt包结构集合
$data['multimt']=array(
    array(
        'mobile'=>'13600112211',
        'content'=>'测试短信',
        'svrtype'=>'SMS001',
        'exno'=>'11111',
        'custid'=>'b3d1a2783d31b21b8573',
        'exdata'=>'1231611'
    ),
    array(
        'mobile'=>'13600112212',
        'content'=>'测试短信',
        'svrtype'=>'SMS001',
        'exno'=>'11111',
        'custid'=>'b3d1a2783d31b21b8573',
        'exdata'=>'1231611'
    )
);
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $SmsSendConn->multiSend($url, $data, $isEncryptPwd);

    if ($result['result'] === 0) {
        print_r("个性化内容信息发送成功！");
    } else {
        print_r("个性化内容信息发送失败，错误码：" . $result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/

/*
 * 查询剩余金额或条数
 */
/*$SmsSendConn=new SmsSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $SmsSendConn->getBalance($url, $data, $isEncryptPwd);
    if ($result['result'] === 0) {
        if ($result['chargetype'] === 0) {
            print_r("查询成功，当前计费模式为条数计费,剩余条数为：" . $result['balance']);
        } else if ($result['chargetype'] === 1) {
            print_r("查询成功，当前计费模式为金额计费,剩余金额为：" . $result['money']);
        } else {
            print_r("未知的计费类型");
        }
    } else {
        print_r("查询余额失败，错误码：" . $result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/


/*
 * 获取上行
 */
/*$SmsSendConn=new SmsSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置获取上行的最大条数
$data['retsize']='100';
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $SmsSendConn->getMo($url, $data, $isEncryptPwd);
    if($result['result']===0)
    {
        print_r("获取上行成功");
        print_r($result['mos']);
    }
    else
    {
        print_r("获取上行失败，错误码：" .$result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/


/*
 * 获取状态报告
 */
/*
$SmsSendConn=new SmsSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置获取上行的最大条数
$data['retsize']='100';
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $SmsSendConn->getRpt($url, $data, $isEncryptPwd);//获取状态报告
    if($result['result']===0)
    {
        print_r("获取状态报告成功");
        print_r($result['rpts']);//输出状态报告信息
    }
    else
    {
        print_r("获取状态报告失败，错误码：" .$result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/


/*
 * 线程获取上行(由于此处线程已设置为永久执行，一旦启用只能通过重启服务器关闭，不要多次调用该线程方法，否则每次调用都会开启一个新的线程占用资源，请谨慎使用)
 */
/*require_once('RecvMoThread.php');
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置获取上行的最大条数
$data['retsize']='100';
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $RecvMoThread = new RecvMoThread($url, $data, $isEncryptPwd);
    $RecvMoThread->start();//开始执行线程
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/


/*
 * 线程获取状态报告(由于此处线程已设置为永久执行，一旦启用只能通过重启服务器关闭，不要多次调用该线程方法，否则每次调用都会开启一个新的线程占用资源，请谨慎使用)
 */
/*require_once('RecvRptThread.php');
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='kuku06';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置获取上行的最大条数
$data['retsize']='100';
//请求地址
$url='/sms/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $RecvMoThread = new RecvRptThread($url, $data, $isEncryptPwd);
    $RecvMoThread->start();//开始执行线程
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/
?>
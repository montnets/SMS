<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-03-06
 * Time: 21:40
 */
require_once('PhpSmsAPIDemo_JSON/ConfigManager.php');
require_once('PhpSmsAPIDemo_JSON/SmsSendConn.php');
$Method=$_POST['Method'];//获取方法名

if(!empty($Method))//获取到请求方法名称
{
    $data_transfer=new data_transfer();
    switch($Method)
    {
        case 'get_ip':$result=$data_transfer->get_ip();
                        echo $result;
                        break;
        case 'set_ip':$result=$data_transfer->set_ip();
                        echo $result;
                        break;
        case 'single_send':$result=$data_transfer->single_send();
                        echo $result;
                        break;
        case 'batch_send':$result=$data_transfer->batch_send();
                        echo $result;
                        break;
        case 'multimt_send':$result=$data_transfer->multimt_send();
                        echo $result;
                        break;
        case 'get_balance':$result=$data_transfer->get_balance();
                        echo $result;
                        break;
        case 'get_mo':$result=$data_transfer->get_mo();
                        echo $result;
                        break;
        case 'get_rpt':$result=$data_transfer->get_rpt();
                        echo $result;
                        break;
        case 'remove_ip':$result=$data_transfer->remove_ip();
                            echo $result;
                            break;
    }
}
class data_transfer
{
    /*
     * 获取IP信息
     */
    public function get_ip()
    {
        try {
            $ConfigManager = new ConfigManager();
            if ($ip = $ConfigManager->get_ip())//获取IP成功
            {
                $result = json_encode($ip);
                return $result;//返回IP集合
            } else {
                return null;//返回null
            }
        }
        catch(Exception $e){
            return null;//返回null
        }
    }
    /*
     * 设置IP信息
     */
    public function set_ip()
    {
        $ConfigManager=new ConfigManager();
        //初始化数组
        $ip=array();
        //主IP
        if(!empty($_POST['ip1'])){
            $ip['ipAddress1'] = $_POST['ip1'];//获取IP信息
        }
        //备IP1
        if(!empty($_POST['ip2'])){
            $ip['ipAddress2'] = $_POST['ip2'];//获取IP信息
        }
        //备IP2
        if(!empty($_POST['ip3'])){
            $ip['ipAddress3'] = $_POST['ip3'];//获取IP信息
        }
        //备IP3
        if(!empty($_POST['ip4'])){
            $ip['ipAddress4'] = $_POST['ip4'];//获取IP信息
        }
        try {
            if(!empty($ip)) //获取到设置好的IP值
            {
                if ($ConfigManager->set_usableip($ip)) //保存设置的IP成功
                {
                    $result = json_encode(array('state' => 0, 'info' => "ip保存成功！"));
                    return $result;//以JSON格式返回数据
                } else {
                    $result = json_encode(array('state' => 1, 'info' => "ip保存失败！"));
                    return $result;//以JSON格式返回数据
                }
            }
            else//未获取到设置好的IP值
            {
                $result = json_encode(array('state' => 1, 'info' => "ip保存失败！"));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "ip保存失败！错误信息".$e->getMessage()));
            return $result;//以JSON格式返回数据
        }
    }
    /*
     * 清除IP信息
     */
    public function remove_ip()
    {
        try {
        $ConfigManager=new ConfigManager();
            if($ConfigManager->removeAllIpInfo())//获取IP成功
            {
                $result = json_encode(array('state' => 0, 'info' => "ip信息重置成功"));
                return $result;//以JSON格式返回数据
            }
            else
            {
                $result = json_encode(array('state' => 1, 'info' => "ip信息重置失败"));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "ip信息重置失败".$e->getMessage()));
            return $result;//以JSON格式返回数据
        }
    }
    /*
    * 单条信息发送
    */
    public function single_send()
    {
        $SmsSendConn=new SmsSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        // 设置手机号码 此处只能设置一个手机号码
        if(!empty($_POST['mobile'])){
            $data['mobile'] = $_POST['mobile'];//获取IP信息
        }
        //设置发送短信内容
        if(!empty($_POST['content'])){
            $data['content'] = $_POST['content'];//获取IP信息
        }
        // 业务类型
        $data['svrtype']=!empty($_POST['svrtype'])? $_POST['svrtype'] : null;//若无信息则返回null
        // 设置扩展号
        $data['exno']=!empty($_POST['exno'])? $_POST['exno'] : null;//若无信息则返回null
        //用户自定义流水编号
        $data['custid']=!empty($_POST['custid'])? $_POST['custid'] : null;//若无信息则返回null
        // 自定义扩展数据
        $data['exdata']=!empty($_POST['exdata'])? $_POST['exdata'] : null;//若无信息则返回null
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        try {
            $result = $SmsSendConn->singleSend($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result['mobile']=$data['mobile'];//返回值赋值此次发送的电话号码
                $result = json_encode(array('state' => 0, 'info' => "单条信息发送成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "单条信息发送失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "单条信息发送失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }
    /*
    * 相同内容发送
    */
    public function batch_send()
    {
        $SmsSendConn=new SmsSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        // 设置手机号码 此处只能设置一个手机号码
        if(!empty($_POST['mobile'])){
            $data['mobile'] = $_POST['mobile'];//获取IP信息
        }
        //设置发送短信内容
        if(!empty($_POST['content'])){
            $data['content'] = $_POST['content'];//获取IP信息
        }
        // 业务类型
        $data['svrtype']=!empty($_POST['svrtype'])? $_POST['svrtype'] : null;//若无信息则返回null
        // 设置扩展号
        $data['exno']=!empty($_POST['exno'])? $_POST['exno'] : null;//若无信息则返回null
        //用户自定义流水编号
        $data['custid']=!empty($_POST['custid'])? $_POST['custid'] : null;//若无信息则返回null
        // 自定义扩展数据
        $data['exdata']=!empty($_POST['exdata'])? $_POST['exdata'] : null;//若无信息则返回null
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        try {
            $result = $SmsSendConn->batchSend($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result['mobile']=explode(",",$data['mobile'])[0];//返回值赋值此次发送的第一个电话号码
                $result = json_encode(array('state' => 0, 'info' => "相同内容信息发送成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "相同内容信息发送失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "相同内容信息发送失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }
    /*
   * 个性化发送
   */
    public function multimt_send()
    {
        $SmsSendConn=new SmsSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['msg_num'])){
            $msg_num = $_POST['msg_num'];//获取IP信息
            for($i=1;$i<=$msg_num;$i++)
            {
                // 设置手机号码 此处只能设置一个手机号码
                if(!empty($_POST['mobile'.$i])){
                    $mobile = $_POST['mobile'.$i];//获取IP信息
                }
                //设置发送短信内容
                if(!empty($_POST['content'.$i])){
                    $content= $_POST['content'.$i];//获取IP信息
                }
                // 业务类型
                $svrtype=!empty($_POST['svrtype'.$i])? $_POST['svrtype'.$i] : null;//若无信息则返回null
                // 设置扩展号
                $exno=!empty($_POST['exno'.$i])? $_POST['exno'.$i] : null;//若无信息则返回null
                //用户自定义流水编号
                $custid=!empty($_POST['custid'.$i])? $_POST['custid'.$i] : null;//若无信息则返回null
                // 自定义扩展数据
                $exdata=!empty($_POST['exdata'.$i])? $_POST['exdata'.$i] : null;//若无信息则返回null
                $data['multimt'][]=array('mobile'=>$mobile,'content'=>$content,'svrtype'=>$svrtype,'exno'=>$exno,'custid'=>$custid,'exdata'=>$exdata);//对multimt数组进行赋值
            }
        }
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        try {
            $result = $SmsSendConn->multiSend($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result['mobile']= $data['multimt'][0]['mobile'];//返回值赋值此次发送的第一个电话号码
                $result = json_encode(array('state' => 0, 'info' => "不同内容信息发送成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "不同内容信息发送失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "不同内容信息发送失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }
    /*
   * 查询余额
   */
    public function get_balance()
    {
        $SmsSendConn=new SmsSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        try {
            $result = $SmsSendConn->getBalance($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result = json_encode(array('state' => 0, 'info' => "查询余额成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "查询余额失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "查询余额失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }
    /*
    * 获取上行
    */
    public function get_mo()
    {
        $SmsSendConn=new SmsSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
           $isEncryptPwd=true;
        }
        else
        {
           $isEncryptPwd=false;
        }
        $data['retsize']=10;//获取条数默认10条
        try {
            $result = $SmsSendConn->getMo($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                foreach($result['mos'] as $k=>$v)
                {
                    $result['mos'][$k]['content']=urldecode($v['content']);//将内容进行utf-8解码
                }
                $result = json_encode(array('state' => 0, 'info' => "获取上行成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "获取上行失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "获取上行失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }
    /*
   * 获取状态报告
   */
    public function get_rpt()
    {
        $SmsSendConn=new SmsSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        $data['retsize']=10;//获取条数默认10条
        try {
            $result = $SmsSendConn->getRpt($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result = json_encode(array('state' => 0, 'info' => "获取状态报告成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "获取状态报告失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "获取状态报告失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }
}
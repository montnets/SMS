$(document).ready(function(){
	$.ajax({
		cache: true,
		type: "POST",
		url:'./DataTransfer.php',
		data:{"Method":'get_ip'},// ip表单
		dataType: "json",
		success: function(data) {
			if(data=='') //已经设置过IP信息
			{
				$('#first').show();//设置IP显示
				$('#second').hide();//业务请求隐藏
			}
			else
			{
				$('#first').hide();//设置IP隐藏
				$('#second').show();//业务请求显示
			}
		},
		error: function(e) {
			$('#first').show();//设置IP显示
			$('#second').hide();//业务请求隐藏
		}
	});
});

//短信接口接口类型选择之后的操作
$('.st_rType').on('change',function(){
	var options=$(".st_rType option:selected").val();
	if(options == 1){
		$('#single_send').show();
		$('#batch_send').hide();
		$('#multimt_send').hide();
		$('#get_balance').hide();
		$('#get_mo').hide();
		$('#get_rpt').hide();
	}else if(options == 2){
		$('#single_send').hide();
		$('#batch_send').show();
		$('#multimt_send').hide();
		$('#get_balance').hide();
		$('#get_mo').hide();
		$('#get_rpt').hide();
	}else if(options == 3){
		$('#single_send').hide();
		$('#batch_send').hide();
		$('#multimt_send').show();
		$('#get_balance').hide();
		$('#get_mo').hide();
		$('#get_rpt').hide();
	}else if(options == 4){
		$('#single_send').hide();
		$('#batch_send').hide();
		$('#multimt_send').hide();
		$('#get_balance').show();
		$('#get_mo').hide();
		$('#get_rpt').hide();
	}else if(options == 5){
		$('#single_send').hide();
		$('#batch_send').hide();
		$('#multimt_send').hide();
		$('#get_balance').hide();
		$('#get_mo').show();
		$('#get_rpt').hide();
	}else if(options == 6){
		$('#single_send').hide();
		$('#batch_send').hide();
		$('#multimt_send').hide();
		$('#get_balance').hide();
		$('#get_mo').hide();
		$('#get_rpt').show();
	}
})


//添加一个内容
$('.MPhone_table').on('click','.addTMSK',function(){
	var trCount = $('.MPhone_table_body tr').length;
	if(Number(trCount)>10){
		alert('最多只能添加10个');
		return;
	}
	
	var html = '';
	var name1 = "mobile"+trCount;
	var name2 = 'content'+trCount;
	var name3 = 'svrtype'+trCount;
	var name4 = 'exnos'+trCount;
	var name5 = 'custid'+trCount;
	var name6 = 'exdata'+trCount;
	html = "<tr><td>"+(trCount)+'</td><td>'+'<input name="'+name1+'"  maxlength = "11" style="float:left;width:120px;margin-left: 0px;" type = "text" /><span style="float:right;" class="required">*</span>'+'</td><td>'+
	'<input name="'+name2+'" style ="width:220px;float:left; margin-left:0px;" type = "text" /><span style="float:right;" class="required">*</span>'+'</td><td>'+
	'<input name="'+name3+'"  style ="width:120px" type = "text" />'+'</td><td>'+
	'<input name="'+name4+'"  style ="width:120px" type = "text" />'+'</td><td>'+
	'<input name="'+name5+'"  style ="width:300px" type = "text" />'+'</td><td>'+
	'<input name="'+name6+'"  style ="width:120px" type = "text" />'+'</td><td><a class="st_deleteSMS">删除</a></td></tr>';
	$('.MPhone_table_body').append(html);
	$("[name='msg_num']").val(trCount);//个性化信息条数
})

//删除一行
$('.MPhone_table').on('click','.st_deleteSMS',function(){
	$(this).closest('tr').remove(); 
	$(".MPhone_table_body tr").each(function(i){
	 	    //获取各个控件
	 	    if(i>0){
	 	    	var ip0 = $(this).children().eq(0);
            ip0.text(i);
            var name1 = "diffMobiles"+i;
	        var name2 = 'diffContents'+i;
	        var name3 = 'diffSvrtypes'+i;
			var name4 = 'diffExnos'+i;
			var name5 = 'diffCustids'+i;
			var name6 = 'diffExdata'+i;
	 	  }
            
   });
})

//提交设置IP信息
$("#setip").click(function () {
	var ip1=$("[name='ip1']").val();
	if(ip1!='')
	{
		var ip1_yz=true;
	}
	if(ip1_yz) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'set_ip'}) + '&' + $('#form_ip').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) //IP设置成功
				{
					$('#first').hide();//设置IP隐藏
					$('#second').show();//业务请求显示
				}
				alert(data['info']);
			},
			error: function (e) {
				alert("ip保存失败");
			}
		});
	}
	else
	{
		alert("请填写主IP信息");
	}
})

//重置清空IP信息
$("#removeip").click(function () {
	$.ajax({
		cache: true,
		type: "POST",
		url:'./DataTransfer.php',
		data:{"Method":'remove_ip'},// ip表单
		dataType: "json",
		success: function(data) {
			if(data['state']==0) //移除成功
			{
				$('#first').show();//设置IP显示
				$('#second').hide();//业务请求隐藏
			}
			else
			{
				$('#first').hide();//设置IP隐藏
				$('#second').show();//业务请求显示
			}
			alert(data['info']);
		},
		error: function(e) {
			$('#first').hide();//设置IP隐藏
			$('#second').show();//业务请求显示
			alert('ip信息重置失败');
		}
	});
})

//单条信息发送
$("#singlesend").click(function () {
	var userid=$("#single_send [name='userid']").val();
	var pwd=$("#single_send [name='pwd']").val();
	var mobile=$("#single_send [name='mobile']").val();
	var content= $("#single_send [name='content']").val();
	var url=$("#single_send [name='url']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(mobile!='')
	{
		var yz_mobile=true;
	}
	if(content!='')
	{
		var yz_content=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(yz_userid&&yz_pwd&&yz_mobile&&yz_content&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'single_send'}) + '&' + $('#form_single').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					var str = data['info'] + '  发送号码:' + data['data']['mobile'] + '  梦网流水号:' + data['data']['msgid'] + '  自定义流水号:' + data['data']['custid'];
					$('#single_send textarea.show_result').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					$('#single_send textarea.show_result').html(str);
				}
			},
			error: function (e) {
				$('#single_send textarea.show_result').html("单条信息发送失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})

//相同内容发送
$("#batchsend").click(function () {
	var userid=$("#batch_send [name='userid']").val();
	var pwd=$("#batch_send [name='pwd']").val();
	var mobile=$("#batch_send [name='mobile']").val();
	var content= $("#batch_send [name='content']").val();
	var url=$("#batch_send [name='url']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(mobile!='')
	{
		var yz_mobile=true;
	}
	if(content!='')
	{
		var yz_content=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(yz_userid&&yz_pwd&&yz_mobile&&yz_content&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'batch_send'}) + '&' + $('#form_batch').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					var str = data['info'] + '  发送号码:' + data['data']['mobile'] + '  梦网流水号:' + data['data']['msgid'] + '  自定义流水号:' + data['data']['custid'];
					$('#batch_send textarea.show_result').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					$('#batch_send textarea.show_result').html(str);
				}
			},
			error: function (e) {
				$('#batch_send textarea.show_result').html("相同内容发送失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})

//不同内容发送
$("#multimtsend").click(function () {
	var userid=$("#multimt_send [name='userid']").val();
	var pwd=$("#multimt_send [name='pwd']").val();
	var url=$("#multimt_send [name='url']").val();
	var msg_num=$("[name='msg_num']").val();//个性化信息条数
	var j=0;
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(msg_num!=0)
	{
		var yz_msg_num=true;
		for(var i=1;i<=msg_num;i++)
		{
			var mobile=$("#multimt_send [name='mobile"+i+"']").val();
			var content=$("#multimt_send [name='content"+i+"']").val();
			if(mobile==''||content=='')
			{
				j=1;
			}
		}
		if(j==0)
		{
			var yz_message=true;
		}
	}
	if(yz_userid&&yz_pwd&&yz_msg_num&&yz_message&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'multimt_send'}) + '&' + $('#form_multimt').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					var str = data['info'] + '  发送号码:' + data['data']['mobile'] + '  梦网流水号:' + data['data']['msgid'] + '  自定义流水号:' + data['data']['custid'];
					$('#multimt_send textarea.show_result').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					$('#multimt_send textarea.show_result').html(str);
				}
			},
			error: function (e) {
				$('#multimt_send textarea.show_result').html("不同内容发送失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})

//查询余额
$("#getbalance").click(function () {
	var userid=$("#get_balance [name='userid']").val();
	var pwd=$("#get_balance [name='pwd']").val();
	var url=$("#get_balance [name='url']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(yz_userid&&yz_pwd&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'get_balance'}) + '&' + $('#form_balance').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					if (data['data']['chargetype'] == 0) {
						var str = data['info'] + '  计费模式为条数计费，剩余条数为:' + data['data']['balance'] + ' 条';
					}
					else {
						var str = data['info'] + '  计费模式为金额计费，剩余金额为:' + data['data']['money'] + ' 元';
					}
					$('#get_balance textarea.show_result').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					$('#get_balance textarea.show_result').html(str);
				}
			},
			error: function (e) {
				$('#get_balance textarea.show_result').html("查询余额失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})

//获取上行
$("#getmo").click(function () {
	var userid=$("#get_mo [name='userid']").val();
	var pwd=$("#get_mo [name='pwd']").val();
	var url=$("#get_mo [name='url']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(yz_userid&&yz_pwd&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'get_mo'}) + '&' + $('#form_mo').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					if (data['data']['mos'] == '') {
						alert('暂无上行信息');
					}
					else {
						var mo = '';
						$.each(data['data']['mos'], function (mos, v) {   // 遍历Object数组 ，每个对象的值存放在value ，index2表示为第几个对象
							mo += '<tr><th>' + v.msgid + '</th> <th>' + v.mobile + '</th> <th>' + v.spno + '</th> <th>' + v.rtime + '</th> <th>' + v.content + '</th> </tr>'
						});
						var str = '<tr><th>平台流水号</th> <th>上行手机号</th> <th>上行通道号</th> <th>上行时间</th> <th>上行内容</th> </tr>' + mo;
					}
					$('.st_SMS_shangx_body').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					alert(str);
				}
			},
			error: function (e) {
				alert("获取上行失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})

//获取状态报告
$("#getrpt").click(function () {
	var userid=$("#get_rpt [name='userid']").val();
	var pwd=$("#get_rpt [name='pwd']").val();
	var url=$("#get_rpt [name='url']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(yz_userid&&yz_pwd&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'get_rpt'}) + '&' + $('#form_rpt').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					if (data['data']['rpts'] == '') {
						alert('暂无状态报告信息');
					}
					else {
						var rpt = '';
						$.each(data['data']['rpts'], function (rpts, v) {   // 遍历Object数组 ，每个对象的值存放在value ，index2表示为第几个对象
							rpt += '<tr><th>' + v.msgid + '</th> <th>' + v.pknum + '</th> <th>' + v.pktotal + '</th> <th>' + v.mobile + '</th> <th>' + v.spno + '</th><th>' + v.stime + '</th><th>' + v.rtime + '</th><th>' + v.status + '</th><th>' + v.errcode + '</th><th>' + v.errdesc + '</th> </tr>'
						});
						var str = '<tr><th>平台流水号</th><th>当前条数</th> <th>总条数</th> <th>手机号</th> <th>完整通道号</th> <th>发送时间</th> <th>返回时间</th> <th>接收状态</th> <th>错误代码</th> <th>错误代码描述</th><tr>' + rpt;
					}
					$('.st_SMS_Status_body').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					alert(str);
				}
			},
			error: function (e) {
				alert("获取状态报告失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})
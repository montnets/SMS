<?php
/**
 * Created by PhpStorm.
 * Date: 2016-11-28
 * Time: 13:57
 * @功能概要：发送管理类
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('Chttp.php');
require_once('EncryptUtil.php');
require_once('ConfigManager.php');

class SmsSendConn
{
    public $ERROR_310099=-310099;//http请求失败
     /*
     * 单条发送
      * $url:请求地址
      * $data:请求数据集合
      * $isEncryptPwd:是否加密
     */
    public function singleSend($url,$data,$isEncryptPwd)
    {
        try {
            $EncryptUtil = new EncryptUtil();
            $data['userid'] = strtoupper($data['userid']);//用户名转化为大写
            if($isEncryptPwd===true)//密码设置为加密模式
            {
                $encrypt=$EncryptUtil->encrypt_pwd($data['userid'],$data['pwd']);//密码进行MD5加密
                $data['pwd']=$encrypt['pwd'];//获取MD5加密后的密码
                $data['timestamp']=$encrypt['time'];//获取加密时间戳
            }
            else {
                $data['timestamp'] = time();//获取时间戳
            }
            $data['content'] = $EncryptUtil->encrypt_content($data['content']);//短信内容进行urlencode加密
            $post_data = json_encode($data);//将数组转化为JSON格式
            $result = $this->request_type($post_data, $url, 'single_send');//根据请求类型进行请求
            return $result;//返回请求结果
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /*
    * 相同内容群发
     * $url:请求地址
     * $data:请求数据集合
     * $isEncryptPwd:是否加密
    */
    public function batchSend($url,$data,$isEncryptPwd)
    {
        try{
            $EncryptUtil=new EncryptUtil();
            $data['userid']=strtoupper($data['userid']);//用户名转化为大写
            if($isEncryptPwd===true)//密码设置为加密模式
            {
                $encrypt=$EncryptUtil->encrypt_pwd($data['userid'],$data['pwd']);//密码进行MD5加密
                $data['pwd']=$encrypt['pwd'];//获取MD5加密后的密码
                $data['timestamp']=$encrypt['time'];//获取加密时间戳
            }
            else {
                $data['timestamp'] = time();//获取时间戳
            }
            $data['content']=$EncryptUtil->encrypt_content($data['content']);//短信内容进行urlencode加密
            $post_data=json_encode($data);//将数组转化为JSON格式
            $result=$this->request_type($post_data,$url,'batch_send');//根据请求类型进行请求
            return $result;
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /*
    * 个性化内容群发
     * $url:请求地址
     * $data:请求数据集合
     * $isEncryptPwd:是否加密
    */
    public function multiSend($url,$data,$isEncryptPwd)
    {
        try{
            $EncryptUtil=new EncryptUtil();
            $data['userid']=strtoupper($data['userid']);//用户名转化为大写
            if($isEncryptPwd===true)//密码设置为加密模式
            {
                $encrypt=$EncryptUtil->encrypt_pwd($data['userid'],$data['pwd']);//密码进行MD5加密
                $data['pwd']=$encrypt['pwd'];//获取MD5加密后的密码
                $data['timestamp']=$encrypt['time'];//获取加密时间戳
            }
            else {
                $data['timestamp'] = time();//获取时间戳
            }
            foreach($data['multimt'] as $k=>$v)
            {
                $data['multimt'][$k]['content'] = $EncryptUtil->encrypt_content($v['content']);//每一条个性化的短信内容进行urlencode加密
            }
            $post_data=json_encode($data);//将数组转化为JSON格式
            $result=$this->request_type($post_data,$url,'multi_send');//根据请求类型进行请求
            return $result;
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /*
    * 查询余额
     * $url:请求地址
     * $data:请求数据集合
     * $isEncryptPwd:是否加密
    */
    public function getBalance($url,$data,$isEncryptPwd)
    {
        try{
            $EncryptUtil=new EncryptUtil();;
            $data['userid']=strtoupper($data['userid']);//用户名转化为大写
            if($isEncryptPwd===true)//密码设置为加密模式
            {
                $encrypt=$EncryptUtil->encrypt_pwd($data['userid'],$data['pwd']);//密码进行MD5加密
                $data['pwd']=$encrypt['pwd'];//获取MD5加密后的密码
                $data['timestamp']=$encrypt['time'];//获取加密时间戳
            }
            else {
                $data['timestamp'] = time();//获取时间戳
            }
            $post_data=json_encode($data);//将数组转化为JSON格式
            $result=$this->request_type($post_data,$url,'get_balance');//根据请求类型进行请求
            return $result;
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /*
     * 请求获取上行
     * $url:请求地址
     * $data:请求数据集合
     * $isEncryptPwd:是否加密
    */
    public function getMo($url,$data,$isEncryptPwd)
    {
        try{
            $SmsSendConn=new SmsSendConn();
            $EncryptUtil = new EncryptUtil();
            $data['userid']=strtoupper($data['userid']);//用户名转化为大写
            if($isEncryptPwd===true)//密码设置为加密模式
            {
                $encrypt=$EncryptUtil->encrypt_pwd($data['userid'],$data['pwd']);//密码进行MD5加密
                $data['pwd']=$encrypt['pwd'];//获取MD5加密后的密码
                $data['timestamp']=$encrypt['time'];//获取加密时间戳
            }
            else {
                $data['timestamp'] = time();//获取时间戳
            }
            $post_data = json_encode($data);//将数组转化为JSON格式
            $result=$SmsSendConn->request_type($post_data,$url,'get_mo');//根据请求类型进行请求
            return $result;//返回请求结果
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /*
    * 请求获取状态报告
    * $url:请求地址
    * $data:请求数据集合
    * $isEncryptPwd:是否加密
   */
    public function getRpt($url,$data,$isEncryptPwd)
    {
        try{
            $SmsSendConn=new SmsSendConn();
            $EncryptUtil = new EncryptUtil();
            $data['userid']=strtoupper($data['userid']);//用户名转化为大写
            if($isEncryptPwd===true)//密码设置为加密模式
            {
                $encrypt=$EncryptUtil->encrypt_pwd($data['userid'],$data['pwd']);//密码进行MD5加密
                $data['pwd']=$encrypt['pwd'];//获取MD5加密后的密码
                $data['timestamp']=$encrypt['time'];//获取加密时间戳
            }
            else {
                $data['timestamp'] = time();//获取时间戳
            }
            $post_data = json_encode($data);//将数组转化为JSON格式
            $result=$SmsSendConn->request_type($post_data,$url,'get_rpt');//根据请求类型进行请求
            return $result;
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }

    /**
     * 根据请求方式进行请求操作
     * *$data：请求提交数据
     * $url：请求地址
     * $mean：请求类型
     */
    public function request_type($data,$url,$mean)
    {
        try {
                switch ($mean) {
                    case 'get_mo':
                        $result = $this->request($data,$url,$mean);//请求类型为获取上行
                        return $result;
                        break;
                    case 'get_rpt':
                        $result = $this->request($data,$url,$mean);//请求类型为获取状态报告
                        return $result;
                        break;
                    case 'get_balance':
                        $result = $this->request($data,$url, $mean);//请求类型为查询余额或条数
                        return $result;
                        break;
                    case 'single_send':
                        $result = $this->request($data,$url,$mean);//请求类型为单条发送
                        return $result;
                        break;
                    case 'batch_send':
                        $result = $this->request($data,$url,$mean);//请求类型为相同内容群发
                        return $result;
                        break;
                    case 'multi_send':
                        $result = $this->request($data,$url,$mean);//请求类型为个性化群发
                        return $result;
                        break;
                }
            }
        catch (Exception $e) {
           print_r($e->getMessage());//输出捕获的异常消息
        }
    }

    /**
     * 公有请求方法
     * *$data：请求提交数据
     * $url：请求地址
     * $mean：请求类型
     */
    public function request($data,$url,$mean)
    {
        try{
            $ConfigManager = new ConfigManager();
            $Chttp = new Chttp();
            $send_ip = $ConfigManager->get_ip();//获取IP信息
            $ip = $send_ip['analysis_ip'];//已处理IP信息赋值
            $domain_name = $send_ip['unresolved_domain_name'];//未处理IP信息赋值
            if (!empty($ip)) //存在可用主备IP
            {
                $ip_num=count($ip);//获取可用IP个数
                if (!empty($send_ip['abnormal']))//主IP异常
                {
                    $interval_time = (time() - $send_ip['last_detection_time']) / 60;//获取上一次主IP检测的间隔时间
                    if ($interval_time < 5&&$ip_num>1)//没有达到5分钟检测时间且含有备IP
                    {
                        $ip_main=$ip[1];//将主IP信息进行赋值
                        unset($ip[1]);//移除主IP
                    }
                }
                foreach ($ip as $k => $v) {
                    $result = $Chttp->PostCURL('http://' . $v['ip'] . $url . $mean, $data);//进行请求
                    if ($result['result'] !== $this->ERROR_310099)//请求结果非网络问题
                    {
                        if ($k == 1 && !empty($send_ip['last_detection_time']) && !empty($send_ip['abnormal']))//主IP状态为异常时
                        {
                            unset($send_ip['last_detection_time']);//移除检测时间
                            unset($send_ip['abnormal']);//移除主IP异常状态
                            $ConfigManager->set_ip($send_ip);//更新IP缓存信息
                        }
                        return $result;//返回请求结果
                    } else {
                        if ($k == 1)//为主IP时
                        {
                            if (!empty($send_ip['last_detection_time']) && !empty($send_ip['abnormal']))//主IP状态为异常时
                            {
                                if ($v['isip'] === 0)//存在对应域名
                                {
                                    $new_ip = $ConfigManager->analysis_domain_name($domain_name[$k]);//获取变更域名解析后的IP
                                    if ($new_ip['ip'] != $v['ip'])//重新从该域名下获取到的IP与之前获取到的IP不一致
                                    {
                                        $result = $Chttp->PostCURL('http://' . $new_ip['ip'] . $url . $mean, $data);//进行请求
                                        if ($result === 0) {
                                            $send_ip['analysis_ip'][$k]['ip'] = $new_ip['ip'];//将原有IP进行覆盖
                                            unset($send_ip['last_detection_time']);//移除检测时间
                                            unset($send_ip['abnormal']);//移除主IP异常状态
                                            $ConfigManager->set_ip($send_ip);//更新IP缓存信息
                                            return $result;//返回请求结果
                                        } else {
                                            $send_ip['last_detection_time'] = time();//检测时间赋值为当前时间轴
                                            $ConfigManager->set_ip($send_ip);//更新IP缓存信息
                                        }
                                    } else {
                                        $send_ip['last_detection_time'] = time();//检测时间赋值为当前时间轴
                                        $ConfigManager->set_ip($send_ip);//更新IP缓存信息
                                    }
                                } else {
                                    $send_ip['last_detection_time'] = time();//检测时间赋值为当前时间轴
                                    $ConfigManager->set_ip($send_ip);//更新IP缓存信息
                                }
                            } else//状态不为异常时
                            {
                                $send_ip['last_detection_time'] = time();//检测时间赋值为当前时间轴
                                $send_ip['abnormal'] = 1;//主IP状态设为异常
                                $ConfigManager->set_ip($send_ip);//更新IP缓存信息
                            }
                            unset($ip[$k]);//移除主IP信息，如果所有IP都请求失败，则只验证备IP
                        }
                    }
                }
                if(!empty($ip_main))//存在可用主IP，所有IP都请求失败
                {
                    $ip[1]=$ip_main;//将主IP信息放入IP集合中
                }
                if (!empty($ip))//存在可用IP，所有IP都请求失败，则验证全部的IP
                {
                    foreach ($ip as $k => $v)//所有的IP请求失败时再次检测所有IP
                    {
                        if ($v['isip'] === 0)//若果存在对应域名
                        {
                            $new_ip = $ConfigManager->analysis_domain_name($domain_name[$k]);//获取变更域名解析后的IP
                            if ($new_ip['ip'] != $v['ip'])//重新从该域名下获取到的IP与之前获取到的IP不一致
                            {
                                $result = $Chttp->PostCURL('http://' . $new_ip['ip'] . $url . $mean, $data);//进行请求
                                if ($result === 0) {
                                    if($k==1)
                                    {
                                        unset($send_ip['last_detection_time']);//移除检测时间
                                        unset($send_ip['abnormal']);//移除主IP异常状态
                                    }
                                    $send_ip['analysis_ip'][$k]['ip'] = $new_ip['ip'];//将原有IP进行覆盖
                                    $ConfigManager->set_ip($send_ip);//更新IP缓存信息
                                    return $result;//返回请求结果
                                }
                            }
                        }
                    }
                    $result['result'] = $this->ERROR_310099;//检测所有IP全部不可用
                }
                $result['result'] = $this->ERROR_310099;//无可用IP
            }
            $result['result'] = $this->ERROR_310099;//无可用IP
            return $result;
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }
}
?>
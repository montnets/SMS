<?php
/**
 * Created by PhpStorm.
 * Date: 2017-03-03
 * Time: 20:33
 * @功能概要：域名(IP)处理类
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
class ConfigManager
{
    /*
     *解析域名
     * $ip 用户账号信息主备IP(域名)解析，若无端口号则自动加上'80'端口号
     */
    public function analysis_domain_name($ip)
    {
        try {
            if ($port_position = strpos($ip, ':'))//判断是否有端口号
            {
               $ip_str = substr($ip, 0, $port_position);//截取IP或域名地址
               $ip_len = strlen($ip);//获取IP长度
               $port_str = substr($ip, $port_position + 1, $ip_len);//截取端口号
               $analysis = gethostbyname($ip_str) . ':' . $port_str;//将域名解析为IP，若为IP，则仍然为IP,解析完成与端口号进行拼接
            } else {
               $analysis = gethostbyname($ip);//将域名解析为IP，若为IP，则仍然为IP
               $analysis = $analysis . ':80';//无端口号时自动加上80端口
            }
            if (preg_match('/[a-zA-Z]/', $ip))//判断用户设置的是IP还是域名
            {
                $isip = 0;//用户设置的为域名
            } else {
                $isip = 1;//用户设置的为IP
            }
            $analysis_ip = array('ip' => $analysis, 'isip' => $isip);//与解析前的域名(IP)进行键值对应
            return $analysis_ip;
        } catch (Exception $e) {
            print_r($e->getMessage());//输出捕获的异常消息
        }
    }
    /**
     * 获取缓存文件地址
     */
    public function filename()
    {
        try {
            $file_url = dirname(__FILE__). DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR . 'cache.txt';//获取缓存文件路径
            if (file_exists($file_url)) //判断是否存在该文件
            {
                return $file_url;//存在则返回文件路径
            }
            fopen($file_url, "w");//不存在则创建文件
            return $file_url;//返回创建文件路径
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }
    /*
     *获取文件内容
     */
    public function get_file()
    {
        try {
            $file_name = $this->filename();//获取文件
            if (is_readable($file_name))//判断缓存文件是否可读
            {
                if ($cache = file_get_contents($file_name))//读取对应文件内容
                {
                    return json_decode(base64_decode($cache), true);//解析数据
                }
                return null;//读取文件失败返回null
            }
            return null;//读取文件失败返回null
        }catch (Exception $e) {
            print_r($e->getMessage());//输出捕获的异常消息
            return null;//读取文件失败返回null
        }
    }
    /*
     *获取IP信息
     */
    public function get_ip()
    {
        try{
            $file=$this->get_file();//获取文件内容
            $ip=!empty($file['ip'])?$file['ip'] : null;//读取用户账号信息，若无信息则返回null
            return $ip;
        }catch (Exception $e) {
            print_r($e->getMessage());//输出捕获的异常消息
            return false;
        }
    }
    /*
    *设置IP信息保存
    * $user：用户信息
    */
    public function set_ip($ip)
    {
        try {
            $all = $this->get_file();//获取文件内容
            $all['ip'] = $ip;
            $all = base64_encode(json_encode($all));//对用户信息进行加密
            if (is_writable($this->filename())) //文件是否可写入
            {
                if (file_put_contents($this->filename(), $all, LOCK_EX))//对当前文件进行写入操作时将文件锁死
                {
                    return true;
                }
                return false;
            }
            return false;
        }catch (Exception $e) {
           print_r($e->getMessage());//输出捕获的异常消息
           return false;
        }
    }
    /*
     * 设置IP信息
     * $domain_name：域名(IP)
     */
    public function set_usableip($domain_name)
    {
        try {
                $i=1;
                foreach($domain_name as $k=>$v)
                {
                    $cache_ip['analysis_ip'][$i]=$this->analysis_domain_name($domain_name[$k]);//获取变更域名解析后的IP
                    $cache_ip['unresolved_domain_name'][$i]=$domain_name[$k];//域名(IP)放入缓存数据中
                    $i++;
                }
                if($this->set_ip($cache_ip))//将缓存数据放入缓存文件中
                {
                    return true;
                }
                return false;
            }catch (Exception $e) {
            print_r($e->getMessage());//输出捕获的异常消息
            return false;
        }
    }
    /*
     * 清除所有IP信息
     */
    public function removeAllIpInfo()
    {
        try {
            if (is_writable($this->filename())) //文件是否可写入
            {
                if (file_put_contents($this->filename(),' ', LOCK_EX))//对当前文件进行写入操作时将文件锁死,此处对文件内容进行清空
                {
                    return true;
                }
                return false;
            }
        } catch (Exception $e) {
            print_r($e->getMessage());//输出捕获的异常消息
            return false;
        }
    }
}
?>